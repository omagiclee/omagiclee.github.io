#!/usr/bin/env python3
from pathlib import Path
from struct import unpack
import sys

keep={b'IHDR',b'iCCP',b'cICP',b'IDAT',b'IEND'}
for n in sys.argv[1:]:
    f=Path(n)
    data=f.read_bytes()
    assert data[:8]==b'\x89PNG\r\n\x1a\n'
    p=8
    output=[data[:8]]
    names=set()
    while p<len(data):
       size,kind=unpack('>I4s',data[p:p+8])
       end=p+size+12
       assert end<=len(data)
       if kind in keep:
           names.add(kind)
           output.append(data[p:end])
       p=end
    assert {b'iCCP',b'cICP',b'IHDR',b'IDAT',b'IEND'} <= names
    f.write_bytes(b''.join(output))
