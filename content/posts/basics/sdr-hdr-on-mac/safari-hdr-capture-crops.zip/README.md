# Safari 与「预览」的系统 HDR 截图裁片

这些 PNG 是从三张 macOS 原生 HDR HEIC 截图裁出的合成测试色条，**不是原始截图、不是用取样数据重绘的色卡**。处理时显式解码 HDR，仅输出色条内部窄带，无桌面和其他窗口。裁片保存为 Display P3 PQ 16-bit PNG，没有缩放，不保存原截图的元数据或其他画面。网页上的 SDR 展示条则另行以同一 0.25 线性倍率减亮、缩放到相同尺寸并转出 SDR Display P3。

| 文件 | 截图 | 条件 |
| --- | --- | --- |
| safari-jpeg-hdr.png | 图 1 上 | Safari 前台，同一份 ISO 增益图 JPEG |
| preview-jpeg-hdr.png | 图 1 下 | 预览前台，同一份 ISO 增益图 JPEG |
| safari-same-jpeg-hdr.png | 图 2 上 | 同一张 Safari 截图里的 ISO 增益图 JPEG |
| safari-same-pq-hdr.png | 图 2 下 | 同一张 Safari 截图里的直接 Display P3 PQ PNG |

`crop-coordinates.txt` 记录原文件尺寸与以左下为原点的裁剪范围。`crop-captures.swift` 记录导出过程。公开文件另用 `strip-png-metadata.py` 只保留像素与颜色描述，完整原桌面截图未公开。`crop-roundtrip.txt` 为对公开 PNG 重新 HDR 解码和取样的原始数据，两个色块的次／主通道比与原截图相比绝对误差均小于 0.003。正文表格以直接取原 HEIC 的数据为准。截图数值是合成信号，不是显示器实测 nit。

例如，用公开裁片复核 Safari 单图一排的灰阶和两块颜色：

~~~sh
swiftc sample-capture.swift -o sample-capture
./sample-capture crops/safari-jpeg-hdr.png 1516 244 0 1516 0 244
~~~
