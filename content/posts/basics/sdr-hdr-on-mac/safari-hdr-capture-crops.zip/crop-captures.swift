import CoreGraphics
import CoreImage
import Foundation
import ImageIO

struct Strip {
    let name: String
    let source: String
    let viewW, viewH, left, right, top, bottom: Double
}
let args=Array(CommandLine.arguments.dropFirst())
guard args.count == 4 else { fatalError("Usage: crop-captures outputDirectory safariHEIC previewHEIC pairedHEIC") }
let sets = [
    Strip(name:"safari-jpeg",source:args[1],viewW:960,viewH:540,left:179,right:562,top:34,bottom:195),
    Strip(name:"preview-jpeg",source:args[2],viewW:960,viewH:515,left:132,right:828,top:146,bottom:438),
    Strip(name:"safari-same-jpeg",source:args[3],viewW:929,viewH:1000,left:28,right:817,top:120,bottom:455),
    Strip(name:"safari-same-pq",source:args[3],viewW:929,viewH:1000,left:28,right:817,top:562,bottom:899)
]
let linear=CGColorSpace(name:CGColorSpace.extendedLinearDisplayP3)!
let sdr=CGColorSpace(name:CGColorSpace.displayP3)!
let pq=CGColorSpace(name:CGColorSpace.displayP3_PQ)!
let ctx=CIContext(options:[.workingColorSpace:linear])
let dir=URL(fileURLWithPath:args[0],isDirectory:true)
let options=[kCGImageSourceDecodeRequest as String:kCGImageSourceDecodeToHDR] as CFDictionary
for a in sets {
    guard let src=CGImageSourceCreateWithURL(URL(fileURLWithPath:a.source) as CFURL,nil),
          let image=CGImageSourceCreateImageAtIndex(src,0,options) else { fatalError("Capture could not be HDR decoded: \(a.name)") }
    let sw=Double(image.width)/a.viewW, sh=Double(image.height)/a.viewH
    let y=(a.top+a.bottom)/2
    let w=a.right-a.left, h=w*0.16
    let l=ceil(sw*(a.left+2)), r=floor(sw*(a.right-2))
    let b=ceil(Double(image.height)-sh*(y+h/2)), t=floor(Double(image.height)-sh*(y-h/2))
    let frame=CGRect(x:l,y:b,width:r-l,height:t-b)
    let linearImage=CIImage(cgImage:image).cropped(to:frame).transformed(by:.init(translationX:-l,y:-b))
    let hdr=linearImage.settingContentHeadroom(image.contentHeadroom)
    try ctx.writePNGRepresentation(of:hdr,to:dir.appendingPathComponent("\(a.name)-hdr.png"),format:.RGBA16,colorSpace:pq,options:[:])
    let view=linearImage.applyingFilter("CIColorMatrix", parameters:[
        "inputRVector":CIVector(x:0.25,y:0,z:0,w:0),
        "inputGVector":CIVector(x:0,y:0.25,z:0,w:0),
        "inputBVector":CIVector(x:0,y:0,z:0.25,w:0),
    ]).settingContentHeadroom(1)
    let resized=view.transformed(by:.init(scaleX:768/frame.width,y:124/frame.height)).cropped(to:.init(x:0,y:0,width:768,height:124))
    try ctx.writePNGRepresentation(of:resized,to:dir.appendingPathComponent("\(a.name).png"),format:.RGBA8,colorSpace:sdr,options:[:])
    print("\(a.name) full=\(image.width)x\(image.height) imageHeadroom=\(image.contentHeadroom) cropBottomLeft=(\(Int(l)),\(Int(b)),\(Int(r-l)),\(Int(t-b)))")
}
