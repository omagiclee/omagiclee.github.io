#!/usr/bin/env python3
from pathlib import Path
import json, subprocess, re, argparse
import numpy as np
p=argparse.ArgumentParser()
p.add_argument('--capture-dir',default='/private/tmp/four-media-display.tScO6j/captures')
p.add_argument('--sampler',default='/private/tmp/four-media-display.tScO6j/sampler.py')
p.add_argument('--output',default='front-video')
p.add_argument('--ignore-raw',action='store_true',help='skip regeneration and retain previous samples')
p.add_argument('--verbosity',type=int,default=1)
args=p.parse_args()
capture=Path(args.capture_dir); out=Path(args.output); out.mkdir(exist_ok=True,parents=True)
names={
 'com.google.chrome.for.testing':'Chrome','com.google.Chrome.forTesting':'Chrome','com.google.Chrome.for.Testing':'Chrome',
 'com.apple.Safari':'Safari','com.apple.QuickTimePlayerX':'QuickTime','com.apple.Photos':'Photos',
}
label=['Chrome','Safari','QuickTime','Photos']
metrics=[]
def footer_white(path,rect,m):
    width,height=m['width'],m['height']
    arr=np.fromfile(path,dtype='<f2').reshape(height,width,4)[:,:,:3]
    x0,y0,w,h=rect
    white=[]
    for x in np.arange(0.015,.065,.006)*w+x0:
        for y in np.arange(9,75,2)+y0+h:
            i,j=int(round(x)),int(round(y))
            if i-6<0 or i+6>=width or j-6<0 or j+6>=height:continue
            q=arr[j-5:j+6,i-5:i+6].astype(np.float32)
            if np.max(np.ptp(q,axis=(0,1)))<.004 and np.min(q)>.85 and np.max(q)<1.16 and np.max(q)-np.min(q)<.025:
                white.append((i,j))
    if white:
        middle=np.median(white,axis=0)
        return min(white,key=lambda z: np.linalg.norm(np.array(z)-middle))
    return None
candidates=sorted([x for x in capture.glob('*.rgba16') if re.search(r'(?i)hdr[-_].*(pq|hlg).*video|hdr[-_].*video.*(pq|hlg)',x.name)])
for raw in candidates:
    command=[]
    b=raw.with_suffix('')
    try:
        m=json.loads(b.with_suffix('.json').read_text())
        name=names[m['target']]
        format='PQ' if re.search(r'pq',raw.name,re.I) else 'HLG'
        if m.get('captureMode') not in ['HDR local screenshot']:raise ValueError('capture not identified as HDR local')
        derived=out/(b.name+'.json')
        if args.ignore_raw and derived.exists():
            sample=json.loads(derived.read_text())
        else:
            roi=json.loads(subprocess.check_output(['python3',str(Path(__file__).with_name('locate-hdr-video.py')),str(b)]))
            rect=roi['rect']
            white=footer_white(raw,rect,m) if name in ['Chrome','Safari'] else None
            command=['python3',args.sampler,str(b),*(str(i) for i in rect),'--layout','hdr-video']
            if white:command+=['--white',*(str(i) for i in white)]
            sample=json.loads(subprocess.check_output(command))
            sample['localizer']=roi
            derived.write_text(json.dumps(sample,indent=2)+'\n')
        gray=[z['Y'] for z in sample['samples'][0]]
        mmax=gray[-1]
        color=sample['samples'][1][:3]
        def q(c,i,j):
            v=color[c]['rgb']
            return v[i]/v[j] if abs(v[j])>.001 else None
        a={'app':name,'kind':format,'variant':'AMVE' if 'amve' in b.name.lower() else 'default','capture':b.name,
           'EDR':m['EDRAfter'],'ratio1000over203':mmax/gray[4],'gray203':gray[4],'peakY1000':mmax,
           'grayY':gray,'ratioGray': [z/gray[4] for z in gray],'cssWhiteY':sample.get('uiSDRWhite',{}).get('Y'),
           'rect':sample['rect'],'red_G_R':q(0,1,0),'green_R_G':q(1,0,1),'blue_R_B':q(2,0,2),
           'sample':str(derived)},
        metrics.extend(a)
    except Exception as e:
        if args.verbosity:print('skip',raw.name,e)
metrics.sort(key=lambda m:(m['kind'],label.index(m['app']),m['variant']=='AMVE',m['capture']))
(out/'metrics.json').write_text(json.dumps(metrics,indent=2)+'\n')
# Plots default controlled condition only. The capture name is retained in
# metrics if multiple capture candidates exist for the same application.
prefer={}
for x in metrics:
    if x['variant']=='default':
        k=(x['app'],x['kind'])
        if k not in prefer or ('repeat' not in x['capture'] and 'repeat' in prefer[k]['capture']):
            prefer[k]=x
idx=list(prefer.values())
(out/'plot-index.json').write_text(json.dumps(idx,indent=2)+'\n')
for x in metrics:
 print(x['app'],x['kind'],x['variant'],x['capture'],'EDR {:.3f} Y203 {:.5f} Y1000 {:.5f} ratio {:.5f} cssWhite {} RGB leakage {:.4f} {:.4f} {:.4f}'.format(x['EDR'],x['gray203'],x['peakY1000'],x['ratio1000over203'],x['cssWhiteY'],x['red_G_R'],x['green_R_G'],x['blue_R_B']))
