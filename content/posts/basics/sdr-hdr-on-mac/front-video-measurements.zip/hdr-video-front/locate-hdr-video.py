#!/usr/bin/env python3
"""Locate the seven chromatic patches in the lab HDR video and recover frame rect.

Input is the raw macOS HDR screen capture paired with its dimensions JSON. The
bytes were validated top-left by the capture operator. No overlay is read as
video unless seven equally spaced rectangular color patches and the gray row
both validate.
"""
import argparse
import json
from pathlib import Path
import numpy as np
p=argparse.ArgumentParser()
p.add_argument('base')
p.add_argument('--rect-only',action='store_true')
a=p.parse_args()
base=Path(a.base)
m=json.loads(base.with_suffix('.json').read_text())
w,h=int(m['width']),int(m['height'])
raw=np.fromfile(base.with_suffix('.rgba16'),dtype='<f2')
if raw.size!=w*h*4: raise ValueError('wrong capture size')
rgb=raw.reshape(h,w,4)[:,:,:3].astype(np.float32)
pmax=np.max(rgb,axis=2); pmin=np.min(rgb,axis=2)
sat=(pmax-pmin)>0.115*np.maximum(pmax,0.015)
sat &= (pmax-pmin)>0.0025
Y_COEFF=np.array([.22897456,.69173852,.07928691])

def rstats(cx,cy,d=4):
    cx,cy=int(round(cx)),int(round(cy))
    if not d<=cx<w-d or not d<=cy<h-d: raise ValueError('not within capture')
    q=rgb[cy-d:cy+d+1,cx-d:cx+d+1].reshape(-1,3)
    return np.median(q,axis=0),float(np.max(np.ptp(q,axis=0)))

def detect(step):
    observations=[]
    for y in range(0,h,step):
        seq=np.diff(np.pad(sat[y].astype(np.int8),(1,1)))
        L,R=np.where(seq==1)[0],np.where(seq==-1)[0]
        sw=R-L
        valid=np.where(sw>=max(9,w*0.019))[0]
        if len(valid)<7: continue
        centers=(L[valid]+R[valid]-1)/2
        widths=sw[valid]
        for i in range(len(valid)-6):
            x=centers[i:i+7]
            sw=widths[i:i+7]
            pitch=float((x[-1]-x[0])/6)
            if not 16<pitch<w/7.7:continue
            loc_err=np.max(np.abs((x-x[0])-np.arange(7)*pitch))
            widths_err=np.max(np.abs(sw/float(pitch)-0.6))
            if loc_err>max(2.2,pitch*.065) or widths_err>.135:continue
            xs=np.rint(x).astype(int)
            c=rgb[y,xs,:]
            if np.argmax(c[0])!=0 or np.argmax(c[1])!=1 or np.argmax(c[2])!=2:continue
            observations.append((x[0],pitch,y,loc_err+pitch*widths_err))
    return observations
rows=detect(2)
if not rows: raise RuntimeError('no seven-patch chromatic row found')
# Cluster by x0 and pitch, as window chrome has unrelated content.
groups=[]
for cx,pitch,y,err in rows:
    for z in groups:
        if abs(z[0][0]-cx)<max(3,pitch*.035) and abs(z[0][1]-pitch)<max(1,pitch*.02):
            z.append((cx,pitch,y,err));break
    else:groups.append([(cx,pitch,y,err)])
results=[]
for g in groups:
    if len(g)<5:continue
    xa,pitch,_,_=np.median(g,axis=0)
    WW=pitch*8; HH=WW*9/16
    ys=sorted(set(o[2] for o in g))
    # Pick a continuous run spanning the expected 96/720 height.
    runs=[[ys[0]]]
    for y in ys[1:]:
        if y-runs[-1][-1]<=4:runs[-1].append(y)
        else:runs.append([y])
    for run in runs:
        height=run[-1]-run[0]+2
        if not .63<=height/(HH*96/720)<=1.25:continue
        y2=(run[0]+run[-1])/2
        left=xa-pitch/2
        top=y2-HH*488/720
        y1=top+HH*232/720
        if not -4<=left<=w-WW+4 or not -4<=top<=h-HH+4:continue
        centers=[xa+i*pitch for i in range(8)]
        r1=[rstats(x,y1) for x in centers]
        r2=[rstats(x,y2) for x in centers]
        c1=np.array([z[0] for z in r1])
        c2=np.array([z[0] for z in r2])
        yy=c1@Y_COEFF
        if not yy[4]>0.01 or not yy[-1]>yy[0]+.1:continue
        if np.any(np.diff(yy)<-max(.002,.015*yy[4])):continue
        if np.max(np.ptp(c1,axis=1)/np.maximum(np.max(c1,axis=1),.012))>.2:continue
        if not np.array_equal(np.argmax(c2[:3],axis=1),[0,1,2]):continue
        patchspread=max(z[1] for z in r1+r2)
        if patchspread>max(.035,.1*yy[4]):continue
        score=len(run)-np.median(g,axis=0)[3]*.25-patchspread*15
        pred=[float(z) for z in (left,top,WW,HH)]
        results.append((score,{'rect':pred,'colored_band_rows':len(run),'plate_peakY':float(yy[-1]),
                              'plate_whiteY':float(yy[4]),'maximum_roi_span':patchspread}))
if not results: raise RuntimeError('geometry candidates found, gray validation failed')
results.sort(key=lambda x:x[0],reverse=True)
best=results[0][1]
if a.rect_only: print(' '.join(f'{v:.2f}' for v in best['rect']))
else: print(json.dumps(best,indent=2))
