import fs from 'node:fs'
import {pathToFileURL} from 'node:url'
import {join} from 'node:path'
const {scaleLog,line,symbol,symbolCircle,symbolSquare,symbolTriangle,symbolDiamond} =
  await import(process.env.D3_PATH ? pathToFileURL(join(process.env.D3_PATH,'src','index.js')).href : 'd3')
const [inpath,svgpath]=process.argv.slice(2)
if (!inpath||!svgpath) throw new Error('Use plot-video.mjs measurement-index.json comparison.svg')
const entries = JSON.parse(fs.readFileSync(inpath,'utf8'))
const targets=[.5,5,25,100,203,400,800,1000]
const floor=.001, ceiling=12
const palette=['#0072B2','#B94D11','#007F5F','#8E3C89']
const icons=[symbolCircle,symbolSquare,symbolTriangle,symbolDiamond]
const names=['Chrome','Safari','QuickTime','Photos']
const label={Chrome:'Chrome',Safari:'Safari',QuickTime:'QuickTime',Photos:'照片'}
const f = n => String(Number(n.toFixed(2)))
const esc = s => s.replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;')
const counts = [0,0]
const series=entries.map(e=>{
  const m=JSON.parse(fs.readFileSync(e.sample,'utf8'))
  if(!names.includes(e.app) || !['PQ','HLG'].includes(e.kind)) throw new Error('Unknown app or format')
  const g=m.samples?m.samples[0]:m.gray
  const ys=g?.map(p=>p?.Y)
  if(!Array.isArray(ys) || ys.length!==8 || !ys.every(Number.isFinite) || ys[4]<=0)
    throw new Error('Missing valid luminance or 203-reference for '+e.sample)
  counts[e.kind==='PQ'?0:1]++
  return {app:e.app,kind:e.kind,white203:ys[4],peak:ys[7],ratio:ys.map(v=>v/ys[4]),file:e.sample}
})
const fmt=(x)=>x<.1?(x.toFixed(3).replace(/0+$/,'')):x.toFixed(2)
const viewW=920,viewH=480,panelW=350,panelH=246,panelY=103
const xs=scaleLog().domain([.5,1000]).range([0,panelW])
const ys=scaleLog().domain([floor,ceiling]).range([panelH,0])
const points=(s,x)=>targets.map((m,i)=>[x+xs(m),panelY+ys(Math.max(floor,Math.min(s[i],ceiling)))])
const pathgen=line()
let a=[]
a.push('<svg xmlns="http://www.w3.org/2000/svg" role="img" viewBox="0 0 '+viewW+' '+viewH+'"><title>PQ 与 HLG 视频的 Mac 应用合成亮度曲线</title><desc>横轴是设计亮度，纵轴是 HDR 截屏扩展线性亮度相对于 203 nit 测试白。虚线为理想母版目标，缺失应用不画曲线。</desc>')
a.push('<rect width="100%" height="100%" rx="14" fill="#f9fbfe"/><g font-family="system-ui,PingFang SC,sans-serif" fill="#253345" font-size="13">')
a.push('<text x="48" y="37" font-size="23" font-weight="650">同一母版灰阶，分开测 PQ 和 HLG</text>')
a.push('<text x="48" y="62" fill="#536276">纵轴为合成画面亮度相对 203 nit 测试白，不是屏幕出光 nit</text>')
const yTicks=[.001,.01,.1,1,10]
for (let c=0;c<2;c++) {
  const kind=['PQ','HLG'][c], x=[85,526][c]
  const here=series.filter(e=>e.kind===kind)
  const groups=[]
  for (const v of here) {
    const same=groups.find(g=>g[0].ratio.every((a,i)=>Math.abs(a-v.ratio[i])<0.000001))
    if(same) same.push(v); else groups.push([v])
  }
  a.push('<text x="'+x+'" y="91" font-size="16" font-weight="650">'+kind+' · '+counts[c]+' 个实测应用</text>')
  for(const y of yTicks){
    const yy=panelY+ys(y)
    a.push('<line x1="'+x+'" y1="'+f(yy)+'" x2="'+(x+panelW)+'" y2="'+f(yy)+'" stroke="'+(y===1?'#9cadc4':'#dbe3ef')+'" stroke-width="1"/>')
    a.push('<text x="'+(x-5)+'" y="'+f(yy+4)+'" text-anchor="end">'+y+'×</text>')
  }
  for(const m of [.5,5,25,100,203,1000]){
    const xx=x+xs(m)
    a.push('<line x1="'+f(xx)+'" y1="'+panelY+'" x2="'+f(xx)+'" y2="'+(panelY+panelH)+'" stroke="#e4eaf2" stroke-width="1"/>')
    a.push('<text x="'+f(xx)+'" y="'+(panelY+panelH+20)+'" text-anchor="middle">'+m+'</text>')
  }
  a.push('<text x="'+(x+panelW/2)+'" y="'+(panelY+panelH+40)+'" text-anchor="middle">设计亮度 / nit</text>')
  a.push('<path d="'+pathgen(points(targets.map(y=>y/203),x))+'" fill="none" stroke="#646f7e" stroke-width="1.5" stroke-dasharray="4 4"/>')
  for(const [s,...same] of groups){
    const namesInGroup=[s,...same].map(v=>label[v.app]).join(' / ')
    if(same.length){
      a.push('<text x="'+(x+panelW/2)+'" y="'+(panelY+panelH+62)+'" text-anchor="middle" fill="#536276">'+esc('曲线重合：'+namesInGroup)+'</text>')
    }
    const index=names.indexOf(s.app), co=palette[index]
    const p=points(s.ratio,x)
    a.push('<path d="'+pathgen(p)+'" fill="none" stroke="'+co+'" stroke-width="2"/>')
    for(let i=0;i<p.length;i++){
      a.push('<path d="'+symbol(icons[index],32)()+'" transform="translate('+p[i].map(f).join(' ')+')" fill="'+co+'"><title>'+esc(namesInGroup+' / '+kind+' / '+targets[i]+' nit 目标 → '+fmt(s.ratio[i])+'×')+'</title></path>')
    }
  }
}
names.forEach((n,i)=>{
  const x=70+i*142
  a.push('<path d="'+symbol(icons[i],44)()+'" transform="translate('+x+' 449)" fill="'+palette[i]+'"/>')
  a.push('<text x="'+(x+12)+'" y="453">'+esc(label[n])+'</text>')
})
a.push('<line x1="650" y1="449" x2="669" y2="449" stroke="#646f7e" stroke-width="1.5" stroke-dasharray="4 4"/><text x="677" y="453">母版参考</text>')
a.push('<text x="790" y="453" fill="#536276">未测不画</text></g></svg>')
fs.writeFileSync(svgpath,a.join('\n'))
console.log(JSON.stringify(series,null,2))
