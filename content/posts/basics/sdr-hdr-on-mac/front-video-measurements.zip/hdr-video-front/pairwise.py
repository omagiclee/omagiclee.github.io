from pathlib import Path
import json,numpy as np
from itertools import combinations
data=json.load(open('front-video/metrics.json'))
def read(a):
 p=json.load(open(a['sample']))
 return np.array([[x['rgb'] for x in y] for y in p['samples']]),np.array([[x['Y'] for x in y] for y in p['samples']])
pairs=[]
for a,b in combinations(data,2):
 if a['kind']!=b['kind'] or a['variant']!=b['variant']:continue
 ar,ay=read(a);br,by=read(b)
 row={
   'format':a['kind'], 'a':a['app'], 'b':b['app'],
   'aSample':a['capture'],'bSample':b['capture'],
   'maxAbsRGB':float(np.max(np.abs(ar-br))),
   'maxAbsY':float(np.max(np.abs(ay-by))),
   'maxAbsRGBOverWhite203':float(np.max(np.abs(ar/ay[0,4]-br/by[0,4]))),
   'maxAbsYOverWhite203':float(np.max(np.abs(ay/ay[0,4]-by/by[0,4]))),
   'peakRatioPctBvsA':float(100*(b['ratio1000over203']/a['ratio1000over203']-1)),
 }
 pairs.append(row)
 print(row['format'],row['a'],row['b'],*[str(round(row[k],7)) for k in ['maxAbsRGB','maxAbsY','maxAbsRGBOverWhite203','peakRatioPctBvsA']])
Path('front-video/pairwise.json').write_text(json.dumps(pairs,indent=2)+'\n')
