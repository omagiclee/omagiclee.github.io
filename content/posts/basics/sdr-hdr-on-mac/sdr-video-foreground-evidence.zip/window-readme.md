# SDR 视频真实前台窗口取样

全部视频输入为同一份精确版 20 s、960×540 的合成 H.264 MP4。合法 BT.709 黑白为码值 16、235，共 32 格。窗口捕获工具只允许前台、固定测试应用和合成文件标题。样块自动定位用到相邻等宽红绿蓝块、16 档单调中性灰和第二处白块，随后对每个中心 11×11 ROI 取中位数并记录内部跨度。

## 主比较只使用 SDR PNG

屏幕捕获时分别请求 SDR 和 HDR 表示。窗口 SDR PNG 是 16-bit Display P3，同一个 ICC 指纹 0ff6958f98684c61f6bbdce1368ddeaf3873baf84545baba482e920d92a914c0，cICP 为 [12,13,0,1]。由 16-bit codeword 逆 sRGB 传递函数得到线性 Display P3，再以色域标准的亮度权重得到线性 Y。坐标以左上为原点。输出近似白 1.0，结果不是光度计 nit。

Raw Float16 数据样本用于捕获输出控制，不能混用在主比较中。例如同一轮 Safari 捕获，同一 Y′126 灰块的 SDR PNG 转换值为 0.259468，HDR local screenshot 转换值为 0.191621。Chrome 的备用 HDR stream preset 则恰与其 SDR 输出吻合。苹果的两个 API 返回不同表示：<https://developer.apple.com/documentation/screencapturekit/scscreenshotoutput/sdrimage> 和 <https://developer.apple.com/documentation/screencapturekit/scscreenshotoutput/hdrimage>。未试图推断截图工具内部如何做此重映射。

## 隐私与复现

这里只包含合成色块取样数据、测量脚本和曲线图，不含完整窗口截图或个人资料。熟悉脚本的复核者可使用本机新的 16-bit Display P3 ScreenCaptureKit 窗口 PNG，配合记录 width/height 的 JSON 跑 compare-sdr-png.py。HDR 控制用 locate-window-sdr.py 读取同次 float16，要求 input 已统一为扩展线性 Display P3 并按图像左上为原点，不能直接读取 PQ 字节。
