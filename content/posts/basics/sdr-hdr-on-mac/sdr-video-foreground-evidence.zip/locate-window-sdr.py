import argparse,json,math
from pathlib import Path
import numpy as np
P3_Y=np.array([0.22897456,.69173852,.07928691])
def runs(mask):
    bounds=np.flatnonzero(np.diff(mask.astype(np.int8),prepend=0,append=0))
    return list(zip(bounds[::2],bounds[1::2]))
def channel_mask(row,channel):
    main=row[...,channel]
    next1,next2=row[..., (channel+1)%3],row[...,(channel+2)%3]
    return (main>.08) & (main>1.62*np.maximum(next1,next2)+.018)
def locate(raw):
    h,w,c=raw.shape
    hints=[]
    rgbs=raw[..., :3]
    for y in range(0,h,max(1,h//180)):
        row=rgbs[y]
        rs,gs,bs=([t for t in runs(channel_mask(row,d)) if t[1]-t[0]>=8] for d in range(3))
        for (r0,r1) in rs:
            cw=r1-r0
            for (g0,g1) in gs:
                if abs(g0-r1)>max(4,cw*.12) or abs((g1-g0)-cw)>cw*.16: continue
                for (b0,b1) in bs:
                    if abs(b0-g1)>max(4,cw*.12) or abs((b1-b0)-cw)>cw*.16: continue
                    newcw=(b1-r0)/3
                    a,b=r0,newcw*8
                    if not (0<=a and a+b<=w+3 and b>=160):continue
                    hints.append((y,a,b))
    if not hints: raise RuntimeError('could not find RGB side-by-side row')
    hints=np.array(hints)
    groups=[]
    seen=set()
    for _,sx,sw in hints:
        key=(int(sx/4),int(sw/4))
        if key in seen: continue
        seen.add(key)
        g=hints[(abs(hints[:,1]-sx)<5)&(abs(hints[:,2]-sw)<10)]
        groups.append([len(g), np.median(g[:,1]),np.median(g[:,2]),np.median(g[:,0])])
    groups.sort(reverse=True)
    for count,x,dx,cy in groups:
        xs=np.round(x+dx*(np.arange(8)+.5)/8).astype(int)
        if xs.min()<6 or xs.max()>=w-6: continue
        match=np.ones(h,dtype=bool)
        for ch,k in enumerate(xs[:3]): match &= channel_mask(rgbs[:,k],ch)
        yr=next((t for t in runs(match) if t[0]<=cy<=t[1] and t[1]-t[0]>=12),None)
        if yr is None:continue
        y2,y3=yr
        dy0=dx*9/16; dyy=(y3-y2)*4
        if abs(dyy-dy0)>max(10,dy0*.18):continue
        # Estimate aspect-ratio and row edge jointly. Integer padding may change the result by a few pixels.
        dxrat=min(dx,w-x)
        y=(y2+y3)/2-dy0*2.5/4
        dy=dy0
        if y< -4 or y+dy>h+4:continue
        y=max(y,0);dy=min(dy,h-y)
        ys=np.round(y+dy*(np.arange(4)+.5)/4).astype(int)
        if ys.min()<6 or ys.max()>=h-6:continue
        values=rgbs[ys[:,None],xs[None,:]]
        gray=values[:2].reshape(16,3)
        lum=gray@P3_Y
        if not (np.all(np.diff(lum)>-.012) and lum[0]<.055 and .4<lum[-1]<1.5 and np.max(np.ptp(gray,axis=1))<.035):
            continue
        white=values[3,7]@P3_Y
        if abs(white-lum[-1])>.15:continue
        return [float(x),float(y),float(dxrat),float(dy)]
    raise RuntimeError(f'{len(hints)} RGB runs matched but none passed the neutral/white check')
def sample(raw,rect):
    h,w,c=raw.shape
    x,y,dx,dy=rect
    samples=[]
    for i in range(4):
        row=[]
        for j in range(8):
            cx=int(round(x+dx*(j+.5)/8));cy=int(round(y+dy*(i+.5)/4))
            if cx-5<0 or cy-5<0 or cx+5>=w or cy+5>=h:raise AssertionError('unsafe ROI')
            b=raw[cy-5:cy+6,cx-5:cx+6,:3]
            rgb=np.median(b,axis=(0,1))
            v=np.max(np.ptp(b.reshape(-1,3),axis=0))
            row.append(dict(xy=[cx,cy],rgb=[round(float(v),6) for v in rgb],Y=round(float(rgb@P3_Y),6),patchSpan=round(float(v),6)))
        samples.append(row)
    return samples
def analyze(b, rect=None):
    m=json.loads(Path(b+'.json').read_text())
    w,h=int(m['width']),int(m['height'])
    data=Path(b+'.rgba16')
    if data.stat().st_size!=w*h*8:raise RuntimeError('bad size when loading raw float16')
    raw=np.fromfile(data,dtype='<f2').reshape(h,w,4).astype(np.float32)
    rect=locate(raw) if rect is None else rect
    v=sample(raw,rect)
    return {'uuid':Path(b).name,'capture':m,'rect':[round(x,3) for x in rect],'samples':v}
if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('base',nargs='+')
    p.add_argument('--rect',nargs=4,type=float)
    p.add_argument('-o','--outdir',type=Path,default=Path('window-output'))
    a=p.parse_args()
    a.outdir.mkdir(parents=True,exist_ok=True)
    for b in a.base:
        try:
            rec=analyze(b,a.rect)
            dst=a.outdir/f'{rec["uuid"]}.json'
            dst.write_text(json.dumps(rec,indent=2)+'\n')
            s=rec['samples']
            print(rec['uuid'],rec['rect'],f'Y16={s[0][0]["Y"]},Y64={s[0][7]["Y"]},Y126={s[1][3]["Y"]},Y176={s[1][5]["Y"]},Y235={s[1][7]["Y"]}',f'max span={max(x["patchSpan"] for row in s for x in row):.5f}')
        except Exception as e:
            print(Path(b).name, 'ERROR:',e)
