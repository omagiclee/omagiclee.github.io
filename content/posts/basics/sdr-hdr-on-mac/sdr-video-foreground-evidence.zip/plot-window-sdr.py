import json,sys,itertools,math
from pathlib import Path
import numpy as np
from xml.sax.saxutils import escape
src=json.load(open('source-measurements.json'))['sdr709.mp4']
labels={'chrome':'Chrome','safari':'Safari','qtp':'QuickTime','photos':'照片'}
palette={'chrome':'#235ac7','safari':'#1f7e71','qtp':'#9f41a0','photos':'#a76009'}
plot=[]
for filename in sys.argv[1:]:
 d=json.load(open(filename))
 app=d['uuid'].split('-')[0]
 if app in labels:plot.append((app,d))
if len(plot)<2:sys.exit('Need at least two foreground captures')
size=(865,518)
w,h=size
message='同一 BT.709 有限范围 MP4 · 前台窗口 SDR 截图统一转换到线性 Display P3'
L,T,R,B=76,76,568,388
def xy(x,y):
 return (L+(x-16)*(R-L)/219,B-y*(B-T)/1.045)
def tx(t,x,y,fill='#334155',s=14,anchor='start',weight=400):
 return f'<text x="{x}" y="{y}" fill="{fill}" font-size="{s}" text-anchor="{anchor}" font-weight="{weight}">{escape(str(t))}</text>'
parts=[f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {w} {h}" role="img" aria-labelledby="title description"><title id="title">SDR 视频的实际窗口灰阶对照</title><desc id="description">多个应用用同一二十秒静态视频取样。左边灰阶曲线，右边中灰亮度和32色块相对Chrome的最大偏差。读数不是屏幕光度。</desc><rect width="{w}" height="{h}" rx="16" fill="#f8fafc"/><g font-family="system-ui, sans-serif">']
parts += [tx('SDR 视频：同一个画面在前台窗口里有多接近？',36,33,'#0f172a',21,weight=660),tx(message,36,56,'#475569',13)]
for yn in [0,.25,.50,.75,1.0]:
 _,y=xy(16,yn)
 parts += [f'<path d="M {L} {y:.2f} H {R}" stroke="#cbd5e1" />',tx(format(yn,'.2f'),62,y+4,anchor='end')]
for xn in [16,48,80,112,144,176,208,235]:
 x,_=xy(xn,0)
 parts += [f'<path d="M {x:.2f} {T} V {B}" stroke="#e2e8f0" />',tx(xn,x,410,anchor='middle')]
parts += [tx('线性亮度 Y',L,T+12,s=12),tx("源 Y′ 码值（16–235）",R,434,s=12,anchor='end')]
baseline=next((d for app,d in plot if app=='chrome'),plot[0][1])
rgbref=np.array([[v['rgb'] for v in row] for row in baseline['samples']])
Yref=np.array([[v['Y'] for v in row] for row in baseline['samples']])
parts += ['<rect x="591" y="84" width="243" height="296" rx="13" fill="#eef2f7"/>',
 tx('主样片取样',606,108,'#0f172a',16,weight=650),tx('中灰 Y′126 与四行 32 色块',606,129,'#475569',12),
 tx('应用',607,152,'#334155',12),tx('中灰 Y',736,152,'#334155',12,'end'),tx('max |ΔRGB|',820,152,'#334155',12,'end')]
summary={}
for i,(app,d) in enumerate(plot):
 s=d['samples'];col=palette[app]
 coords=[xy(q['decoded_ycbcr'][0],s[q['row']][q['column']]['Y']) for q in src['patches'] if q['row']<2]
 dash=['','6 4','2 4','8 3 2 3'][i]
 parts.append(f'<polyline fill="none" stroke="{col}" stroke-width="2.7" stroke-dasharray="{dash}" points="'+' '.join(f'{x:.3f},{y:.3f}' for x,y in coords)+'"/>')
 for j,(x,y) in enumerate(coords):
  if j%len(plot)!=i: continue
  parts.append(f'<circle cx="{x:.2f}" cy="{y:.2f}" r="3.2" fill="{col}" stroke="white" stroke-width=".8"/>')
 rgb=np.array([[v['rgb'] for v in row] for row in s])
 lum=np.array([[v['Y'] for v in row] for row in s])
 drgb=abs(rgb-rgbref);dlum=abs(lum-Yref)
 idx=np.unravel_index(np.argmax(drgb),drgb.shape)
 rowy=177+i*29
 parts += [tx(labels[app],607,rowy,col,13,weight=650),tx(f'{lum[1,3]:.4f}',736,rowy,s=13,anchor='end'),tx(f'{drgb.max():.4f}',820,rowy,s=13,anchor='end')]
 summary[app]={'name':labels[app],'Y16':lum[0,0],'Y64':lum[0,7],'Y126':lum[1,3],'Y176':lum[1,5],'Y235':lum[1,7],'relative_max_channel_error_vs_reference':round(float(drgb.max()),6),'absolute_max_luma_error_vs_reference':round(float(dlum.max()),6),'max_channel_where':list(map(int,idx)),'rgb_skin_warm':s[2][6]['rgb'],'rgb_red':s[2][0]['rgb'],'edr_before':d['capture']['EDRBefore'],'capture_mode':d['capture']['captureMode'],'max_span':max(x['patchSpan'] for row in s for x in row),'capture':d['uuid']}
for i,(app,_) in enumerate(plot):
 cx=77+i*128;cy=458
 parts += [f'<path d="M {cx} {cy} H {cx+19}" stroke="{palette[app]}" stroke-width="3"/>',tx(labels[app],cx+26,463,palette[app],12)]
parts += [tx('最大 RGB 差以 '+labels[plot[0][0]]+' 为参照 · 窗口截图，不是光度计读数。',57,495,'#475569',13),'</g></svg>']
Path('window-output/sdr-video-foreground.svg').write_text(''.join(parts)+'\n')
Path('window-output/sdr-video-foreground-summary.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False)+'\n')
print(json.dumps(summary,indent=2,ensure_ascii=False))
