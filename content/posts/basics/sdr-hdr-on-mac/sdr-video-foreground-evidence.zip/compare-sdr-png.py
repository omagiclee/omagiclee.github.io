import argparse,sys,json,subprocess,struct,zlib,hashlib
from pathlib import Path
import numpy as np
from importlib.util import spec_from_file_location,module_from_spec
sp=spec_from_file_location("sampler","locate-window-sdr.py");sampler=module_from_spec(sp);sp.loader.exec_module(sampler)
p=argparse.ArgumentParser()
p.add_argument('base',nargs='+');a=p.parse_args()
for b in a.base:
 m=json.loads(Path(b+'.json').read_text())
 w,h=int(m['width']),int(m['height'])
 png=Path(b+'.png').read_bytes()
 assert png[24] == 16 and png[25] in (2,6)
 assert struct.unpack_from('>II',png,16)==(w,h)
 profile=cicp=None
 pos=8
 while pos+12<=len(png):
  n,key=struct.unpack_from('>I4s',png,pos)
  payload=png[pos+8:pos+8+n]
  if key==b'iCCP':
   profile_name,raw=payload.split(b'\0',1)
   profile={'name':profile_name.decode(),'sha256':hashlib.sha256(zlib.decompress(raw[1:])).hexdigest()}
  if key==b'cICP':cicp=list(payload)
  pos+=12+n
 if not profile or profile['name']!='kCGColorSpaceDisplayP3':
   raise RuntimeError('The measured output is not known Display P3')
 if cicp is not None and cicp != [12,13,0,1]:
   raise RuntimeError(f'Unexpected cICP: {cicp}')
 m.update(dict(hdrCompanionMode=m['captureMode'],captureMode='ScreenCaptureKit SDR PNG',pngICC=profile,pngCICP=cicp))
 rgb=np.frombuffer(subprocess.check_output(['ffmpeg','-v','error','-i',b+'.png','-f','rawvideo','-pix_fmt','rgb48le','-']),dtype='<u2').reshape(h,w,3).astype(np.float32)/65535
 rgb=np.where(rgb<.04045,rgb/12.92,((rgb+.055)/1.055)**2.4)
 rect=sampler.locate(rgb)
 v=sampler.sample(rgb,rect)
 print(Path(b).name,m['captureMode'],[x['Y'] for x in [v[0][0],v[0][7],v[1][3],v[1][5],v[1][7]]])
 dest=Path('window-output')/(Path(b).name+'-sdrpng.json')
 dest.write_text(json.dumps({'rect':rect,'uuid':Path(b).name+'-sdrpng','capture':m,'samples':v},indent=2)+'\n')
