import json
from pathlib import Path
test=[
('Chrome · SDR PNG','chrome-sdr-video-sdrpng.json','#215ac0'),
('Safari · SDR PNG','safari-sdr-video-sdrpng.json','#238173'),
('Chrome · HDR stream preset','chrome-sdr-video.json','#7b51a8'),
('Safari · HDR local screenshot','safari-sdr-video.json','#c44c40')
]
W,H=810,309
out=[f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {W} {H}" role="img" aria-labelledby="title"><title id="title">同一个 SDR 视频，采用不同截图输出会造成虚假的应用差异</title><rect width="{W}" height="{H}" rx="15" fill="#f8fafc"/><g font-family="system-ui, sans-serif" font-size="15" fill="#0f172a"><text x="28" y="31" font-size="20" font-weight="650">先统一截图输出，再比较应用</text><text x="28" y="55" font-size="13" fill="#475569">同一 BT.709 视频，源中灰 Y′126 · 线性亮度 Y，白约 1.0（不是 nit）</text>']
for i,(label,f,c) in enumerate(test):
    d=json.loads((Path('window-output')/f).read_text())
    y=d['samples'][1][3]['Y']; r=81+i*47
    out.append(f'<text x="28" y="{r+17}" fill="{c}">{label}</text><rect x="291" y="{r}" width="{470*y/.3:.1f}" height="21" rx="5" fill="{c}"/><text x="{301+470*y/.3:.1f}" y="{r+16}" font-family="ui-monospace,monospace">{y:.4f}</text>')
out.append('<text x="28" y="285" fill="#475569" font-size="13">下方是两种不同的 HDR 捕获输出，不用于应用之间的 SDR 主对照。</text></g></svg>')
Path('window-output/sdr-capture-output-control.svg').write_text(''.join(out)+'\n')
