import json,sys,math
import numpy as np
src=json.load(open('source-measurements.json'))['sdr709.mp4']
tests={}
for filename in sys.argv[1:]:
 d=json.load(open(filename));s=d['samples']
 y=np.array([s[p['row']][p['column']]['Y'] for p in src['patches'] if p['row']<2])
 x=np.array([(p['decoded_ycbcr'][0]-16)/219 for p in src['patches'] if p['row']<2])
 level_base_y=float(y[0]);level_white_y=float(y[-1])
 y=(y-level_base_y)/(level_white_y-level_base_y)
 models={'gamma1961':x**1.961,'gamma24':x**2.4,'sRGB':np.where(x<=.04045,x/12.92,((x+.055)/1.055)**2.4),
 'inverse709':np.where(x<.081,x/4.5,((x+.099)/1.099)**(1/.45))}
 use=(x>.10)&(x<.91)
 gamma=np.dot(np.log(x[use]),np.log(y[use]))/np.dot(np.log(x[use]),np.log(x[use]))
 rms={k:float(np.mean((v-y)**2)**.5) for k,v in models.items()}
 tests[d['uuid']]={'gamma_log_fit':float(gamma),'rms_errors':rms,'white':level_white_y,'black':level_base_y}
 print(d['uuid'], json.dumps(tests[d['uuid']]),flush=True)
open('window-output/fit-sdr-video-'+('sdrpng' if all('sdrpng' in x for x in tests) else 'half16')+'.json','w').write(json.dumps(tests,indent=2)+'\n')
