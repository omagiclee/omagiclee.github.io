import json,sys
from pathlib import Path
from xml.sax.saxutils import escape
import numpy as np
appnames={'chrome':'Chrome','safari':'Safari','qtp':'QuickTime Player','photos':'照片'}
cs=np.array([[1.22494,-.22494,0],[-.042056,1.042056,0],[-.019638,-.078636,1.098274]])
def convert(a):
    v=np.clip(cs@np.asarray(a),0,1)
    e=np.where(v<=.0031308,12.92*v,1.055*v**(1/2.4)-.055)
    return '#%02x%02x%02x'%tuple(np.round(255*e).astype(int))
names=[]
for p in sys.argv[1:]:
 d=json.load(open(p));names.append((appnames[d['uuid'].split('-')[0]],d['samples']))
cols=min(2,len(names));rows=(len(names)+cols-1)//cols
w=820 if cols==2 else 450
h=75+rows*235+30
out=[f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {w} {h}" role="img" aria-labelledby="title"><title id="title">相同 SDR 视频片在前台应用取样的色块重建</title><rect width="{w}" height="{h}" rx="16" fill="#f1f5f9"/><g font-family="system-ui, sans-serif" fill="#1e293b"><text x="32" y="32" font-size="21" font-weight="650">同一 SDR 视频的前台色块</text><text x="32" y="58" font-size="14">由实际窗口 32 个中心取样重绘为 sRGB，非原窗口截图</text>']
for i,(name,patches) in enumerate(names):
 x=32+i%cols*390;y=89+i//cols*235
 out.append(f'<text x="{x}" y="{y+15}" font-size="16" font-weight="650">{escape(name)}</text>')
 Y=y+30
 for r,row in enumerate(patches):
  for c,item in enumerate(row):
   out.append(f'<rect x="{x+c*45}" y="{Y+r*45}" width="45" height="45" fill="{convert(item["rgb"])}"/>')
out.append('</g></svg>')
Path('window-output/sdr-video-appearance-panels.svg').write_text(''.join(out)+'\n')
