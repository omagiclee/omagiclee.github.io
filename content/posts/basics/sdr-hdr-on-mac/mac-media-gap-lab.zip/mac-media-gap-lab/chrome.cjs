const {chromium}=require(process.env.PLAYWRIGHT_PATH||'playwright');
const {createServer}=require('node:http');
const {readFile}=require('node:fs/promises');
const path=require('node:path');
const fs=require('node:fs');
const { execFile }=require('node:child_process');
const types={'.html':'text/html','.jpg':'image/jpeg','.png':'image/png','.avif':'image/avif','.heic':'image/heic','.mp4':'video/mp4'};
const server=createServer(async(req,res)=>{
 const filename=path.basename(new URL(req.url,'http://localhost').pathname);
 try{
  const data=await readFile(path.join(__dirname,filename));const type=types[path.extname(filename)]||'application/octet-stream';
  const m=/^bytes=(\d+)-(\d*)$/.exec(req.headers.range??'');
  if(m){
   const start=+m[1],end=m[2]?Math.min(+m[2],data.length-1):data.length-1;
   if(start>end){res.writeHead(416,{'Content-Range':'bytes */'+data.length});return res.end();}
   res.writeHead(206,{'Content-Type':type,'Accept-Ranges':'bytes','Content-Range':'bytes '+start+'-'+end+'/'+data.length,'Content-Length':end-start+1});return res.end(data.subarray(start,end+1));
  }
  res.writeHead(200,{'Content-Type':type,'Accept-Ranges':'bytes','Content-Length':data.length});res.end(data);
 }catch{res.writeHead(404);res.end();}
});
(async()=>{
  let browser;
  try{
   await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(0,'127.0.0.1',resolve);});
   const url='http://127.0.0.1:'+server.address().port+'/bench.html';
   const wk = process.argv[3] ? new Promise(resolve=>execFile(process.argv[3],[url],(error,stdout)=>{if(error){console.error(error.message);process.exitCode=1;}fs.writeFileSync('webkit-http.json',stdout);resolve()})) : Promise.resolve();
   browser=await chromium.launch({executablePath:process.argv[2],headless:true});
   const page=await browser.newPage({viewport:{width:1100,height:850}});
   await page.goto(url);
   const result=await page.evaluate(()=>window.bench);
   console.log(JSON.stringify({browserVersion:browser.version(),...result},null,2));
   await wk;
  }catch(error){console.error(error);process.exitCode=1}
  finally{await browser?.close();server.close()}
})();
