import AppKit
import CoreImage
import CoreGraphics
import ImageIO
import UniformTypeIdentifiers

let dir = URL(fileURLWithPath: CommandLine.arguments[1], isDirectory: true)
let n = 512, m = 256
let linear = CGColorSpace(name: CGColorSpace.extendedLinearDisplayP3)!
let p3 = CGColorSpace(name: CGColorSpace.displayP3)!
let pq = CGColorSpace(name: CGColorSpace.displayP3_PQ)!
let ctx = CIContext(options: [.workingColorSpace: linear, .useSoftwareRenderer: true])
let colors: [(Float, Float, Float)] = [(0.18, 0.18, 0.18), (0.50, 0.50, 0.50), (1,1,1), (1.5,1.5,1.5), (2,2,2), (4,4,4), (2,0.35,0.16), (0.25,1.5,0.45)]
func make(_ hdr: Bool) -> CIImage {
    var values: [Float] = []
    for y in 0..<m {
        for x in 0..<n {
            let (a,b,c) = colors[x/64]
            let v: Float = y > 220 ? 0.08 : 1
            values += [min(a * v, hdr ? 4 : 1), min(b * v, hdr ? 4 : 1), min(c * v, hdr ? 4 : 1), 1]
        }
    }
    let data = values.withUnsafeBytes { Data($0) }
    let img = CIImage(bitmapData: data, bytesPerRow: n * 16, size: CGSize(width:n,height:m), format:.RGBAf, colorSpace:linear)
    return hdr ? img.settingContentHeadroom(4) : img
}
let hdr = make(true), sdr = make(false)
func out(_ name: String) -> URL { dir.appendingPathComponent(name) }
try ctx.writeJPEGRepresentation(of:sdr,to:out("sdr.jpg"),colorSpace:p3,options:[:])
try ctx.writeJPEGRepresentation(of:sdr,to:out("gain-map.jpg"),colorSpace:p3,options:[.hdrImage:hdr,.hdrGainMapAsRGB:true])
try ctx.writeHEIFRepresentation(of:sdr,to:out("gain-map.heic"),format:.RGBA8,colorSpace:p3,options:[.hdrImage:hdr,.hdrGainMapAsRGB:true])
try ctx.writePNGRepresentation(of:hdr,to:out("pq.png"),format:.RGBA16,colorSpace:pq,options:[:])
try ctx.writeHEIF10Representation(of:hdr,to:out("pq.heic"),colorSpace:pq,options:[:])
