# macOS SDR / HDR：格式与播放复验包

## 范围

这些是人为生成的灰阶和彩条，不包含任何个人照片、显示器截图、浏览器资料或图库内容。记录于 2026-11-26，macOS 27.2 (26B123)，Chrome for Testing Stable 158.0.8127.88，系统 WebKit 对应 Safari 27.2。与另一份 Safari/预览 HDR 截图实验分开。

- bench.html：共享的 img / video 测试页。图片成功要求 decode() 与有效尺寸；视频成功要求 play()、解码尺寸与时钟前进。totalVideoFrames（显示与丢弃的帧合计）单列，不代表实际屏幕呈现。
- chrome.cjs：绑定随机端口的本地文件 HTTP 服务，测试 Chrome 的独立无头实例，并可把同一个 URL 交给 WKWebView。需 Node.js / Playwright，可用 PLAYWRIGHT_PATH 指定现有 Playwright 模块。
- wk.swift：使用临时非持久数据存储和独立后台窗口。它不是 Safari.app。videoDynamicRangeHigh、时钟、帧计数互不替代；此处 WKWebView 时钟前进但totalVideoFrames 为 0。
- native.swift：ImageIO 的默认/显式 HDR 解码，以及 AVFoundation 读轨并检查首帧的颜色附件。统一请求 x420 方便检查，不等于源帧都是 10-bit。色彩空间显示 unnamed 是 CGColorSpace 未报告名字，不能推断文件没有色彩标记。contentHeadroom 不是测得的出光。
- make-fixtures.py：Python 3、带 libx264 / libx265 / libsvtav1 的 FFmpeg。生成一个 sRGB PNG、一个带系统 Display P3 ICC 的 SDR PNG、PQ／HLG 灰阶与三份 MP4。两种 HDR 灰阶用 0/25/100/203/400/1000 的设计值作为输入。HLG 的转换按 1000 nit 和 1.2 的系统 gamma 生成中性输入码值。
- generate-p3.swift：Core Image 生成原始 P3 取样图，直接运行时指定输出目录。附有预先生成的 SDR JPEG、PQ HEIC 和增益图 JPEG／HEIC；它也能生成另一份用于同窗实验的 P3 PQ PNG。
- chrome.json、webkit-http.json、native.txt、ffprobe-first-frame.txt：实际读数。SHA256SUMS 仅针对包内交付样片。解码结果不能推导实际的 HDR 峰值或色准。

## 复核

在解压后的文件夹运行。传给 Node.js 的参数为实际安装或解压得到的 Chrome for Testing 可执行文件，不需要替换日常使用的 Chrome。不装 Playwright 时，可以先只跑原生探针。

    swiftc wk.swift -o wk
    swiftc -parse-as-library native.swift -o native
    node chrome.cjs '/path/to/Google Chrome for Testing.app/Contents/MacOS/Google Chrome for Testing' "$PWD/wk"
    ./native sdr.jpg sdr-srgb.png sdr-p3.png pq-bt2020.png hlg-bt2020.png hlg-bt2020.avif gain-map.jpg gain-map.heic pq.heic sdr-709.mp4 pq-bt2020.mp4 hlg-bt2020.mp4
    shasum -a 256 -c SHA256SUMS

Chrome 结果输出到标准输出，WKWebView 结果写到 webkit-http.json；若要保留原始记录，可先复制结果或在新的解压目录中跑。应用显示链路、HDR 色差和系统截图的检验步骤见博客及另一份 Safari／预览实验附件。
