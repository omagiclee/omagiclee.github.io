import AppKit
import WebKit
import Foundation

let argument=CommandLine.arguments[1]
let url=argument.hasPrefix("http://") ? URL(string:argument)! : URL(fileURLWithPath:argument)
let app=NSApplication.shared
app.setActivationPolicy(.accessory)
let settings=WKWebViewConfiguration()
settings.websiteDataStore = .nonPersistent()
settings.mediaTypesRequiringUserActionForPlayback=[]
let view=WKWebView(frame:NSRect(x:0,y:0,width:1100,height:850),configuration:settings)
let window=NSWindow(contentRect:view.frame,styleMask:[.titled,.closable],backing:.buffered,defer:false)
window.title="Isolated SDR HDR media probe"
window.contentView=view
window.orderBack(nil)
@MainActor final class Probe:NSObject,WKNavigationDelegate {
    func webView(_ w:WKWebView,didFinish navigation:WKNavigation!) {
        Task{@MainActor in
            do {
                let x=try await w.callAsyncJavaScript("return await window.bench",arguments:[:],in:nil,contentWorld:.page)
                if let x, let d=try? JSONSerialization.data(withJSONObject:x,options:[.prettyPrinted,.sortedKeys]),let s=String(data:d,encoding:.utf8){print(s);exit(0)}
                print("no JSON",String(describing:x));exit(1)
            }catch{print(error);exit(1)}
        }
    }
}
let probe=MainActor.assumeIsolated{Probe()}
view.navigationDelegate=probe
if url.isFileURL { view.loadFileURL(url,allowingReadAccessTo:url.deletingLastPathComponent()) }
else { view.load(URLRequest(url:url)) }
DispatchQueue.main.asyncAfter(deadline:.now()+24){print("timed out");exit(2)}
app.run()
