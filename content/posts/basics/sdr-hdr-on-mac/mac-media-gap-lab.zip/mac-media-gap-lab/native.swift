import Foundation
import ImageIO
import CoreImage
import AVFoundation
import CoreVideo
import UniformTypeIdentifiers

func nativeImage(_ name: String, _ url: URL) {
    guard let source = CGImageSourceCreateWithURL(url as CFURL,nil) else { print("\(name): no source"); return }
    for (key, opt) in [("default", [:]), ("HDR", [kCGImageSourceDecodeRequest:kCGImageSourceDecodeToHDR] as [CFString:CFString])] {
        guard let image = CGImageSourceCreateImageAtIndex(source,0,opt as CFDictionary) else { print("\(name) \(key): no image"); continue }
        print("\(name) \(key):",CGImageSourceGetType(source) as String? ?? "",image.bitsPerComponent,image.colorSpace?.name as String? ?? "unnamed",String(format:"contentHeadroom=%.4f",image.contentHeadroom))
    }
}
func ext(_ dict: CFDictionary?, _ key: CFString) -> String {
    ((dict as? [String:Any])?[key as String]).map {String(describing:$0)} ?? "(none)"
}
func nativeVideo(_ name: String, _ url: URL) async {
    let asset = AVURLAsset(url:url)
    do {
        let playable = try await asset.load(.isPlayable)
        guard let track = try await asset.loadTracks(withMediaType:.video).first else { print("\(name) playable=\(playable) no video track"); return }
        let fmt = try await track.load(.formatDescriptions).first
        let keys = [kCVImageBufferColorPrimariesKey,kCVImageBufferTransferFunctionKey,kCVImageBufferYCbCrMatrixKey]
        let desc = fmt.map { CMFormatDescriptionGetExtensions($0) } ?? nil
        let color = keys.map { ext(desc, $0) }
        let hdr = track.hasMediaCharacteristic(.containsHDRVideo)
        print("\(name) playable=\(playable) HDR-track=\(hdr) format=\(color)")
        let reader = try AVAssetReader(asset:asset)
        let out = AVAssetReaderTrackOutput(track:track,outputSettings:[kCVPixelBufferPixelFormatTypeKey as String:kCVPixelFormatType_420YpCbCr10BiPlanarVideoRange])
        guard reader.canAdd(out) else { print("  no reader output"); return }
        reader.add(out)
        guard reader.startReading(), let sample = out.copyNextSampleBuffer(), let pixel = CMSampleBufferGetImageBuffer(sample) else { print("  no decoded frame",String(describing:reader.error)); return }
        let data = CVBufferCopyAttachments(pixel,.shouldPropagate)
        let width = CVPixelBufferGetWidth(pixel)
        let height = CVPixelBufferGetHeight(pixel)
        print("  decoded \(width)x\(height), requested x420, frame attachments:",keys.map{ext(data,$0)})
        reader.cancelReading()
    } catch { print("\(name) \(error)") }
}
@main struct Main {
    static func main() async {
        for name in CommandLine.arguments.dropFirst() {
            let url=URL(fileURLWithPath:name)
            if url.pathExtension=="mp4" { await nativeVideo(name,url) }
            else { nativeImage(name,url) }
        }
    }
}
