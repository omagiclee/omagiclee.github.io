import binascii, math, struct, subprocess, zlib
from pathlib import Path

def chunk(typ,data):
    return struct.pack('>I',len(data))+typ+data+struct.pack('>I',binascii.crc32(typ+data))
def quant(x):
    return round(max(0,min(1,x))*65535)
def pq(n):
    p=(n/10000)**(2610/16384)
    return ((3424/4096+(2413/128)*p)/(1+(2392/128)*p))**(2523/32)
def hlg(n):
    e=(n/1000)**(1/1.2)
    a=0.17883277
    return math.sqrt(3*e) if e<=1/12 else a*math.log(12*e-(1-4*a))+0.5-a*math.log(4*a)
def srgb(e):
    return 12.92*e if e<=0.0031308 else 1.055*e**(1/2.4)-0.055
def bt709(e):
    return 4.5*e if e<0.018 else 1.099*e**0.45-0.099
def png(path,clrs,prim,trc,fn,icc=None):
    w,h=640,360
    line=b''.join(struct.pack('>HHH',*(quant(fn(v)) for v in c))*80 for c in clrs)
    tag=chunk(b'cICP',bytes([prim,trc,0,1]))
    if icc:
        tag=chunk(b'iCCP',b'Display P3\0\0'+zlib.compress(Path(icc).read_bytes()))
    Path(path).write_bytes(b'\x89PNG\r\n\x1a\n'+chunk(b'IHDR',struct.pack('>IIBBBBB',w,h,16,2,0,0,0))+tag+chunk(b'IDAT',zlib.compress((b'\0'+line)*h))+chunk(b'IEND',b''))
def ff(*args):
    subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y',*args],check=True,stdout=subprocess.DEVNULL)
sd=[(x,x,x) for x in [0,.05,.18,.5,.75,1]]+[(.8,.15,.09),(.1,.7,.2)]
hdr=[(x,x,x) for x in [0,25,100,203,400,1000]]+[(203,203,203),(100,100,100)]
png('sdr-srgb.png',sd,1,13,srgb)
png('sdr-p3.png',sd,12,13,srgb,'/System/Library/ColorSync/Profiles/Display P3.icc')
png('sdr-709-input.png',sd,1,1,bt709)
png('pq-bt2020.png',hdr,9,16,pq)
png('hlg-bt2020.png',hdr,9,18,hlg)
ff('-i','hlg-bt2020.png','-vf','scale=in_range=full:out_range=limited:out_color_matrix=bt2020','-pix_fmt','yuv420p10le','-c:v','libsvtav1','-preset','12','-svtav1-params','lp=2:log-level=1','-color_range','tv','-color_primaries','bt2020','-color_trc','arib-std-b67','-colorspace','bt2020nc','-frames:v','1','hlg-bt2020.avif')
for stem,img,trc,mat,prim,codec,pix in [
        ('sdr-709','sdr-709-input.png','bt709','bt709','bt709','libx264','yuv420p'),
        ('pq-bt2020','pq-bt2020.png','smpte2084','bt2020nc','bt2020','libx265','yuv420p10le'),
        ('hlg-bt2020','hlg-bt2020.png','arib-std-b67','bt2020nc','bt2020','libx265','yuv420p10le')]:
    extra=[]
    if codec=='libx265':
        params='pools=2:frame-threads=2:log-level=error'
        if trc=='smpte2084':
            params+=':hdr10=1:master-display=G(8500,39850)B(6550,2300)R(35400,14600)WP(15635,16450)L(10000000,50):max-cll=1000,300'
        extra=['-tag:v','hvc1','-x265-params',params]
    ff('-loop','1','-framerate','24','-i',img,'-t','2','-vf','scale=in_range=full:out_range=limited:out_color_matrix='+('bt709' if mat=='bt709' else 'bt2020'),'-pix_fmt',pix,'-c:v',codec,'-color_range','tv','-color_primaries',prim,'-color_trc',trc,'-colorspace',mat,*extra,'-movflags','+faststart+write_colr',stem+'.mp4')
