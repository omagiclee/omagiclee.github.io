# macOS SDR 照片｜ICC 控制组

这是由代码生成的 768×512 色板，六列四行。色板、记录与自行生成的 ICC 可按 CC0 1.0 公开复用。没有嵌入苹果系统 ICC，也不含真实照片、文件路径、账户、桌面截图或个人数据。生成脚本运行需要 Python 3、FFmpeg（JPEG）和 LittleCMS 2（自制的 ICC 已附带，按需重建）。

| 样片 | 改动 | 预期 |
| --- | --- | --- |
| fixture-sRGB-reference | sRGB ICC | SDR 参考 |
| fixture-p3-matched | RGB 已换算到 P3，再嵌 Display P3 ICC | 在 sRGB 可表达范围内，色彩应与参考近似 |
| fixture-p3-gamut | 不改参考图 RGB 码字，换 Display P3 ICC | 因坐标基准不同，颜色改变，部分颜色超出 sRGB |
| fixture-p3-untagged | 同 gamut 图像字节，移除 ICC | 浏览器按 sRGB 解释，和参考图接近 |

PNG 保证无损。JPEG 的三份参考／gamut／untagged 源解码数据只更换 ICC，避免让 JPEG 编码变化自行解释结果；匹配 P3 的矩阵正控制要重算字节，因此仍可能有量化差异。

## 离屏复验

使用全新无头 Chrome，通过 --force-color-profile=srgb 固定截图输出空间。系统 WKWebView 无窗口 takeSnapshot 自带 sRGB ICC。两者都是离屏绘制、不是实际应用窗口的合成取样。readings 下为这两条路径的色块数据。sRGB 输出会截断超出 sRGB 的颜色，不能将照片真实设备的宽色域表现外推于此。

## 真机采样

用同一显示器、同一系统显示配置和同一份文件。优先比较各 App 中独立前台单图，避免在整个窗口拖动缩放后比较缩略图。记录 app/版本、显示器/ICC、窗口是否在前台、样片哈希。Chrome/Safari 只测同一极简 HTML 的标准 img，不用 Canvas。照片用隔离图库和实际单图查看，不测缩略图。QuickTime Player 不作为通用静态照片入口。

用同一输出模式捕获测试区域，保留系统输出颜色标签。独立采样命令约定截图左上角为原点，left top width height 全部是截图像素坐标。优先只截图色板矩形，便可省略四参数。第 1 排黑到白和第 3 排红绿蓝青紫黄有助定位矩形。取样每格中心 11×11、每通道取中位数。统一转换到扩展线性 Display P3，其中 SDR 参考白通常为 1。如果截图自身是向 sRGB 限幅的端点，不可据其反推显示器之外或本应更宽的色域。该方法测应用/系统截图信号，不是用光度计测屏幕物理亮度。

    swiftc locate.swift -o locate
    ./locate screenshot.png  # 可选，自动定位四边，其余画面忽略
    swiftc sample.swift -o sample
    ./sample screenshot.png 20 30 768 512 > sampled.json
    python3 compare.py baseline.json candidate.json ...

如用显示 EDR 的 HEIC 捕获，应先核对参考灰/白、待机、刷新和前后台状态一致。在报告中标注离屏截图、系统合成截图及实际光度测量的层级。
