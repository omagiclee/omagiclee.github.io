/* Creates independently generated ICC matrix profiles from standard primaries. */
#include <lcms2.h>
#include <stdio.h>

static int label(cmsHPROFILE profile, cmsTagSignature tag, const char *value) {
    cmsMLU *mlu = cmsMLUalloc(NULL, 1);
    if (!mlu) return 0;
    int ok = cmsMLUsetASCII(mlu, "en", "US", value) && cmsWriteTag(profile,tag,mlu);
    cmsMLUfree(mlu);
    return ok;
}

static int make(const cmsCIExyYTRIPLE *colors, const char *file, const char *desc) {
    const cmsCIExyY white = {0.3127,0.3290,1};
    const double params[] = {2.4, 1.0/1.055, 0.055/1.055, 1.0/12.92, 0.04045};
    cmsToneCurve *curve = cmsBuildParametricToneCurve(NULL,4,params);
    if (!curve) return 0;
    cmsToneCurve *curves[] = {curve,curve,curve};
    cmsHPROFILE profile = cmsCreateRGBProfile(&white,colors,curves);
    cmsFreeToneCurve(curve);
    if (!profile) return 0;
    cmsSetHeaderRenderingIntent(profile,INTENT_RELATIVE_COLORIMETRIC);
    int ok=label(profile,cmsSigProfileDescriptionTag,desc) &&
           label(profile,cmsSigCopyrightTag,"Synthetic test ICC profile, CC0 1.0") &&
           cmsSaveProfileToFile(profile,file);
    cmsCloseProfile(profile);
    return ok;
}

int main(void) {
    const cmsCIExyYTRIPLE srgb = {{0.640,0.330,1},{0.300,0.600,1},{0.150,0.060,1}};
    const cmsCIExyYTRIPLE p3 = {{0.680,0.320,1},{0.265,0.690,1},{0.150,0.060,1}};
    return ! (make(&srgb,"sRGB-generated.icc","Synthetic SDR sRGB D65") &&
              make(&p3,"DisplayP3-generated.icc","Synthetic SDR Display P3 D65"));
}
