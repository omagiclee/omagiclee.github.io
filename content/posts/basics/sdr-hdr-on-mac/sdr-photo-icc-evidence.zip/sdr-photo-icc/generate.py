#!/usr/bin/env python3
"""SDR synthetic fixture generator. No third-party image inputs."""
import hashlib, json, pathlib, struct, subprocess, sys, zlib
p=pathlib.Path(__file__).parent
srgb=(p/'sRGB-generated.icc').read_bytes()
p3=(p/'DisplayP3-generated.icc').read_bytes()
w,h=768,512
ncols,nrows=6,4
names=['black','gray_32','gray_64','gray_128','gray_192','white',
       'skin_light','skin_dark','blue_sky','leaf','deep_orange','navy',
       'red','green','blue','cyan','magenta','yellow',
       'red_orange','bright_green','purple','blue_green','warm_gray','cool_gray']
colors=[(x,x,x) for x in [0,32,64,128,192,255]]+[(222,168,138),(119,76,62),(100,168,218),(77,133,59),(234,110,31),(32,61,108),(255,0,0),(0,255,0),(0,0,255),(0,255,255),(255,0,255),(255,255,0),(255,59,0),(68,255,0),(180,0,248),(2,218,180),(141,133,127),(119,133,146)]
def lin(v):
    v=v/255
    return v/12.92 if v<=.04045 else ((v+.055)/1.055)**2.4
def enc(v):
    v=12.92*v if v<=.0031308 else 1.055*(v**(1/2.4))-.055
    return min(255,max(0,round(v*255)))
# sRGB to Display P3 in linear light via D65-adjusted XYZ matrices (CSS Color 4).
matrix=[[0.82246197,0.17753803,0],[0.03319420,0.96680580,0],[0.01708263,0.07239744,0.91051993]]
match=[tuple(enc(sum(a*lin(q) for a,q in zip(row,c))) for row in matrix) for c in colors]
def rgb_bytes(table):
    stride=w//ncols
    return b''.join(bytes(table[j*ncols+k])*stride for j in range(nrows) for _ in range(h//nrows) for k in range(ncols))
def chunk(kind,data):
    return struct.pack('>I',len(data))+kind+data+struct.pack('>I',zlib.crc32(kind+data))
def png(name, pixels, tag, label):
    dest=p/name
    iccp=chunk(b'iCCP',label+b'\x00\x00'+zlib.compress(tag)) if tag else b''
    ident=chunk(b'IHDR', struct.pack('>IIBBBBB',w,h,8,2,0,0,0))
    comp=chunk(b'IDAT', zlib.compress(b''.join(b'\x00'+pixels[j:j+w*3] for j in range(0,len(pixels),w*3)),9))
    dest.write_bytes(b'\x89PNG\r\n\x1a\n'+ident+iccp+comp+chunk(b'IEND',b''))
def jpeg_bytes(pixels):
    return subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-f','rawvideo','-pix_fmt','rgb24','-s',f'{w}x{h}','-i','pipe:0','-frames:v','1','-pix_fmt','yuvj444p','-c:v','mjpeg','-q:v','1','-f','image2pipe','pipe:1'],input=pixels,capture_output=True,check=True).stdout
def jpeg(name, data, tag):
    if tag:
       payload=b'ICC_PROFILE\x00\x01\x01'+tag
       data=data[:2]+b'\xff\xe2'+struct.pack('>H',len(payload)+2)+payload+data[2:]
    (p/name).write_bytes(data)
base=rgb_bytes(colors)
matched=rgb_bytes(match)
pname='fixture'
variants=[
 ('sRGB-reference',base,srgb,b'sRGB','matched reference, sRGB ICC'),
 ('p3-matched',matched,p3,b'Display P3','matched appearance; P3 ICC and converted RGB, not same bytes'),
 ('p3-gamut',base,p3,b'Display P3','same pixel bytes as sRGB reference, correct P3 tag, purposely wider reds/greens'),
 ('p3-untagged',base,None,b'','same pixel bytes as P3 gamut, ICC removed'),
]
files={}
encoded={id(src):jpeg_bytes(src) for src in (base,matched)}
for stem, pixels, tag, label, purpose in variants:
    for ext in ('png','jpg'):
        name=f'{pname}-{stem}.{ext}'
        if ext=='png':png(name,pixels,tag,label)
        else:jpeg(name,encoded[id(pixels)],tag)
        data=(p/name).read_bytes()
        files[name]={'sha256': hashlib.sha256(data).hexdigest(),'basis':purpose,'profile':label.decode() or None}
(p/'fixtures.json').write_text(json.dumps({'width':w,'height':h,'grid_cols':ncols,'grid_rows':nrows,'patches':[{'id':n,'srgb_rgb8':a,'matched_p3_rgb8':b} for n,a,b in zip(names, colors,match)],'files':files},indent=2, ensure_ascii=False)+'\n')
