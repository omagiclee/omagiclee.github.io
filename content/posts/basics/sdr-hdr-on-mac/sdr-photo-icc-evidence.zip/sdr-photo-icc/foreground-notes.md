# SDR 照片前台实验

Chrome 158.0.8127.88（独立 Chrome for Testing）、Safari 27.2 和「预览」11.0（1147.1.10）。macOS 27.2 26B123。每次置测试窗口为前台，仅截合成样片所在窗口，不接触个人照片。使用相同的两份合成 PNG，通过标准 img 或原生查看器分别显示。sRGB 与 P3 PNG 的 RGB 样板字节一致；只有 iCCP 标签不同。样片 SHA-256 验证在 fixtures.json。

- foreground/*.json 是系统 ScreenCaptureKit 截图或本地 HDR stream 帧转线性 Display P3 Float16 后，抽取 24 色块中心 11×11 的各通道中值；保留截图路径/版本边界，不保存完整截图、个人数据或窗口号。
- foreground-pairwise.json 计算所有色块最大 RGB 通道、灰阶 Y，以及差最大的色块。Y 由线性 Display P3 相对亮度矩阵计算，白色约 1.0。前景差值不能作为光度计 nit。
- foreground-deltae00.json 是 CIEDE2000 的辅助比较，以 D65 作为共同 Lab 白点，见 [Sharma/Wu/Dalal](https://www.hajim.rochester.edu/ece/sites/gsharma/ciede2000/)。不是参与者看见差异的统计阈值。
- P3 需要使用 Float16 取样。用于定位的 SDR 诊断 PNG 在极饱和绿、青色出现额外数值变化，不能作为定量显示来源。独立诊断 PNG 工具核对灰阶、RGB 控制的序列和裁框。
- Chrome 使用 HDR local stream preset，Safari 和「预览」使用 HDR local screenshot，因此前台多一个统一颜色的证据：十张诊断 SDR PNG 携带同一份 Display P3 ICC（SHA-256 0ff6958f98684c61f6bbdce1368ddeaf3873baf84545baba482e920d92a914c0）。sRGB 源以同 ICC PNG 为主，P3 源以 Float16 为主，保留两种读数。Safari 和预览各重复两种图，中心色块在同应用、同图、同输出类型的两轮完全一致。个别与 Safari 相关的小差在两种输出均复现，即使 Safari 当前 EDR 从 1.20 到 6.30 也一致。它不是 Float16 单步舍入或随机抓取波动。本实验还未孤立到解码器、CMM 或后续合成任一层。三个 App 灰阶最大差不超过约 0.00012。标签更改引起最大约 0.18 的对照差，在三个 App 均出现。
- QuickTime 不是通用静态图查看器，不纳入静态色差比对。若某应用没有前台取样，不用底层 ImageIO、WKWebView 或其他应用代填。
