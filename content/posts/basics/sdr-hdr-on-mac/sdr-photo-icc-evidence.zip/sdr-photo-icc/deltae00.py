"""Compute CIEDE2000 relative to the common linear Display P3 white."""
from math import sqrt, atan2, sin, cos, degrees, radians, hypot, exp
from pathlib import Path
import itertools,json

M = (
  (0.4865709486482162,0.265667693169093,0.1982172852343625),
  (0.2289745640697488,0.6917385218365064,0.079286914093745),
  (0.0,0.0451133818589026,1.043944368900976),
)
wp=tuple(sum(r) for r in M)
def lab(rgb):
 x,y,z=(sum(t*q for t,q in zip(r,rgb))/w for r,w in zip(M,wp))
 def f(t):
  delta=6/29
  return t**(1/3) if t>delta**3 else t/(3*delta**2)+4/29
 x,y,z=map(f,(x,y,z))
 return (116*y-16,500*(x-y),200*(y-z))
def delta(lab1,lab2):
 L1,a1,b1=lab1
 L2,a2,b2=lab2
 C1,C2=hypot(a1,b1),hypot(a2,b2)
 C=(C1+C2)/2
 G=.5*(1-sqrt(C**7/(C**7+25**7)))
 a1p,a2p=(1+G)*a1,(1+G)*a2
 c1,c2=hypot(a1p,b1),hypot(a2p,b2)
 h1,h2=(degrees(atan2(b,a))%360 if a or b else 0 for a,b in ((a1p,b1),(a2p,b2)))
 dL, dC=L2-L1,c2-c1
 d=h2-h1
 if c1*c2==0:d=0
 elif d>180:d-=360
 elif d<-180:d+=360
 dH=2*sqrt(c1*c2)*sin(radians(d/2))
 L,C=(L1+L2)/2,(c1+c2)/2
 if c1*c2==0:h=h1+h2
 elif abs(h1-h2)<=180:h=(h1+h2)/2
 elif h1+h2<360:h=(h1+h2+360)/2
 else:h=(h1+h2-360)/2
 T=1-.17*cos(radians(h-30))+.24*cos(radians(2*h))+.32*cos(radians(3*h+6))-.20*cos(radians(4*h-63))
 sL=1+.015*(L-50)**2/sqrt(20+(L-50)**2)
 sC=1+.045*C
 sH=1+.015*C*T
 rT=-2*sqrt(C**7/(C**7+25**7))*sin(radians(60*exp(-((h-275)/25)**2)))
 return sqrt((dL/sL)**2+(dC/sC)**2+(dH/sH)**2+rT*dC/sC*dH/sH)
def selftest():
 p=[( (50,2.6772,-79.7751), (50,0,-82.7485), 2.0425),
 ((50,3.1571,-77.2803),(50,0,-82.7485),2.8615),
 ((50,2.8361,-74.0200),(50,0,-82.7485),3.4412),
 ((50,-1.3802,-84.2814),(50,0,-82.7485),1.0000),
 ((50,-1.1848,-84.8006),(50,0,-82.7485),1.0000),
 ((50,-.9009,-85.5211),(50,0,-82.7485),1.0000)]
 for a,b,e in p:
  assert round(delta(a,b),4)==e
def data(path):
 return [lab(p['rgb']) for row in json.loads(path.read_text())['samples'] for p in row]
if __name__=='__main__':
 selftest()
 rows={}
 names=[i['id'] for i in json.loads(Path('public-fixtures/fixtures.json').read_text())['patches']]
 d=Path('foreground')
 groups={'sRGB':['chrome-sdr-srgb-main','safari-sdr-srgb-main','preview-sdr-srgb-front','photos-sdr-srgb'],
           'P3':['chrome-sdr-p3-main','safari-sdr-p3-main','preview-sdr-p3-main','photos-sdr-p3']}
 for col, f in groups.items():
  paths=[d/(p+'.json') for p in f if (d/(p+'.json')).exists()]
  rows[col]={}
  for a,b in itertools.combinations(paths,2):
   vals=sorted((delta(x,y),i) for i,(x,y) in enumerate(zip(data(a),data(b))))
   rows[col][a.stem+'/'+b.stem]={'max':round(vals[-1][0],6),'max_patch':names[vals[-1][1]],'median':round((vals[11][0]+vals[12][0])/2,6)}
 print(json.dumps(rows,indent=2,ensure_ascii=False))
