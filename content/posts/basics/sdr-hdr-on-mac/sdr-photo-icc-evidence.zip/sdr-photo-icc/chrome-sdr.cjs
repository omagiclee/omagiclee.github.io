const {chromium}=require(process.env.PLAYWRIGHT_PATH || 'playwright')
const path=require('path')
const fs=require('fs')
const {pathToFileURL}=require('url')
const cwd=process.cwd();
(async()=>{
 const choice=cwd+'/public-fixtures';
 let browser=await chromium.launch({executablePath:process.argv[2],headless:true,args:['--force-color-profile=srgb']});
 try {
  let results={browserVersion:browser.version(),capture:'headless Chromium page screenshot, forced sRGB output', fixtures:[]};
  const page=await browser.newPage({viewport:{width:900,height:620},deviceScaleFactor:1});
  fs.mkdirSync('chrome-sdr',{recursive:true});
  for (const ext of ['png','jpg']) for (const sample of ['sRGB-reference','p3-matched','p3-gamut','p3-untagged']) {
    let url=pathToFileURL(choice+'/board.html')
    url.searchParams.set('chart',sample)
    url.searchParams.set('ext',ext)
    await page.goto(url.href)
    let img=page.locator('img')
    await img.evaluate(async e=>await e.decode())
    let box=await img.boundingBox()
    let dest=`chrome-sdr/${sample}-${ext}.png`
    await img.screenshot({path:dest})
    results.fixtures.push({sample,ext,box,dest})
  }
  console.log(JSON.stringify(results,null,2));
 } finally { await browser.close() }
})().catch(e=>{console.error(e);process.exitCode=1})
