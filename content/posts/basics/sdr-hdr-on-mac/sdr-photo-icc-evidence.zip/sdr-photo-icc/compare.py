#!/usr/bin/env python3
"""Compare identical crop patch IDs using raw extended linear Display P3."""
import argparse
import json
import statistics
from pathlib import Path
arg=argparse.ArgumentParser(description=__doc__)
arg.add_argument('measurements',nargs='+',type=Path)
arg.add_argument('--json',action='store_true')
p=arg.parse_args()
if len(p.measurements)<2:arg.error('baseline and at least one candidate required')
def read(path):
    obj=json.loads(path.read_text())
    rows={r['id']:r['linearP3'] for r in obj['patches']}
    if any(len(row)!=3 for row in rows.values()):
        raise ValueError(f'{path} has invalid extended linear P3 triplets')
    return rows
base=read(p.measurements[0])
def summary(path):
    data=read(path)
    if set(data)!=set(base):raise ValueError(f'{path} patch IDs do not match baseline')
    values=[]
    gray=max((max(abs(x-y) for x,y in zip(base[n],data[n])) for n in base if n.startswith('gray') or n in ['white','black']),default=None)
    for n in base:
        values.append((max(abs(x-y) for x,y in zip(base[n],data[n])),n))
    values.sort()
    return {'sample_file':path.name,'patch_count':len(values),'median_patch_max_abs':statistics.median(v for v,_ in values),'max_abs':values[-1][0],'worst_patch':values[-1][1],'gray_max_abs':gray,'baseline_white':base['white'],'candidate_white':data['white'],'baseline_gray128':base['gray_128'],'candidate_gray128':data['gray_128']}
result=[summary(path) for path in p.measurements[1:]]
if p.json:
    print(json.dumps(result,ensure_ascii=False,indent=2))
else:
    print('候选文件\t色块数\t中位 Δ\t最大 Δ\t差异最明显色块\t灰阶最大 Δ')
    for r in result:
        print('{sample_file}\t{patch_count}\t{median_patch_max_abs:.6f}\t{max_abs:.6f}\t{worst_patch}\t{gray_max_abs:.6f}'.format(**r))
