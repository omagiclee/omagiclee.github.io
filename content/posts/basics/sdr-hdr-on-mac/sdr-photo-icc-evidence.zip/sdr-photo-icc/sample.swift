import Foundation
import CoreGraphics
import CoreImage
import ImageIO

let args = CommandLine.arguments
if args.count != 2 && args.count != 6 {
    fputs("usage: sample SCREENSHOT_OR_FIXTURE [left top width height]\n",stderr)
    exit(2)
}
let url=URL(fileURLWithPath:args[1])
guard let source=CGImageSourceCreateWithURL(url as CFURL,nil),
      let cg=CGImageSourceCreateImageAtIndex(source,0,[kCGImageSourceDecodeRequest:kCGImageSourceDecodeToHDR] as CFDictionary)
else { fputs("decode failed\n",stderr);exit(3) }
let w=cg.width, h=cg.height
let r=args.count==6 ? args.suffix(4).compactMap{Int($0)} : [0,0,w,h]
if r.count != 4 || r[0]<0 || r[1]<0 || r[2]<60 || r[3]<40 || r[0]+r[2]>w || r[1]+r[3]>h { fputs("invalid chart rect\n",stderr);exit(4) }
let names=["black","gray_32","gray_64","gray_128","gray_192","white",
       "skin_light","skin_dark","blue_sky","leaf","deep_orange","navy",
       "red","green","blue","cyan","magenta","yellow",
       "red_orange","bright_green","purple","blue_green","warm_gray","cool_gray"]
let rgb=CGColorSpace(name:CGColorSpace.extendedLinearDisplayP3)!
let srgb=CGColorSpace(name:CGColorSpace.extendedSRGB)!

func patch(_ xc:Int,_ yc:Int,_ target:CGColorSpace) -> [Double] {
   let side=11
   let rect=CGRect(x:xc-side/2,y:yc-side/2,width:side,height:side)
   guard let crop=cg.cropping(to:rect) else { fatalError("crop outside source") }
   var v = [Float](repeating: -99, count: side*side*4)
   v.withUnsafeMutableBytes { p in
      let flags=CGBitmapInfo.floatComponents.rawValue|CGBitmapInfo.byteOrder32Little.rawValue|CGImageAlphaInfo.premultipliedLast.rawValue
      guard let ctx=CGContext(data:p.baseAddress!,width:side,height:side,bitsPerComponent:32,bytesPerRow:side*16,space:target,bitmapInfo:flags) else { fatalError("cannot create float CGContext") }
      ctx.setBlendMode(.copy)
      ctx.setRenderingIntent(.relativeColorimetric)
      ctx.draw(crop,in:CGRect(x:0,y:0,width:side,height:side))
   }
   return (0..<3).map{c in
       let values=stride(from:c,to:v.count,by:4).map{v[$0]}.sorted()
       return Double(values[values.count/2])
   }
}
let report:[String:Any]=[
  "filename":url.lastPathComponent,
  "captureSize":[w,h],
  "chartRect":r,
  "colorSpace":cg.colorSpace?.name as String? ?? "(unnamed)",
  "contentHeadroom":cg.contentHeadroom,
  "patches":(0..<names.count).map{ i -> [String:Any] in
    let x=r[0]+(2*(i%6)+1)*r[2]/12
    let y=r[1]+(2*(i/6)+1)*r[3]/8
    return ["id":names[i],"xy":[x,y],"linearP3":patch(x,y,rgb),"sRGB":patch(x,y,srgb)]
  }
]
let values=try JSONSerialization.data(withJSONObject:report,options:[.prettyPrinted,.sortedKeys])
print(String(data:values,encoding:.utf8)!)
