import json,pathlib,itertools,numpy as np
p=pathlib.Path('foreground')
names=[i['id'] for i in json.loads(pathlib.Path('public-fixtures/fixtures.json').read_text())['patches']]
groups={
'sRGB':{'Chrome':'chrome-sdr-srgb-main','Safari':'safari-sdr-srgb-main','Preview':'preview-sdr-srgb-front','Photos':'photos-sdr-srgb'},
'P3':{'Chrome':'chrome-sdr-p3-main','Safari':'safari-sdr-p3-main','Preview':'preview-sdr-p3-main','Photos':'photos-sdr-p3'},
}
rows={}
for fixture,appfiles in groups.items():
 data={app:json.loads((p/(name+'.json')).read_text()) for app,name in appfiles.items() if (p/(name+'.json')).exists()}
 values={app:np.asarray([patch['rgb'] for row in payload['samples'] for patch in row]) for app,payload in data.items()}
 ys={app:np.asarray([patch['Y'] for row in payload['samples'] for patch in row]) for app,payload in data.items()}
 print('\n',fixture)
 rows[fixture]={}
 for app,payload in data.items():
  v=values[app]; y=ys[app]
  ss=np.asarray([patch['patchSpan'] for row in payload['samples'] for patch in row])
  print(app,'ref white:',v[5], 'Y gray128:',y[3],'red:',v[12],'green:',v[13], 'Deeporange:',v[10], 'max RGB sample ROI span:',np.max(ss))
 for a,b in itertools.combinations(data,2):
  d=np.abs(values[a]-values[b]);dy=np.abs(ys[a]-ys[b])
  i,j=np.unravel_index(np.argmax(d),d.shape)
  k=np.argmax(dy)
  med=np.median(np.max(d,axis=1))
  row={'max':round(float(d[i,j]),6),'max_patch':names[i],'channel':'RGB'[j],'median':round(float(med),6),'max_y':round(float(dy[k]),6),'max_y_patch':names[k],
  'max_delta_y_grays':round(float(np.max(dy[:6])),6),'delta_pair':[[round(float(z),6) for z in values[a][i]],[round(float(z),6) for z in values[b][i]]]}
  rows[fixture][a+'/'+b]=row
  print(a,b,row)
 print('Relative white normalized')
 for a,b in itertools.combinations(data,2):
  d=np.abs(values[a]/ys[a][5]-values[b]/ys[b][5]);dy=np.abs(ys[a]/ys[a][5]-ys[b]/ys[b][5])
  i,j=np.unravel_index(np.argmax(d),d.shape)
  print(a,b,round(float(d[i,j]),6),names[i],'RGB'[j],'Ymax',round(float(np.max(dy)),6))
if all('Chrome' in groups[g] for g in groups):
 for app,f in groups['sRGB'].items():
  try: s=json.loads((p/(f+'.json')).read_text()); u=json.loads((p/(groups['P3'][app]+'.json')).read_text())
  except FileNotFoundError:continue
  a,b=(np.asarray([patch['rgb'] for row in r['samples'] for patch in row]) for r in (s,u))
  d=np.abs(a-b)
  i,j=np.unravel_index(np.argmax(d),d.shape)
  print(app,'sRGB↔P3','max',d[i,j],names[i],'RGB'[j],'max gray',np.max(d[:6]),'red sRGB',a[12],'P3',b[12])
pathlib.Path('foreground-pairwise.json').write_text(json.dumps(rows,indent=2))
