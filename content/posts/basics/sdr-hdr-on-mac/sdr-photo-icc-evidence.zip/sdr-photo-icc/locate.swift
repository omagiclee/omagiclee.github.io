import Foundation
import CoreGraphics
import ImageIO

let url=URL(fileURLWithPath:CommandLine.arguments[1])
let src=CGImageSourceCreateWithURL(url as CFURL,nil)!
let img=CGImageSourceCreateImageAtIndex(src,0,nil)!
let w=img.width,h=img.height
var pixels=[UInt8](repeating:0,count:w*h*4)
pixels.withUnsafeMutableBytes { ptr in
    let info=CGImageAlphaInfo.premultipliedLast.rawValue|CGBitmapInfo.byteOrder32Big.rawValue
    let c=CGContext(data:ptr.baseAddress!,width:w,height:h,bitsPerComponent:8,bytesPerRow:w*4,
                    space:CGColorSpace(name:CGColorSpace.sRGB)!,bitmapInfo:info)!
    c.setBlendMode(.copy)
    c.draw(img,in:CGRect(x:0,y:0,width:w,height:h))
}
func rgb(_ x:Int,_ y:Int)-> (Int,Int,Int) {
    let i=(y*w+x)*4
    return (Int(pixels[i]),Int(pixels[i+1]),Int(pixels[i+2]))
}
func tag(_ x:Int,_ y:Int)->Int {
    let (r,g,b)=rgb(x,y)
    let maxp=max(r,g,b),minp=min(r,g,b)
    if maxp<140 || maxp-minp<58 {return 0}
    if r>g+60 && r>b+60 {return 1}
    if g>r+60 && g>b+60 {return 2}
    if b>r+60 && b>g+60 {return 3}
    if g>r+47 && b>r+47 {return 4}
    if r>g+47 && b>g+47 {return 5}
    if r>b+47 && g>b+47 {return 6}
    return 0
}
let strideX=max(1,w/1500),strideY=max(1,h/900)
typealias Run = (tag:Int,start:Int,end:Int)
var candidates:[String:(x:Int,width:Int,rows:[Int])]=[:]
for y in stride(from:0,to:h,by:strideY) {
    var runs:[Run]=[]
    var prev=tag(0,y), x0=0
    for x in stride(from:strideX,to:w,by:strideX) {
        let q=tag(x,y)
        if q != prev {runs.append((prev,x0,x));x0=x;prev=q}
    }
    runs.append((prev,x0,w))
    guard runs.count>=6 else {continue}
    for i in 0...(runs.count-6) {
        let g=Array(runs[i..<i+6])
        guard g.map({$0.tag}) == [1,2,3,4,5,6] else {continue}
        let lengths=g.map{$0.end-$0.start}
        let t=lengths.sorted()[2]
        guard t>=14,lengths.allSatisfy({abs($0-t)<=max(strideX*2,t/25)}) else {continue}
        let x=g[0].start
        let wide=g[5].end-x
        let key="\(x):\(wide)"
        if candidates[key]==nil {candidates[key]=(x,wide,[])}
        candidates[key]!.rows.append(y)
    }
}
var found:[[String:Int]]=[]
for r in candidates.values {
    let t=Double(r.width)/6
    var blocks:[[Int]]=[]
    var block:[Int]=[]
    for y in r.rows {
        if let last=block.last, y-last>2*strideY {
            blocks.append(block)
            block=[]
        }
        block.append(y)
    }
    if !block.isEmpty {blocks.append(block)}
    for block in blocks {
        guard let y1=block.first,let y2=block.last,
             abs(Double(y2-y1+strideY)-t)<max(4,t*0.12)
        else {continue}
        let top=y1-Int((2*t).rounded())
        let tall=Int((4*t).rounded())
        guard top>=0,top+tall<=h else {continue}
        let gy=top+Int(t*0.5)
        let val=(0..<6).map{j -> Int in let (r2,g,b)=rgb(r.x+Int((Double(j)+0.5)*t),gy); return (r2+g+b)/3}
        guard val[0]<45,val[5]>205,zip(val,val.dropFirst()).allSatisfy({$1>$0+8}) else {continue}
        found.append(["left":r.x,"top":top,"width":r.width,"height":tall])
    }
}
let out=try JSONSerialization.data(withJSONObject:found.sorted{$0["width",default:0]>$1["width",default:0]},options:[.prettyPrinted,.sortedKeys])
print(String(decoding:out,as:UTF8.self))
