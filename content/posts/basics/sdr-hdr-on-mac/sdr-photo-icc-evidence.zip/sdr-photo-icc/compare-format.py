import json,pathlib,itertools,numpy as np
groups={
'sRGB':{'Chrome':['chrome-sdr-srgb-main'],'Safari':['safari-sdr-srgb-main','safari-sdr-srgb'],'Preview':['preview-sdr-srgb-front','preview-sdr-srgb'],'Photos':['photos-sdr-srgb']},
'P3':{'Chrome':['chrome-sdr-p3-main'],'Safari':['safari-sdr-p3-main','safari-sdr-p3'],'Preview':['preview-sdr-p3-main','preview-sdr-p3'],'Photos':['photos-sdr-p3']},
}
names=[p['id'] for p in json.loads(pathlib.Path('public-fixtures/fixtures.json').read_text())['patches']]
Y=np.asarray([.22897456,.69173852,.07928691])
store={}
def row(a,b):
 d=np.abs(a-b); x=np.argmax(d); i,j=np.unravel_index(x,d.shape)
 dy=np.abs((a-b)@Y); y=np.argmax(dy)
 return {'max':round(float(d[i,j]),7),'max_patch':names[i],'channel':'RGB'[j],
 'median':round(float(np.median(np.max(d,axis=1))),7),
 'max_y':round(float(dy[y]),7),'max_y_patch':names[y],
 'max_delta_y_grays':round(float(np.max(dy[:6])),7)}
for fmt in ['raw','png']:
 base=pathlib.Path('foreground-png' if fmt=='png' else 'foreground')
 store[fmt]={}
 for fc,apps in groups.items():
  print(fmt,fc)
  data={}
  for app,files in apps.items():
   data[app]=[]
   for f in files:
    p=base/(f+'.json')
    if not p.exists():continue
    obj=json.loads(p.read_text())
    x=np.asarray([t['linearP3'] for t in obj['patches']] if fmt=='png' else [t['rgb'] for rr in obj['samples'] for t in rr])
    data[app].append((f,x))
  props={}
  for a,b in itertools.combinations(data.items(),2):
   aa,ar=a;bb,br=b
   more={}
   for (an,av),(bn,bv) in itertools.product(ar,br):more[an+'//'+bn]=row(av,bv)
   if more:props[aa+'/'+bb]=more
   for rub,vals in more.items(): print(rub,vals)
  repeat={}
  for a,ar in data.items():
   if len(ar)>1:
    (an,av),(bn,bv)=ar[:2]
    r=row(av,bv); print(a,'repeat',r); repeat[a]=r
  store[fmt][fc]={'pairwise':props,'repeat':repeat}
pathlib.Path('foreground-format-matrix.json').write_text(json.dumps(store,indent=2))
