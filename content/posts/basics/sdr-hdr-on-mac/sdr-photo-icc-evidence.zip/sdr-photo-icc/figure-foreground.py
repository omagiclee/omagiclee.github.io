"""Draw a scalable SVG from the actual foreground window sample outputs."""
from pathlib import Path
from xml.sax.saxutils import escape
import json
matrix=json.loads(Path('foreground-format-matrix.json').read_text())
D={profile:{pair:next(iter(runs.values())) for pair,runs in matrix[fmt][profile]['pairwise'].items()}
   for profile,fmt in [('sRGB','png'),('P3','raw')]}
pairs=list(D['sRGB'])
if not pairs:raise ValueError("no foreground comparisons")
colors={'sRGB':'#326ca0','P3':'#bf601d'}
height = 165+len(pairs)*64+102
s=[]
A=s.append
A(f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 772 {height}" width="772" height="{height}" role="img" aria-labelledby="title note">')
A(f'<title id="title">SDR 照片真机前台窗口的色差</title><desc id="note">在两份各有 24 格的 SDR PNG 色板中比较实际应用窗口的最大线性 P3 单通道绝对差。以左侧应用配对和颜色区分 sRGB 的统一 ICC SDR PNG 读数与 Display P3 原始 Float16 读数。</desc>')
A(f'<rect width="772" height="{height}" rx="18" fill="#f8fafc"/>')
A('<g font-family="system-ui,-apple-system,sans-serif">')
A('<text x="27" y="45" fill="#103452" font-size="23" font-weight="650">SDR 照片：真机前台应用有小色差，灰阶接近</text>')
A('<text x="27" y="75" fill="#365570" font-size="16">每组固定源文件 · 24 色块 · 线性 Display P3 最大单通道差</text>')
A('<rect x="28" y="100" width="13" height="13" rx="2" fill="#326ca0"/><text x="48" y="112" fill="#234463" font-size="15">sRGB · 同 ICC SDR PNG</text>')
A('<rect x="279" y="100" width="13" height="13" rx="2" fill="#bf601d"/><text x="299" y="112" fill="#234463" font-size="15">Display P3 · 原始 Float16</text>')
mx=max(x['max'] for a in D.values() for x in a.values())
scale=max(0.012,(int(mx*1000/3)+1)*.003)
w=425
x=260
for q in range(5):
 xx=x+w*q/4
 A(f'<path d="M{xx},130 V{138+len(pairs)*64}" stroke="#d6e1ee" stroke-width="1"/>')
 A(f'<text x="{xx}" y="{160+len(pairs)*64}" font-size="14" fill="#365570" text-anchor="middle">{scale*q/4:.3f}</text>')
for i,p in enumerate(pairs):
 y=145+i*64
 label=p.replace('/', ' ↔ ').replace('Preview','预览').replace('Photos','照片')
 A(f'<text x="28" y="{y+19}" font-size="17" fill="#234463">{escape(label)}</text>')
 for j,profile in enumerate(['sRGB','P3']):
  val=D[profile][p]['max'] if p in D[profile] else None
  if val is None:
   A(f'<text x="{x}" y="{y+16+j*21}" font-size="15" fill="#62748a">—</text>')
   continue
  length=w*val/scale
  A(f'<rect x="{x}" y="{y+j*21}" width="{max(2,length)}" height="14" rx="3" fill="{colors[profile]}"/>')
  A(f'<text x="{x+length+7:.1f}" y="{y+12+j*21}" font-size="15" font-weight="600" fill="{colors[profile]}">{val:.4f}</text>')
maxGray=max(x['max_delta_y_grays'] for a in D.values() for x in a.values())
A(f'<text x="27" y="{height-59}" fill="#284767" font-size="16">灰阶亮度 Y 最大差 {maxGray:.5f}。同一 App 只改 ICC，最大色差约 0.18。</text>')
A(f'<text x="27" y="{height-29}" fill="#365570" font-size="14">Safari 和预览重复一致。系统合成取样，不是光度计出光测量。</text>')
A('</g></svg>')
Path('sdr-photo-foreground.svg').write_text('\n'.join(s)+'\n')
