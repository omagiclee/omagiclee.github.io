import AppKit
import WebKit
import ImageIO
import UniformTypeIdentifiers
import Foundation
@MainActor class Capture: NSObject, WKNavigationDelegate {
    let filenames=["sRGB-reference","p3-matched","p3-gamut","p3-untagged"]
    let webView:WKWebView
    let dir:URL
    let out:URL
    var index=0
    init(_ dir:URL,_ out:URL) {
        let cfg=WKWebViewConfiguration()
        cfg.websiteDataStore = .nonPersistent()
        self.webView=WKWebView(frame:CGRect(x:0,y:0,width:900,height:620),configuration:cfg)
        self.dir=dir
        self.out=out
        super.init()
        webView.navigationDelegate=self
    }
    func load(){
        if index==filenames.count { exit(0) }
        var u=URLComponents(url:dir.appendingPathComponent("board.html"),resolvingAgainstBaseURL:false)!
        u.queryItems=[URLQueryItem(name:"chart",value:filenames[index])]
        webView.loadFileURL(u.url!,allowingReadAccessTo:dir)
    }
    func webView(_ v:WKWebView,didFinish navigation:WKNavigation!) {
        Task { @MainActor in
            do {
                let val=try await v.callAsyncJavaScript("let e=document.querySelector('img'); await e.decode(); let b=e.getBoundingClientRect(); return [b.x,b.y,b.width,b.height]",arguments:[:],in:nil,contentWorld:.page)
                guard let r=val as? [Double],r.count==4 else {fatalError("fixture sizing failed")}
                let snap=WKSnapshotConfiguration()
                snap.rect=CGRect(x:r[0],y:r[1],width:r[2],height:r[3])
                let view=try await v.takeSnapshot(configuration:snap)
                var rect=CGRect(origin:.zero,size:view.size)
                guard let cg=view.cgImage(forProposedRect:&rect,context:nil,hints:nil) else {fatalError("snapshot nil CGImage")}
                let dest=out.appendingPathComponent(filenames[index]+".png")
                guard let writer=CGImageDestinationCreateWithURL(dest as CFURL,UTType.png.identifier as CFString,1,nil) else {fatalError("destination unavailable")}
                CGImageDestinationAddImage(writer,cg,nil)
                guard CGImageDestinationFinalize(writer) else {fatalError("writing snapshot failed")}
                print("\(dest.lastPathComponent) \(cg.width)x\(cg.height) \(String(describing:cg.colorSpace?.name))")
                index+=1
                load()
            }catch{print(error);exit(1)}
        }
    }
}
let app=NSApplication.shared
app.setActivationPolicy(.prohibited)
let dir=URL(fileURLWithPath:CommandLine.arguments[1],isDirectory:true)
let out=URL(fileURLWithPath:CommandLine.arguments[2],isDirectory:true)
try FileManager.default.createDirectory(at:out,withIntermediateDirectories:true)
let capture=MainActor.assumeIsolated{Capture(dir,out)}
MainActor.assumeIsolated{capture.load()}
DispatchQueue.main.asyncAfter(deadline:.now()+25){print("timeout");exit(2)}
app.run()
