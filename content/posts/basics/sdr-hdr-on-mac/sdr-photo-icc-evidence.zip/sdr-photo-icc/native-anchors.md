# 本机静态证据及局限

Mac 27.2 26B123。Preview 11.0（1147.1.10），app binary SHA-256 8818a0e7c199e334882a71179167458acb677ea3705e20a9e6710bc077a2e228，arm64e.x1 UUID 832471DF-8CE0-3C2E-A0F3-8187435A0CCA。地址为此 slice 的静态未滑移地址。不包含运行时调用跟踪。

| 位置 | 可核事实 |
| --- | --- |
| PVImageElement._sourceImage 0x10004B964 | 0x10004B9FC 向 CIImage 传 ImageIO scalar source/index/options；0x10004BA20 读 CIImage colorSpace |
| PVImageElement.sourceColorSpaceForAppliedGainImage: 0x10004C6F4 | 分开的赋色彩空间／HDR 选择分支；普通 fallback 0x10004C7C0 委托内存中 CIImage.colorSpace |
| PVImageElement.outputColorSpaceForAppliedGainImage: 0x1000435B0 | 非 RAW 路径读取 sourceColorSpace，保留兼容输出且 ICC-compatible 的常规 RGB 色彩空间。灰阶、CMYK、不适合作为输出或不兼容 ICC 的其他分支存在，不代表本样片进入这些分支 |
| PVImageElement._createLayerForView 0x10004CD08 | 0x10004CDF0 调 CIImage 下采样路径，0x10004CE1C 得到 CGImage，0x10004CECC 设 CALayer contents |

Photos 12.0 (916.58.114)，arm64e.x1 UUID 3C0A9E94-F787-3027-BEE4-5FD697189FD6，SHA-256 ffccc28c6e42fdaaab69a1a065907255609bcb9d4432d3efd0f625b6b6ea10ad。应用主程序导入 PHImageManager、CGImageGetColorSpace、CIContext。更具体的单项查看器静态证据如下。

| 位置 | 可核事实 |
| --- | --- |
| IPXViewerItemController._setImageOnPreviewLayer:forAsset:info: 0x100240BB4 | 检查 PHImageResultIsDegradedKey 与 isPreviewReady，0x100240D54 将 CGImage 设为 CALayer contents |
| 同方法 0x100240D88–0x100240DD8 | 若打开 HDR，取 CGImage 色彩空间，判断扩展范围或是否使用 BT.2100 TF，选择高动态范围或标准动态范围 |
| IPXViewerItemController.optimizedImageRequestOptions 0x100240240 | 单独的优化预览选项调用 setPreferHDR(false)，不能外推为所有图库展示都降级 |

不据该静态证据认定某样片进入这些分支、设置已打开、按指定峰值渲染，或 Photos 使用了 Preview 的代码路径。

公开说明：W3C CSS Color 4 的[嵌标签与缺失标签规则](https://www.w3.org/TR/css-color-4/#tagged-images)，Apple 的[ColorSync ICC 转换](https://developer.apple.com/documentation/colorsync/color-profiles)，[WebKit ImageDecoderCG](https://github.com/WebKit/WebKit/blob/main/Source/WebCore/platform/graphics/cg/ImageDecoderCG.cpp)，[Chromium JPEG ICC 读取](https://chromium.googlesource.com/chromium/src/+/062a002cca0bbf39d296fa6b2d1e6840eb4611fb/third_party/blink/renderer/platform/image-decoders/jpeg/jpeg_image_decoder.cc)。
