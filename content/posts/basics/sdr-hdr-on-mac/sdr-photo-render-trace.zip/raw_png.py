import struct,zlib,sys,pathlib,collections,json
import numpy as np
def decode(p):
    b=p.read_bytes()
    assert b[:8]==b'\x89PNG\r\n\x1a\n'
    idat=[]
    j=8
    while j<len(b):
        n=int.from_bytes(b[j:j+4],"big")
        k,t=b[j+4:j+8],b[j+8:j+8+n];j+=12+n
        if k==b'IHDR':w,h,pixels,typ,comp,filt,it=struct.unpack(">IIBBBBB",t)
        if k==b'IDAT':idat.append(t)
    channels={2:3,6:4}[typ]
    assert pixels in (8,16) and it==0
    step=channels*(pixels//8); rs=w*step
    f=zlib.decompress(b''.join(idat))
    out=bytearray(h*rs)
    prior=bytearray(rs)
    for y in range(h):
        idx=y*(rs+1)
        what=f[idx];row=bytearray(f[idx+1:idx+1+rs]); idx=y*rs
        if what==1:
            for j in range(step,rs):row[j]=(row[j]+row[j-step])&255
        elif what==2:
            row=bytearray((a+b)&255 for a,b in zip(row,prior))
        elif what==3:
            for j in range(rs):row[j]=(row[j]+((prior[j]+(row[j-step] if j>=step else 0))>>1))&255
        elif what==4:
            for j in range(rs):
                x=row[j-step] if j>=step else 0; z=prior[j-step] if j>=step else 0;y0=prior[j];pp=x+y0-z
                a,b,c=abs(pp-x),abs(pp-y0),abs(pp-z)
                row[j]=(row[j]+(x if a<=b and a<=c else y0 if b<=c else z))&255
        else: assert what==0
        out[idx:idx+rs]=row;prior=row
    return np.frombuffer(out,dtype='>u2' if pixels==16 else 'u1').reshape(h,w,channels)
if __name__=='__main__':
    d=pathlib.Path('/private/tmp/sdr-photo-evidence.mSZhUc/foreground-png')
    root=pathlib.Path('/private/tmp/four-media-display.tScO6j/captures')
    output={}
    for f in sys.argv[1:]:
        rgb=decode(root/(f+'.png'))
        coords=json.load(open(d/(f+'.json')))['patches']
        output[f]={}
        for v in coords:
            i=v['id'];x,y=v['xy']; c=collections.Counter(tuple(map(int,p)) for p in rgb[y-14:y+15,x-14:x+15,:3].reshape(-1,3))
            output[f][i]=c.most_common(12)
    print(json.dumps(output,indent=1))
