import Foundation
import AppKit
import WebKit
import IOSurface
import QuartzCore
import CryptoKit
import CoreGraphics
import ImageIO
import Darwin
let qc=dlopen("/System/Library/Frameworks/QuartzCore.framework/QuartzCore",RTLD_NOW)!
let surfaceFromCA=unsafeBitCast(dlsym(qc,"CAIOSurfaceGetIOSurface")!,to:(@convention(c)(CFTypeRef)->IOSurfaceRef?).self)
let cgSurfaceContext=unsafeBitCast(dlsym(UnsafeMutableRawPointer(bitPattern:-2),"CGIOSurfaceContextCreate")!,to:(@convention(c)(IOSurfaceRef,Int,Int,Int,Int,CGColorSpace,UInt32)->CGContext?).self)
let cgSurfaceImage=unsafeBitCast(dlsym(UnsafeMutableRawPointer(bitPattern:-2),"CGIOSurfaceContextCreateImage")!,to:(@convention(c)(CGContext)->CGImage?).self)
let csFromPlist=unsafeBitCast(dlsym(UnsafeMutableRawPointer(bitPattern:-2),"CGColorSpaceCreateWithPropertyList")!,to:(@convention(c)(CFTypeRef)->CGColorSpace?).self)

@MainActor final class Run:NSObject, WKNavigationDelegate {
    let web:WKWebView
    let window:NSWindow
    let root:URL
    let out:URL
    let modes=["plain-srgb","layer-srgb","plain-p3","layer-p3","scale-srgb","scale-p3"]
    var current=0
    init(root:URL,out:URL) {
        self.root=root;self.out=out
        window=NSWindow(contentRect:NSRect(x:20,y:70,width:800,height:560),styleMask:[.titled,.nonactivatingPanel],backing:.buffered,defer:false)
        window.title="SDR synthetic layer experiment"
        window.isReleasedWhenClosed=false
        let c=WKWebViewConfiguration()
        c.websiteDataStore = .nonPersistent()
        web=WKWebView(frame:window.contentRect(forFrameRect:window.frame),configuration:c)
        self.window.contentView=web
        super.init()
        web.navigationDelegate=self
    }
    func next(){
        if current == modes.count { exit(0) }
        let mode=modes[current]
        let img=mode.hasSuffix("srgb") ? "fixture-sRGB-reference.png" : "fixture-p3-gamut.png"
        let css=mode.hasPrefix("layer") ? "will-change:transform;transform:translateZ(0)" : mode.hasPrefix("scale") ? "width:740px;height:auto" : ""
        let h="""
        <!doctype html><title>SDR synthetic experiment</title><style>body{margin:0;background:#3e3e3e}img{display:block;\(css)}</style><img src="\(img)">
        """
        let f=root.appendingPathComponent("replay-\(mode).html")
        try! h.data(using:.utf8)!.write(to:f)
        web.loadFileURL(f,allowingReadAccessTo:root)
    }
    func scan(_ l:CALayer,_ parent:String,_ files:inout [String:Any]) {
        let ix=files.count
        let path="\(parent)/\(ix)"
        var info:[String:Any]=["name":l.name ?? "", "layer":String(describing:type(of:l)), "frame":"\(l.frame)","scale":l.contentsScale,"format":"\(l.contentsFormat)"]
        if let obj=l.contents {
            let o=obj as AnyObject
            let id=CFGetTypeID(o)
            info["type"]="\(CFCopyTypeIDDescription(id) as String? ?? "-")"
            let surface = id==IOSurfaceGetTypeID() ? unsafeBitCast(o,to:IOSurfaceRef.self) : (info["type"] as? String == "CAIOSurface" ? surfaceFromCA(o) : nil)
            if let s=surface {
                let pr=IOSurfaceGetPixelFormat(s)
                info["pixels"]=[IOSurfaceGetWidth(s),IOSurfaceGetHeight(s),IOSurfaceGetBytesPerRow(s)]
                info["pixelFormat"]=String(format:"%08x",pr)
                for k in ["IOSurfaceColorSpace", "ColorSpace"] { if let prop=IOSurfaceCopyValue(s,k as CFString) {
                    info["colorProperty"]=k
                    if let cs=csFromPlist(prop) {info["colorSpace"]=cs.name as String? ?? "unnamed";if let icc=cs.copyICCData() {info["icc"]=SHA256.hash(data:icc as Data).map{String(format:"%02x",$0)}.joined()}} else {info["colorSpace"]="\(prop)"}
                }}
                if let prop=IOSurfaceCopyValue(s,"IOSurfaceICCProfile" as CFString),let data=prop as? Data {
                    info["icc"]=SHA256.hash(data:data).map{String(format:"%02x",$0)}.joined()
                }
                if let prop=IOSurfaceCopyValue(s,"IOSurfaceColorSpace" as CFString),let cs=csFromPlist(prop),
                   let ctx=cgSurfaceContext(s,IOSurfaceGetWidth(s),IOSurfaceGetHeight(s),8,32,cs,CGBitmapInfo.byteOrder32Little.rawValue | CGImageAlphaInfo.premultipliedFirst.rawValue),
                   let im=cgSurfaceImage(ctx) {
                    let path=out.appendingPathComponent("\(modes[current])-\(ix).png")
                    if let dest=CGImageDestinationCreateWithURL(path as CFURL,"public.png" as CFString,1,nil) {
                        CGImageDestinationAddImage(dest,im,nil)
                        info["readbackPNG"]=CGImageDestinationFinalize(dest)
                    }
               }
            } else if id==CGImage.typeID {
                let cg=unsafeBitCast(o,to:CGImage.self)
                info["pixels"]=[cg.width,cg.height,cg.bytesPerRow]
                let path=out.appendingPathComponent("\(modes[current])-\(ix).png")
                if let dest=CGImageDestinationCreateWithURL(path as CFURL,"public.png" as CFString,1,nil) {
                    CGImageDestinationAddImage(dest,cg,nil)
                    CGImageDestinationFinalize(dest)
                }
            }
        }
        files[path]=info
        for k in l.sublayers ?? [] {scan(k,path,&files)}
    }
    func webView(_ view:WKWebView,didFinish navigation:WKNavigation!) {
        Task{@MainActor in
            let _=try! await view.callAsyncJavaScript(rawJS,arguments:[:],in:nil,contentWorld:.page)
            try! await Task.sleep(for:.milliseconds(850))
            var tree:[String:Any]=[:]
            if let l=web.layer {scan(l,"",&tree)}
            for (label, object) in [("web",view as NSObject),("page",view as NSObject)] {
                let sel=NSSelectorFromString("_layerTreeAsText")
                if object.responds(to:sel), let s=object.perform(sel)?.takeUnretainedValue() as? String {
                    try? s.write(to:out.appendingPathComponent("\(modes[current])-\(label).txt"),atomically:true,encoding:.utf8)
                }
            }
            try! JSONSerialization.data(withJSONObject:tree,options:[.prettyPrinted,.sortedKeys]).write(to:out.appendingPathComponent("\(modes[current]).json"))
            print("\(modes[current]) \(tree.count) layers")
            current+=1;next()
        }
    }
}
let rawJS="await document.querySelector('img').decode(); return true;"
let app=NSApplication.shared
app.setActivationPolicy(.accessory)
let args=CommandLine.arguments
for s in NSScreen.screens {
    let digest=s.colorSpace?.cgColorSpace?.copyICCData().map {SHA256.hash(data:$0 as Data).map{String(format:"%02x",$0)}.joined()} ?? "-"
    print("screen",s.localizedName,"HDR",s.maximumExtendedDynamicRangeColorComponentValue,"ICC",digest)
}
let runner=MainActor.assumeIsolated {Run(root:URL(fileURLWithPath:args[1]),out:URL(fileURLWithPath:args[2]))}
MainActor.assumeIsolated { runner.window.orderBack(nil);runner.next() }
DispatchQueue.main.asyncAfter(deadline:.now()+18){exit(3)}
app.run()
