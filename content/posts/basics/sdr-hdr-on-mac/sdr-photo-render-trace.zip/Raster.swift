import Foundation
import AppKit
import CoreGraphics
import CoreVideo
import IOSurface
import ImageIO
import Darwin
let cs=NSScreen.screens.first!.colorSpace!.cgColorSpace!
let gc=unsafeBitCast(dlsym(UnsafeMutableRawPointer(bitPattern:-2),"CGIOSurfaceContextCreate")!,to:(@convention(c)(IOSurfaceRef,Int,Int,Int,Int,CGColorSpace,UInt32)->CGContext?).self)
let gi=unsafeBitCast(dlsym(UnsafeMutableRawPointer(bitPattern:-2),"CGIOSurfaceContextCreateImage")!,to:(@convention(c)(CGContext)->CGImage?).self)
let args=CommandLine.arguments
let source=URL(fileURLWithPath:args[1])
let out=URL(fileURLWithPath:args[2])
let m=try JSONSerialization.jsonObject(with: Data(contentsOf:URL(fileURLWithPath:args[3]))) as! [String:[String:[[Int]]]]
let cases=["srgb":"fixture-sRGB-reference.png", "p3":"fixture-p3-gamut.png"]
let names=try JSONSerialization.jsonObject(with:Data(contentsOf:URL(fileURLWithPath:args[4]))) as! [String:Any]
let patches=(names["patches"] as! [[String:Any]]).map{$0["id"] as! String}
var results:[String:Any]=[:]
for (key,name) in cases {
    let src=CGImageSourceCreateWithURL(source.appendingPathComponent(name) as CFURL,nil)!
    let im=CGImageSourceCreateImageAtIndex(src,0,nil)!
    for scale in [1,2] {
    let width=im.width*scale,height=im.height*scale
    for format in [kCVPixelFormatType_32BGRA,kCVPixelFormatType_Lossless_32BGRA,0] as [OSType] {
      for blend in [CGBlendMode.normal,.copy] {
      for interpolation in [CGInterpolationQuality.default,.none] {
      for alpha in [CGImageAlphaInfo.premultipliedFirst,.noneSkipFirst] {
        let flags=CGBitmapInfo.byteOrder32Little.rawValue | alpha.rawValue
        var pixel:CVPixelBuffer?
        let context:CGContext
        if format == 0 {
            guard let bitmap=CGContext(data:nil,width:width,height:height,bitsPerComponent:8,bytesPerRow:width*4,space:cs,bitmapInfo:flags) else {continue}
            context=bitmap
        } else {
            let e=CVPixelBufferCreate(kCFAllocatorDefault,width,height,format,[kCVPixelBufferIOSurfacePropertiesKey:[:] as [String:Int],kCVPixelBufferMetalCompatibilityKey:true] as CFDictionary,&pixel)
            guard e==0,let pixel,let s=CVPixelBufferGetIOSurface(pixel)?.takeUnretainedValue(),
                  let c=gc(s,width,height,8,32,cs,flags) else { continue }
            context=c
        }
        context.interpolationQuality=interpolation
        context.setBlendMode(blend)
        context.draw(im,in:CGRect(x:0,y:0,width:width,height:height))
        context.flush()
        guard let readback=format == 0 ? context.makeImage() : gi(context) else {continue}
        let dest=out.appendingPathComponent("raster-\(key)-\(scale)-\(format)-\(blend.rawValue)-\(interpolation.rawValue)-\(alpha.rawValue).png")
        let writer=CGImageDestinationCreateWithURL(dest as CFURL,"public.png" as CFString,1,nil)!
        CGImageDestinationAddImage(writer,readback,nil)
        if !CGImageDestinationFinalize(writer) { print("failed writing",dest.lastPathComponent) }
        withExtendedLifetime(pixel){}
      }}}
    }
    }
}
