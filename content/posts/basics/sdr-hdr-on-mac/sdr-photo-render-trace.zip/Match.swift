import AppKit
import CoreGraphics
import CoreImage
import ImageIO
import Foundation
import CryptoKit
let args=CommandLine.arguments
let cs=NSScreen.screens.first!.colorSpace!.cgColorSpace!
let lp=CGColorSpace(name:CGColorSpace.extendedLinearDisplayP3)!
let captures=URL(fileURLWithPath:args[1])
let out=URL(fileURLWithPath:args[2])
let w=try JSONSerialization.jsonObject(with: Data(contentsOf: URL(fileURLWithPath:args[3]))) as! [String:[String:[[Double]]]]
let names=["black","gray_32","gray_64","gray_128","gray_192","white","skin_light","skin_dark","blue_sky","leaf","deep_orange","navy","red","green","blue","cyan","magenta","yellow","red_orange","bright_green","purple","blue_green","warm_gray","cool_gray"]
let ci=CIContext(options:[.workingColorSpace:lp])
let outLRGB=CGColorSpace(name:CGColorSpace.extendedSRGB)!
func fromFloats(_ rgb:[Double])->CGImage {
    var rgba=rgb.map{Float($0)}+[1]
    let data=rgba.withUnsafeMutableBytes{Data($0)}
    let provider=CGDataProvider(data:data as CFData)!
    return CGImage(width:1,height:1,bitsPerComponent:32,bitsPerPixel:128,bytesPerRow:16,space:lp,bitmapInfo:[.floatComponents,.byteOrder32Little,CGBitmapInfo(rawValue:CGImageAlphaInfo.premultipliedLast.rawValue)],provider:provider,decode:nil,shouldInterpolate:false,intent:.defaultIntent)!
}
func to8(_ image:CGImage)->[Int] {
    let ctx=CGContext(data:nil,width:1,height:1,bitsPerComponent:8,bytesPerRow:4,space:cs,bitmapInfo:CGImageAlphaInfo.premultipliedLast.rawValue)!
    ctx.setBlendMode(.copy)
    ctx.draw(image,in:CGRect(x:0,y:0,width:1,height:1))
    return (0..<3).map{Int(ctx.data!.load(fromByteOffset:$0,as:UInt8.self))}
}

func fromDeviceRGB(_ rgb:[Int])->CGImage {
  let v=rgb.map{UInt8($0)}+[255]
  let p=CGDataProvider(data:Data(v) as CFData)!
  return CGImage(width:1,height:1,bitsPerComponent:8,bitsPerPixel:32,bytesPerRow:4,space:cs,bitmapInfo:CGBitmapInfo(rawValue:CGImageAlphaInfo.premultipliedLast.rawValue),provider:p,decode:nil,shouldInterpolate:false,intent:.defaultIntent)!
}
func viaCI(_ rgb:[Int],_ withRoundTrip:Bool)->[Double] {
  let s=fromDeviceRGB(rgb)
  var v=[UInt16](repeating:0,count:4)
  v.withUnsafeMutableBytes { p in
    let image=CIImage(cgImage:s)
    let input = withRoundTrip ? CIImage(cgImage:ci.createCGImage(image,from:image.extent,format:.RGBAh,colorSpace:outLRGB)!) : image
    ci.render(input,toBitmap:p.baseAddress!,rowBytes:8,bounds:input.extent,format:.RGBAh,colorSpace:lp)
  }
  return v.prefix(3).map{Double(Float16(bitPattern:$0))}
}
var evidence:[String:Any]=[:]
for kind in ["srgb","p3"] {
    var samples:[String:[[Double]]]=[:]
    for app in ["safari","preview","chrome"] {
      let label=app+"-sdr-"+kind+(app=="chrome" ? "-main":"")
      let data=try Data(contentsOf:captures.appendingPathComponent(label+".json"))
      let parsed=try JSONSerialization.jsonObject(with:data) as! [String:Any]
      let patches=(parsed["samples"] as! [[[String:Any]]]).flatMap{$0}
      samples[app]=patches.map{$0["rgb"] as! [Double]}
    }
    evidence[kind]=names.enumerated().map { i,name -> [String:Any] in
        let wr=w["plain-"+kind]![name]!.first!.map{Int($0)}
        var line:[String:Any]=["id":name,"wk":wr]
        for (app,rgb) in samples {
            let v=rgb[i]
            let q=to8(fromFloats(v))
            line[app+"HDR"]=v
            line[app+"Reverse8"]=q
        }
        let pv=line["previewReverse8"] as! [Int]
        line["webkitForwardHDR"]=viaCI(wr,true)
        line["previewCodeForwardHDR"]=viaCI(pv,true)
        line["controlCodeDifference"]=zip(wr,pv).map{$0-$1}
        return line
    }
}
try JSONSerialization.data(withJSONObject:evidence,options:[.prettyPrinted,.sortedKeys]).write(to:out)
