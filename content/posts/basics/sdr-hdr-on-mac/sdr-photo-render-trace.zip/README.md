# SDR 照片图层量化定位

同一台 Apple Silicon Mac、macOS 27.2 (26B123)、Safari/WebKit 27.2、Chrome for Testing 158.0.8127.88、「预览」11.0、LG ULTRAGEAR+。无个人截图或媒体，只有合成色卡、预先取样的数值与探针。

- `Native.swift` 重放原尺寸 ImageIO 解码、WebKit ImageIO flags 与同宽度的缩略图入口。两个 PNG 的每 24 格 RGB 码与各自的 ICC 完全相同。Core Image 以同源 ICC 重新输出 RGBA8 同样保留匹配的颜色读数。原图和上一轮证据也在博客的 SDR 照片证据包中。
- `Layers.swift` 启动使用系统 WebKit 的独立 WKWebView，读取自己窗口的 CAIOSurface / IOSurface，不是取得 Safari.app 进程权限。图层是无损压缩 BGRA8 (`&BGA`)，用 CGIOSurfaceContextCreateImage 解包并重读 24 格。根据图层内置的 ICC 对照本机显示器 ICC SHA-256，三种网页布置使用相同的设备空间。未把压缩 bytes 当作 RGBA 读。默认、单独图层与缩放三个对照得到相同的 24 格颜色。
- `hdr-match.json` 中的 `wk` 是实取 WebKit 8 位设备 RGB。三种 App 的 `*Reverse8` 由原始 HDR 捕获样本 `*HDR` 通过 ColorSync/Core Graphics 逆转到同一设备空间再量化获得，不是从 Safari/Chrome/预览私有缓冲区直接读出。每份色卡各 24/24 格 Safari 均和 WKWebView 同码。用同 ICC 的 16-bit SDR PNG 独立验证 sRGB 同样 24/24；宽色域以 HDR 浮点取样为准。
- `Match.swift` 用同一个转换器正向算两套设备 RGB，唯一改变是表列通道相差 1。模型重现四个 sRGB 与三个 P3 差异的主要方向，P3 浅肤色 G 几乎逐值重现，sRGB 红 R 的 -0.00830 小于前台的 -0.01025，不能说逐位无残差。该单变量是输入码值的反事实，不是 patched Safari 窗口。
- `Raster.swift` 用同 ICC、同内容、同色深来回放普通位图、普通及无损压缩两种 IOSurface。对照中的压缩/非压缩中心值无变化，但单独的 Core Graphics 重放未逐码复刻 WebKit。不能给某个 Apple 私有 CMM 内核、GPU 指令或特定 rounding 算式下结论。观察到的首处分叉和 8 位落码位置已有强证据。
- 图层属性及像素来自独立宿主。装机静态锚点是 WebCore 27.2 `GraphicsContextCG::drawNativeImage` 0x1BB56373C（CGContextDrawImage 0x1BB5639F8），同一版 arm64e.x1。Preview 11.0 `PVImageElement._sourceImage` 0x10004B964、`_createLayerForView` 0x10004CD08（0x10004CE1C 取 CGImage，0x10004CECC 交给 CALayer）。地址均未加 ASLR slide。
- 复查实测流程：解压，将 `Layers.swift` 用 `swiftc Layers.swift -o wk-layers` 编译，执行 `mkdir -p layers; ./wk-layers ./fixtures ./layers`，再用 Python 3 和 numpy 执行 `python3 extract_layers.py`。色卡、图层 JSON、对比报告和每格前台数据已包含。设备 ICC 因设备/模式而异，实验结论不外推到所有 Mac。
