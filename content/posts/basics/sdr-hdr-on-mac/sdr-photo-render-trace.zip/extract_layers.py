from raw_png import decode
import json,pathlib,numpy as np
root=pathlib.Path('.')
names=[p['id'] for p in json.load(open(root/'fixtures.json'))['patches']]
d={}
for mode in ('plain-srgb','layer-srgb','scale-srgb','plain-p3','layer-p3','scale-p3'):
 files=[('layers',mode)]
 for dir_,mode in files:
  dir_=pathlib.Path(dir_)
  p=15 if mode.startswith('layer') else 10
  buf=[decode(dir_/f'{mode}-{x}.png') for x in ([p] if p==15 else [p,p+1])]
  a={}
  for i,name in enumerate(names):
   w,h=(768,512) if not mode.startswith('scale') else (740,740*512/768)
   x,y=(int((i%6+.5)*w/6),int((i//6+.5)*h/4))
   if p==15:
    b=buf[0]
   else:
    b=buf[0] if x<512 else buf[1]; x=(x if x<512 else x-512)*2
    y*=2
   a[name]=sorted({tuple(z.tolist()) for z in b[y-4:y+5,x-4:x+5,:3].reshape(-1,3)})
  d[mode]=a
print(json.dumps(d,indent=1))
