import Foundation
import AppKit
import CoreGraphics
import CoreImage
import ImageIO
import CryptoKit
import Darwin
let d=URL(fileURLWithPath:CommandLine.arguments[1])
let out=URL(fileURLWithPath:CommandLine.arguments[2])
let profiles=URL(fileURLWithPath:CommandLine.arguments[3])
let specs=["fixture-sRGB-reference.png","fixture-p3-gamut.png"]
let patchNames=["black","gray_32","gray_64","gray_128","gray_192","white","skin_light","skin_dark","blue_sky","leaf","deep_orange","navy","red","green","blue","cyan","magenta","yellow","red_orange","bright_green","purple","blue_green","warm_gray","cool_gray"]
let lp=CGColorSpace(name:CGColorSpace.extendedLinearDisplayP3)!
let p3=CGColorSpace(name:CGColorSpace.displayP3)!
let es=CGColorSpace(name:CGColorSpace.extendedSRGB)!
let s=CGColorSpace(name:CGColorSpace.sRGB)!
let capture=CGColorSpace(iccData:try Data(contentsOf:profiles) as CFData)!
let display=NSScreen.screens.max(by: {$0.frame.width<$1.frame.width})?.colorSpace?.cgColorSpace ?? p3
let imageIO=dlopen("/System/Library/Frameworks/ImageIO.framework/ImageIO",RTLD_NOW)!
func key(_ n:String)->String? {
  guard let p=dlsym(imageIO,n) else {return nil}
  return p.assumingMemoryBound(to:CFString.self).pointee as String
}
var decode:[String:Any]=[kCGImageSourceShouldCache as String:true]
for n in ["kCGImageSourceShouldPreferRGB32","kCGImageSourceSkipMetadata","kCGImageSourceCreateUnpremultipliedPNG"] { if let k=key(n) {decode[k]=true} }
var thumb=decode
thumb[kCGImageSourceShouldCacheImmediately as String]=true
thumb[kCGImageSourceCreateThumbnailFromImageAlways as String]=true
thumb[kCGImageSourceThumbnailMaxPixelSize as String]=768
func digest(_ s:CGColorSpace?) -> String {
    guard let data=s?.copyICCData() else{return "-"}
    return SHA256.hash(data:data as Data).map{String(format:"%02x",$0)}.joined()
}
func centers(_ w:Int,_ h:Int) -> [Int] { (0..<24).map{((2*($0/6)+1)*h/8)*w + (2*($0%6)+1)*w/12} }
func draw(_ image:CGImage,_ cs:CGColorSpace,_ bits:Int,_ intent:CGColorRenderingIntent = .defaultIntent) -> [String:Any] {
    let w=image.width,h=image.height
    let bytes=bits/8
    let flags:(UInt32)=(bits==8 ? 0 : CGBitmapInfo.floatComponents.rawValue | (bits==16 ? CGBitmapInfo.byteOrder16Little.rawValue : CGBitmapInfo.byteOrder32Little.rawValue)) | CGImageAlphaInfo.premultipliedLast.rawValue
    guard let ctx=CGContext(data:nil,width:w,height:h,bitsPerComponent:bits,bytesPerRow:w*4*bytes,space:cs,bitmapInfo:flags) else {return [:]}
    ctx.setBlendMode(.copy)
    ctx.interpolationQuality = .none
    ctx.setRenderingIntent(intent)
    ctx.draw(image,in:CGRect(x:0,y:0,width:w,height:h))
    let p=ctx.data!
    let v=centers(w,h).map { i in (0..<3).map { j -> Double in
      let pos=4*i+j
      if bits==8 {return Double(p.load(fromByteOffset:pos,as:UInt8.self))}
      if bits==16 {return Double(Float16(bitPattern:p.load(fromByteOffset:pos*2,as:UInt16.self)))}
      return Double(p.load(fromByteOffset:pos*4,as:Float.self))
    }}
    var answer:[String:Any]=["pixels":v]
    if cs != lp, let im=ctx.makeImage() {answer["linearP3"]=draw(im,lp,32,.relativeColorimetric)["pixels"]}
    return answer
}
let sourcesToTry:[(String,CIContext)]=[
   ("ciDefault",CIContext()),
   ("ciLP3",CIContext(options:[.workingColorSpace:lp])),
   ("ciCPU",CIContext(options:[.useSoftwareRenderer:true]))
]
var report:[String:Any]=["patches":patchNames,"webkitDecodeOptions":decode,"displayColorSpace":display.name as String? ?? "unnamed","profiles":["display":digest(display),"capture":digest(capture),"builtinP3":digest(p3)]]
for name in specs {
    let src=CGImageSourceCreateWithURL(d.appendingPathComponent(name) as CFURL,nil)!
    let basic=CGImageSourceCreateImageAtIndex(src,0,nil)!
    let web=CGImageSourceCreateImageAtIndex(src,0,decode as CFDictionary)!
    let thumbnail=CGImageSourceCreateThumbnailAtIndex(src,0,thumb as CFDictionary)!
    let cs=basic.colorSpace!
    var data:[String:Any]=[:]
    for (label,im) in [("basic",basic),("web",web),("thumbnail",thumbnail)] {
        data[label] = ["icc":digest(im.colorSpace),"bpp":im.bitsPerPixel,"bpc":im.bitsPerComponent,"size":[im.width,im.height],"source8":draw(im,cs,8),"linearP3":draw(im,lp,32,.relativeColorimetric)["pixels"]!]
    }
    for (dest,space) in [("P3",p3),("sRGB",s),("display",display),("linearP3",lp),("captureICC",capture),("sourceICC",cs),("extSRGB",es)] {
        for (key,v) in [("default",CGColorRenderingIntent.defaultIntent),("relative",.relativeColorimetric),("perceptual",.perceptual),("absolute",.absoluteColorimetric),("saturation",.saturation)] {
            for bits in [8,16,32] {
                data["cg_\(dest)_\(bits)_\(key)"]=draw(web,space,bits,v)
            }
        }
    }
    let dsrc = CIImage(cgImageSource:src,index:0,options:nil)
    for (kind,ci) in [("fromImageIO",dsrc),("fromCG",CIImage(cgImage:basic))] {
      data[kind+"_sourceColorSpace"]=digest(ci.colorSpace)
      for (ctxname,ctx) in sourcesToTry {
        for (dest,space) in [("source",cs),("display",display),("sRGB",s),("P3",p3),("linearP3",lp)] {
          for (formatName,format) in [("RGBA8",CIFormat.RGBA8),("RGBAh",.RGBAh),("RGBAf",.RGBAf)] {
            if let rendered=ctx.createCGImage(ci,from:ci.extent,format:format,colorSpace:space) {
                data["\(ctxname)_\(kind)_\(dest)_\(formatName)"] = ["linearP3":draw(rendered,lp,32,.relativeColorimetric)["pixels"]!, "icc":digest(rendered.colorSpace), "pixels":draw(rendered,space,8)["pixels"] as Any]
            }
          }
        }
      }
    }
    report[name]=data
}

if CommandLine.arguments.count>4 {
    var info:[String:Any]=[:]
    let a=URL(fileURLWithPath:CommandLine.arguments[4])
    let bases=["safari-sdr-srgb","preview-sdr-srgb","chrome-sdr-srgb-main","safari-sdr-p3","preview-sdr-p3","chrome-sdr-p3-main"]
    let points=URL(fileURLWithPath:CommandLine.arguments[5])
    let cases:[String:CGColorSpace]=["display":display,"P3":p3,"lp":lp]
    for n in bases {
        let im=CGImageSourceCreateImageAtIndex(CGImageSourceCreateWithURL(a.appendingPathComponent(n+".png") as CFURL,nil)!,0,nil)!
        let j=try JSONSerialization.jsonObject(with: Data(contentsOf:points.appendingPathComponent(n+".json"))) as! [String:Any]
        let arr=j["patches"] as! [[String:Any]]
        let data=arr.map { p -> [String:Any] in
            let xy=p["xy"] as! [Int]
            let r=CGRect(x:xy[0]-16,y:xy[1]-16,width:32,height:32)
            let cg=im.cropping(to:r)!
            var row:[String:Any]=["id":p["id"]!]
            for (caseName,cs) in cases {
                for bits in (caseName == "lp" ? [32] : [8,32]) {
                    let k=draw(cg,cs,bits)["pixels"] as! [[Double]]
                    row[caseName+"-"+String(bits)] = k[0]
                }
            }
            return row
        }
        info[n]=data
    }
    report["foregroundInverse"]=info
}
try JSONSerialization.data(withJSONObject:report,options:[.prettyPrinted,.sortedKeys]).write(to:out)
