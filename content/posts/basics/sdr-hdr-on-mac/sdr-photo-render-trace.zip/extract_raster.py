import json,pathlib
from raw_png import decode
from collections import defaultdict
ref=json.load(open('hdr-match.json'))
d={}
for p in sorted(pathlib.Path('raster-cases').glob('*.png')):
 mode,scale,fmt,blend,q,alpha=p.stem.split('-')[1:]
 if blend!='0' or q!='0': continue
 r=ref[mode]
 a=decode(p)
 h,w,_=a.shape
 rows=[a[h*(2*(i//6)+1)//8,w*(2*(i%6)+1)//12,:3].tolist() for i in range(24)]
 e=[(b['id'],v,b['wk']) for v,b in zip(rows,r) if v!=b['wk']]
 d[p.stem]={'rgb':rows,'differentFromWK':e}
 print(p.stem,'matches',24-len(e), e)
pathlib.Path('raster-match.json').write_text(json.dumps(d,indent=2))
