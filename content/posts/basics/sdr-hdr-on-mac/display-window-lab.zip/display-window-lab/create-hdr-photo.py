import math,struct,zlib,json
from pathlib import Path
# Relative display light. White=203 nit in these authored inputs.
grey=[.08,.25,.5,1,1.5,2,3,4]
bars=[(v,v,v) for v in grey]+[(1,.15,.10),(.1,.9,.14),(.18,.30,1),(1.5,.2,.15),(.25,1.5,.45),(.3,.52,1.75),(1.6,1.45,.22),(.4,.7,1.5)]
def pq(n):
    a=(n/10000)**(2610/16384)
    return ((3424/4096+2413*a/128)/(1+2392*a/128))**(2523/32)
def hlg_unit(e):
    a=.17883277
    return math.sqrt(3*e) if e<=1/12 else a*math.log(12*e-(1-4*a))+0.5-a*math.log(4*a)
def signal(row,form):
    n=[x*203 for x in row]
    if form==16:return [pq(x) for x in n]
    l=sum(x*c for x,c in zip(n,[.2627,.6780,.0593]))/1000
    return [hlg_unit(x/1000*l**((1-1.2)/1.2)) for x in n]
def chunk(c,b):
    return struct.pack('>I',len(b))+c+b+struct.pack('>I',zlib.crc32(c+b))
expect=[]
for name,trc in [('Lab-HDR-PQ-2020.png',16),('Lab-HDR-HLG-2020.png',18)]:
    signals=[[round(x*65535) for x in signal(p,trc)] for p in bars]
    rows=[b'\0'+b''.join(struct.pack('>HHH',*s)*90 for s in signals[i:i+8]) for i in (0,8)]
    dat=b'\x89PNG\r\n\x1a\n'+chunk(b'IHDR',struct.pack('>IIBBBBB',720,360,16,2,0,0,0))+chunk(b'cICP',bytes([9,trc,0,1]))+chunk(b'IDAT',zlib.compress(rows[0]*180+rows[1]*180))+chunk(b'IEND',b'')
    Path('assets',name).write_bytes(dat)
    expect.append({'file':name,'geometry':{'rows':2,'cols':8},'linearBT2020OverRefWhite':bars,'encodedRgb16':signals})
Path('hdr-photo-source.json').write_text(json.dumps(expect,indent=2))
