import argparse,json,numpy as np
from pathlib import Path
p=argparse.ArgumentParser()
p.add_argument('base');p.add_argument('rect',nargs=4,type=float,help='top-left x y w h in capture pixels')
p.add_argument('--layout',choices=['sdr-photo','sdr-video','hdr-photo','hdr-gain','hdr-video'],required=True)
p.add_argument('--white',nargs=2,type=float)
a=p.parse_args()
m=json.loads(Path(a.base+'.json').read_text())
w,h=m['width'],m['height']
raw=np.fromfile(a.base+'.rgba16',dtype='<f2').reshape(h,w,4).astype(np.float32)
if a.layout=='hdr-video':
 xs=[(80+160*i)/1280 for i in range(8)];ys=[232/720,488/720]
else:
 cols,rows={'sdr-photo':(6,4),'sdr-video':(8,4),'hdr-photo':(8,2),'hdr-gain':(8,1)}[a.layout]
 xs=[(i+.5)/cols for i in range(cols)];ys=[(j+.5)/rows for j in range(rows)]
x,y,dx,dy=a.rect
def get(cx,cy):
 i,j=int(round(cx)),int(round(cy))
 if i<5 or i+5>=w or j<5 or j+5>=h: raise ValueError('sample outside safe image interior')
 b=raw[j-5:j+6,i-5:i+6,:3]
 med=np.median(b,axis=(0,1))
 if not np.isfinite(med).all():raise ValueError("invalid non-finite samples")
 v=[round(float(q),6) for q in med]
 spread=np.max(np.ptp(b.reshape(-1,3),axis=0))
 lum=np.dot(med,[.22897456,.69173852,.07928691])
 return {'xy':[i,j],'rgb':v,'Y':round(float(lum),6),'patchSpan':round(float(spread),6)}
s=[[get(x+dx*i,y+dy*j) for i in xs] for j in ys]
data={'capture':m,'rect':a.rect,'samples':s}
if a.white:data['uiSDRWhite']=get(*a.white)
print(json.dumps(data,indent=2))
