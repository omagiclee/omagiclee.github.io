# Mac SDR／HDR 前台显示实验

本包保存本文四类实验的合成样片、HDR 静态图前台数值、采样和生成脚本。没有个人照片、图库或原始窗口截图。「照片」App 未取样。SDR 照片、SDR 视频和 HDR 视频的完整窗口数值另见文章中对应的专用证据包。

- 样片在 samples/。直接 PQ 与 HLG 静态图分别按对应曲线生成，设计目标见 hdr-photo-source.json。
- lab-http.py 默认读取 assets/。可将样片复制到 assets/ 后运行。它只监听本机回环地址，支持视频的 Range 请求。
- capture.swift 使用 macOS ScreenCaptureKit，请自行编译并按系统流程授权给测试程序。只针对打开的合成样片窗口。sampler.py 接受同一次抓取的 JSON、Float16 像素和已核对的矩形。原始窗口像素不随本包分发。色卡校验行序为 top-left。
- 数值属于窗口合成或相应截图输出，不是显示器物理 nit。比较 SDR 视频时使用同一 ICC 的 SDR 输出，不混用 HDR 截图表示。

日期为 2026-11-26，macOS 27.2 (26B123)，Chrome for Testing 158.0.8127.88、Safari 27.2、QuickTime Player 10.5、预览 11.0。
