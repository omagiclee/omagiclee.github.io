from pathlib import Path
from urllib.parse import urlsplit,unquote
from http.server import ThreadingHTTPServer,BaseHTTPRequestHandler
import mimetypes,re
class H(BaseHTTPRequestHandler):
 def do_GET(self): self.send_file(True)
 def do_HEAD(self): self.send_file(False)
 def send_file(self,body):
  name=unquote(urlsplit(self.path).path).lstrip('/')
  if not re.fullmatch(r'test\.html|Lab-[\w-]+\.(?:png|jpg|heic|avif|mp4)',name):
   return self.send_error(404)
  f=Path(__file__).parent/'assets'/name
  if not f.is_file():return self.send_error(404)
  data=f.read_bytes()
  n=len(data);a=0;b=n-1;status=200
  req=self.headers.get('Range')
  if req:
   m=re.fullmatch(r'bytes=(\d+)-(\d*)',req)
   if not m or int(m[1])>=n:
    self.send_response(416);self.send_header('Content-Range',f'bytes */{n}');self.end_headers();return
   status=206;a=int(m[1]);b=min(int(m[2]),b) if m[2] else b
   if b<a:return self.send_error(416)
  self.send_response(status)
  self.send_header('Content-Type',mimetypes.guess_type(name)[0] or 'application/octet-stream')
  self.send_header('Content-Length',str(b-a+1));self.send_header('Accept-Ranges','bytes')
  self.send_header('Cache-Control','no-store')
  if status==206:self.send_header('Content-Range',f'bytes {a}-{b}/{n}')
  self.end_headers()
  if body:
   try:self.wfile.write(data[a:b+1])
   except (BrokenPipeError,ConnectionResetError):pass
if __name__=='__main__':
 ThreadingHTTPServer(('127.0.0.1',49537),H).serve_forever()
