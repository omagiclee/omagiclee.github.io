import AppKit
import CoreGraphics
import CoreImage
import ImageIO
import UniformTypeIdentifiers
import ScreenCaptureKit

@MainActor
@main struct MacDisplayLab {
    static let safeApps:Set<String>=["com.apple.Safari","com.google.chrome.for.testing","com.google.Chrome.forTesting","com.google.Chrome.for.Testing","com.apple.Preview","com.apple.QuickTimePlayerX","com.apple.Photos"]
    static func finish(_ output:URL,_ fields:[String:Any],_ ec:Int32=0) -> Never {
        if let data=try? JSONSerialization.data(withJSONObject:fields,options:[.prettyPrinted,.sortedKeys]) { try? data.write(to:output.appendingPathExtension("json"),options:.atomic) }
        exit(ec)
    }
    static func main() {
        let a=Array(CommandLine.arguments.dropFirst())
        guard a.count>=2 else {exit(2)}
        let out=URL(fileURLWithPath:a[1])
        let app=NSApplication.shared
        app.setActivationPolicy(.accessory)
        DispatchQueue.main.async {
            Task { @MainActor in
                let before=CGPreflightScreenCaptureAccess()
                if a[0]=="permission" {
                    let requested=before ? true : CGRequestScreenCaptureAccess()
                    finish(out,["before":before,"requested":requested,"after":CGPreflightScreenCaptureAccess(),"screenCount":NSScreen.screens.count])
                }
                if a[0]=="state" {
                    finish(out,["authorized":before,"screenCount":NSScreen.screens.count])
                }
                guard before else {finish(out,["error":"macOS has not granted screen capture to this app"],19)}
                guard a.count==4, safeApps.contains(a[2]) else {finish(out,["error":"expected application and synthetic title key"],2)}
                let expected=a[2], name=a[3], ws=NSWorkspace.shared
                guard a[0]=="capture", !name.isEmpty else {finish(out,["error":"request does not name a synthetic window"],2)}
                guard let front=ws.frontmostApplication, front.bundleIdentifier==expected else {finish(out,["error":"requested test app is not frontmost"],3)}
                let initialEDR=NSScreen.main?.maximumExtendedDynamicRangeColorComponentValue ?? -1
                do {
                    let sc=try await SCShareableContent.excludingDesktopWindows(true,onScreenWindowsOnly:true)
                    let candidates=sc.windows.filter { w in
                        guard w.owningApplication?.processID==front.processIdentifier, w.windowLayer==0,w.frame.width>=180,w.frame.height>=120 else {return false}
                        if expected=="com.apple.Photos",name.hasPrefix("isolated-confirmed-id:") {
                            return name==("isolated-confirmed-id:"+String(w.windowID))
                        }
                        return w.title?.localizedCaseInsensitiveContains(name) ?? false
                    }
                    guard candidates.count==1,let w=candidates.first else {finish(out,["error":"expected exactly one matching synthetic window","matches":candidates.count],4)}
                    let filter=SCContentFilter(desktopIndependentWindow:w)
                    let scale=min(1.0,1600/w.frame.width)
                    let config=SCScreenshotConfiguration()
                    config.displayIntent = .local
                    config.dynamicRange = .bothSDRAndHDR
                    config.showsCursor = false
                    config.ignoreShadows = true
                    config.includeChildWindows = false
                    config.width=Int(w.frame.width*scale)
                    config.height=Int(w.frame.height*scale)
                    let output=try await SCScreenshotManager.captureScreenshot(contentFilter:filter,configuration:config)
                    guard ws.frontmostApplication?.processIdentifier==front.processIdentifier else {finish(out,["error":"focus changed during capture, no pixels saved"],5)}
                    var captureMode = output.hdrImage != nil ? "HDR local screenshot" : "SDR local screenshot"
                    var selected = output.hdrImage
                    if selected == nil {
                        let legacy=SCStreamConfiguration(preset:.captureHDRScreenshotLocalDisplay)
                        legacy.width=config.width
                        legacy.height=config.height
                        legacy.showsCursor=false
                        legacy.ignoreShadowsSingleWindow=true
                        if let im=try? await SCScreenshotManager.captureImage(contentFilter:filter,configuration:legacy) {
                            captureMode="HDR local stream preset"
                            selected=im
                        }
                    }
                    guard let hdr=selected ?? output.sdrImage else {finish(out,["error":"capture returned no image"],6)}
                    guard ws.frontmostApplication?.processIdentifier==front.processIdentifier else {finish(out,["error":"focus changed during fallback, no pixels saved"],5)}
                    let cs=CGColorSpace(name:CGColorSpace.extendedLinearDisplayP3)!
                    let ctx=CIContext(options:[.workingColorSpace:cs])
                    let ci=CIImage(cgImage:hdr)
                    var raw=Data(count:hdr.width*hdr.height*8)
                    raw.withUnsafeMutableBytes { b in
                        ctx.render(ci,toBitmap:b.baseAddress!,rowBytes:hdr.width*8,bounds:ci.extent,format:.RGBAh,colorSpace:cs)
                    }
                    try raw.write(to:out.appendingPathExtension("rgba16"),options:.atomic)
                    let preview=output.sdrImage ?? ctx.createCGImage(ci,from:ci.extent,format:.RGBA8,colorSpace:CGColorSpace(name:CGColorSpace.sRGB)!)
                    if let sdr=preview, let dest=CGImageDestinationCreateWithURL(out.appendingPathExtension("png") as CFURL, UTType.png.identifier as CFString,1,nil) {
                        CGImageDestinationAddImage(dest,sdr,nil)
                        _=CGImageDestinationFinalize(dest)
                    }
                    finish(out,["windowID":w.windowID,"target":expected,"fixtureKey":name,"width":hdr.width,"height":hdr.height,
                         "captureMode":captureMode,"hdrComponents":hdr.bitsPerComponent,"sdrComponents":preview?.bitsPerComponent ?? 0,
                         "hdrColorSpace":hdr.colorSpace?.name as String? ?? "unnamed",
                         "EDRBefore":initialEDR,"EDRAfter":NSScreen.main?.maximumExtendedDynamicRangeColorComponentValue ?? -1,
                         "EDRPotential":NSScreen.main?.maximumPotentialExtendedDynamicRangeColorComponentValue ?? -1,
                         "captureDate":ISO8601DateFormatter().string(from:Date()),"rawRowOrigin":"bottom-left","rawColor":"extended linear Display P3 RGBA Float16 little-endian"])
                } catch {finish(out,["error":String(describing:error)],8)}
            }
        }
        app.run()
    }
}
