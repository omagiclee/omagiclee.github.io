import Foundation
import ImageIO
import CoreGraphics
import CoreImage

let args = Array(CommandLine.arguments.dropFirst())
guard [1,5,7].contains(args.count),
      let src = CGImageSourceCreateWithURL(URL(fileURLWithPath: args[0]) as CFURL,nil),
      let img = CGImageSourceCreateImageAtIndex(src,0,[kCGImageSourceDecodeRequest:kCGImageSourceDecodeToHDR] as CFDictionary)
else { fatalError("use sample capture.heic [left top width height [SDRWhiteX SDRWhiteY]]") }
let dimensions = args.dropFirst().compactMap(Double.init)
guard dimensions.count == args.count-1 else { fatalError("bad coordinates") }
let w = Double(img.width), h = Double(img.height)
let bounds = dimensions.isEmpty ? [0,0,w,h] : Array(dimensions[0..<4])
let color = CGColorSpace(name:CGColorSpace.extendedLinearDisplayP3)!
let ci = CIImage(cgImage:img), ctx = CIContext(options:[.workingColorSpace:color,.useSoftwareRenderer:true])
let side=9
func sample(_ x:Double,_ y:Double)->[String:Any] {
    guard x>=5, x<w-5, y>=5, y<h-5 else { fatalError("patch outside of image") }
    var rgba=[Float](repeating:-1,count:side*side*4)
    rgba.withUnsafeMutableBytes { out in
        ctx.render(ci,toBitmap:out.baseAddress!,rowBytes:side*16,
            bounds:CGRect(x:Int(x)-side/2,y:Int(h-y)-side/2,width:side,height:side),
            format:.RGBAf,colorSpace:color)
    }
    guard rgba[3]>0.5 else { fatalError("Core Image did not render opaque samples; check capture coordinates and execution environment") }
    let med=(0..<3).map { k in
        stride(from:k,to:rgba.count,by:4).map{Double(rgba[$0])}.sorted()[side*side/2]
    }
    let ym=0.228975*med[0]+0.691739*med[1]+0.079287*med[2]
    func quant(_ x:Double)->Double { (x*100000).rounded()/100000 }
    return ["x":quant(x), "y":quant(y), "r":quant(med[0]),"g":quant(med[1]), "b":quant(med[2]),"Y":quant(ym)]
}
var data:[String:Any]=["captureWidth":img.width,"captureHeight":img.height,"bitsPerComponent":img.bitsPerComponent,
                          "captureHeadroom":img.contentHeadroom,"captureProfile":img.colorSpace?.name as String? ?? "(unnamed)"]
let rows=[232.0,488.0].map { n in
    (0..<8).map { i in
        sample(bounds[0]+(80+160*Double(i))/1280*bounds[2],bounds[1]+n/720*bounds[3])
    }
}
data["gray"]=rows[0]; data["color"]=rows[1]
let Y=(rows[0][4]["Y"] as? Double) ?? 0
if Y>0.0001 { data["grayOver203"]=rows[0].map{(($0["Y"] as? Double) ?? 0)/Y} }
if dimensions.count==6 {
    data["appSDRWhite"]=sample(dimensions[4],dimensions[5])
    let W=((data["appSDRWhite"] as? [String:Any])?["Y"] as? Double) ?? 0
    if W>0.0001 { data["grayOverAppWhite"]=rows[0].map{(($0["Y"] as? Double) ?? 0)/W} }
}
let bytes=try JSONSerialization.data(withJSONObject:data,options:[.prettyPrinted,.sortedKeys])
print(String(decoding:bytes,as:UTF8.self))
