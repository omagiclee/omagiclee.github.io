import fs from "node:fs"
import {pathToFileURL} from "node:url"
import {join} from "node:path"
const {scaleLog,line}=await import(process.env.D3_PATH ? pathToFileURL(join(process.env.D3_PATH,'src','index.js')).href : 'd3')
const latest=JSON.parse(fs.readFileSync(process.argv[2]??'player-transfer-results.json','utf8'))
const target=[.5,5,25,100,203,400,800,1000]
if(latest.length!==3||latest.some(x=>!x.ratios||x.ratios.length!==8||!x.ratios.every(Number.isFinite)))throw new Error('Unexpected off-screen data')
const W=760,H=474, left=91,right=690, top=124,bottom=364
const x=scaleLog().domain([.5,1000]).range([left,right])
const y=scaleLog().domain([.002,6]).range([bottom,top])
const fmt=n=>Number(n.toFixed(2))
const draw=line().x((_,i)=>x(target[i])).y(t=>y(t))
const a=[]
a.push('<svg xmlns="http://www.w3.org/2000/svg" role="img" viewBox="0 0 '+W+' '+H+'"><title>离屏 HDR 视频 PQ 与 HLG 浮点帧对照</title><desc>PQ 高光对参考白为 4.94 倍，HLG 3.77 倍。带 AMVE 的 HLG 与无 AMVE 的曲线重合。图是 AVPlayerItemVideoOutput 浮点帧，不是应用窗口或屏幕。</desc>')
a.push('<rect width="100%" height="100%" rx="14" fill="#f9fbfe"/><g font-family="system-ui,PingFang SC,sans-serif" fill="#253345" font-size="14">')
a.push('<text x="44" y="39" font-size="22" font-weight="650">PQ 与 HLG 离屏浮点帧：配对控制</text>')
a.push('<text x="44" y="64" fill="#536276">macOS 27.2 · AVPlayerItemVideoOutput · 线性 Display P3</text>')
a.push('<text x="44" y="87" fill="#536276">这是播放框架转换层，不是应用窗口合成或显示器出光。</text>')
for(const t of [.002,.01,.1,1,5]){
 const yy=y(t)
 a.push('<line x1="'+left+'" y1="'+fmt(yy)+'" x2="'+right+'" y2="'+fmt(yy)+'" stroke="'+(t===1?'#9cadc4':'#dbe3ef')+'"/><text x="'+(left-8)+'" y="'+fmt(yy+5)+'" text-anchor="end">'+t+'×</text>')
}
for(const t of [.5,5,25,100,203,400,1000]){
 const xx=x(t)
 a.push('<line x1="'+fmt(xx)+'" y1="'+top+'" x2="'+fmt(xx)+'" y2="'+bottom+'" stroke="#e4eaf2"/><text x="'+fmt(xx)+'" y="'+(bottom+20)+'" text-anchor="middle">'+t+'</text>')
}
a.push('<text transform="translate(24 245) rotate(-90)" text-anchor="middle">浮点帧亮度相对 203 nit 测试块</text>')
a.push('<text x="'+((left+right)/2)+'" y="'+(bottom+45)+'" text-anchor="middle">母版目标 / nit</text>')
a.push('<path d="'+draw(target.map(t=>t/203))+'" fill="none" stroke="#64748b" stroke-width="2" stroke-dasharray="5 4"/>')
for(const [i,data] of latest.slice(0,2).entries()){
 let co=['#006a9d','#a34b13'][i]
 a.push('<path d="'+draw(data.ratios)+'" fill="none" stroke="'+co+'" stroke-width="2.3"/>')
 for(const [j,r] of data.ratios.entries()){
   a.push('<circle cx="'+fmt(x(target[j]))+'" cy="'+fmt(y(r))+'" r="3.5" fill="'+co+'"><title>'+target[j]+' nit: '+r.toPrecision(4)+'×</title></circle>')
 }
 const val=data.ratios[7]
 a.push('<text x="'+(right+12)+'" y="'+fmt(y(val)+(i?14:-5))+'" fill="'+co+'" font-size="15" font-weight="650">'+val.toFixed(2)+'×</text>')
}
for(const [i,[name,color,dash,sx]] of [['PQ','#006a9d','',92],['HLG（有／无 AMVE 重合）','#a34b13','',212],['母版参考','#64748b','5 4',521]].entries()){
 a.push('<path d="M '+sx+' 442 h 25" stroke="'+color+'" stroke-dasharray="'+dash+'" stroke-width="2.3"/><text x="'+(sx+34)+'" y="447">'+name+'</text>')
}
a.push('</g></svg>')
fs.writeFileSync(process.argv[3]??'hdr-video-buffer-curves.svg',a.join('\n'))
