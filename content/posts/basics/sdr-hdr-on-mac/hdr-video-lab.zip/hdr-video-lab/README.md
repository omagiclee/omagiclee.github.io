# HDR 视频真机对照样片

这份目录是用于跨播放器测量的合成视频，不含个人素材。请用同一台开启 HDR 的 Mac、同一屏、同一显示模式和应用前台窗口测量。保持测试窗口和视频内容矩形面积尽量一致。截图使用 macOS 的 HDR 模式（HEIC，或 ScreenCaptureKit HDR 本显示器路径），不是普通 SDR 截图和浏览器截图。记录每次截图时实际 HDR 余量、应用版本、窗口尺寸。宏观结论只外推到这里的文件、状态和测量阈值，不把应用未测项算作一致。

## 素材

- `hdr-pq-bt2020.mp4`、`hdr-hlg-bt2020.mp4`：1280×720、24 fps、12 秒、HEVC Main10 (hvc1)，BT.2020 NCL、10-bit 4:2:0、有限范围。
- PQ 曲线由 ST 2084 逆 EOTF 构造；静态 MDCV 为 BT.2020/D65/1000 nit，MaxCLL 1000、MaxFALL 55。FFprobe trace_headers 确认 hvcC extradata 和关键帧均有这两项 SEI。
- HLG 与 PQ 共享同一套**显示目标**。对 HLG 反算场景域 RGB，再用 HLG OETF 编码。假设 1000 nit 标称峰值、系统 gamma 1.2、黑位偏置 0。两条片规避了「把 PQ 数据直接重贴 HLG 标签」。
- `hdr-hlg-amve-bt2020.mp4` 是可选 AMVE 单变量控制。它只比基础 HLG 在 hvc1 样本描述中多 314 lx/D65 项。mdat 内容和解码帧 SHA256 相同，色彩标签未改。如果某端不带 AMVE 和带 AMVE 的结果不同，这才是说明该路径受该元数据影响的实测。
- `gen.py`、`add_amve.py` 可在 Python 与有 libx265 的 FFmpeg 上重建。CSV 列出目标光度、Y′CbCr 码字和回算后值。FFmpeg 第 2 秒采样 2×16×3 个码字，每个抽样与对应输入完全相同。AVFoundation 另实际解出了三份文件的首帧且 PQ/HLG 标签保持不变，仅做解码链路定位。
- `hdr-video.html` 无滤镜、色彩效果或网站选流。用支持 Range 的本地 HTTP 服务。默认 PQ，可按 HLG 按钮或用 ?format=hlg。左右尺布局一致。视频下方白块是 CSS 纯白，后两类原生播放器没有这个参照。测试窗口不必全屏，默认不显示视频控制层。

## 测量

- 两排各八块，坐标基于影像区域。视频内容实际边界为左上 x0、y0、宽 w、高 h；第 i 列中心 x=x0+(80+160*i)/1280*w，i 从 0 开始。第一排 y=y0+232/720*h，第二排 y=y0+488/720*h。两排最右位置和背景不能误采进播放器黑边、控制栏或 CSS 纯白。
- 第一排是 0.5、5、25、100、203、400、800、1000 nit 的设计目标。203 用作母版参考白，不能直接当作每个播放器中的实际 SDR 白。可以报告第一排后 3 块对 203 块的比值，以及 1000/203 理论目标 4.926。截图后的物理亮度仍需光度计。
- 若截图越过显示器合成至 Tone Map，报告「合成 EDR 取样」，不称为 nit。即使普通截图能输出 PNG 或 HEIC，也不保证保留 HDR；先看捕获模式和已知基准是否保留超过 1 的线性高光。仅当清楚是 HDR 捕获才比较 EDR，不能把某帧读数 1.0 立即当作应用 SDR 回退。
- 用截图坐标点而不是逻辑视图单位。例如 `swiftc sample.swift -o sample`，`./sample capture.heic x0 y0 w h`，可再给 app 白块像素位置。取 9×9 中位数，转换到扩展线性 Display P3，Y=0.228975R+0.691739G+0.079287B。量化前需复查背景，视觉色度可比较相同色块 R/G/B 比例。窗口可以用全图中确定的实际范围，也可以在截图 UI 选区时只选视频本体。程序若在工具沙箱里拿不到 Core Image 服务，需用授权的解码入口，不得把 sentinel 当成读数。
- 同一浏览器有播放时间前进、帧计数不等同于屏幕显示。可把实际值落地为图：横轴目标灰阶 log，纵轴截图归一对 203，PQ/HLG 分栏，应用各一条曲线。四种播放器都分别测，Preview 不具备常规视频播放能力，标不适用。QuickTime 和照片如只能测预览暂停帧，需注明不是播放中 EDR。

## 离屏浮点输出的单独实验

`player-transfer.swift` 复用 Apple WWDC22 的 AVPlayerItemVideoOutput，取得扩展线性 Display P3 half-float 缓冲，不创建窗口。PQ 1000/203 从母版量化回算约 4.9297，实测输出 4.9398。HLG 1000/203 从参考显示回算约 4.9224，实测输出 3.7670，拟合指数 0.83319，接近移除 1.2 OOTF 后的 1/1.2；满信号约为 12，符合 Apple 的场景域约定。带 AMVE 的 HLG 这一步结果逐块相同。绝不把这个离屏比较当成 Chrome、Safari、QuickTime 或照片的应用窗口差异。参见 [Apple AVPlayerItemVideoOutput](https://developer.apple.com/videos/play/wwdc2022/110565/?time=693) 和 [CAEDRMetadata.hlg](https://developer.apple.com/documentation/quartzcore/caedrmetadata/hlg)。

## 根因对照

- [ITU-R BT.2100-3](https://www.itu.int/dms_pubrec/itu-r/rec/bt/R-REC-BT.2100-3-202502-I!!PDF-E.pdf) 的 PQ/HLG 参考传递及 [ITU-R BT.2408-9](https://www.itu.int/pub/R-REP-BT.2408-9-2026) 的参考白和互转实践。HLG 曲线在不同显示目标可变，不能把和 PQ 差异直接判 bug。
- [Apple HDR 文件元数据](https://developer.apple.com/av-foundation/High-Dynamic-Range-Metadata-for-Apple-Devices.pdf) 和 [Apple TN3145 AMVE](https://developer.apple.com/documentation/technotes/tn3145-hdr-video-metadata) 说明 HLG AMVE 对映射的意义；苹果外置兼容屏把 HLG 转成 HDR10，[Apple 支持](https://support.apple.com/en-us/102205)。
- [WebKit Safari 27.2 对应源码](https://github.com/WebKit/WebKit/blob/5e62f67e97ebccc9da92e1ab166cfe640767dea4/Source/WebCore/platform/graphics/avfoundation/objc/MediaPlayerPrivateAVFoundationObjC.mm#L628-L682) 中普通媒体的 AVPlayerLayer 及限幅；macOS 27.2 (26B123) 本机 WebCore arm64e.x1 的 dyld 未滑移锚点 createVideoLayer 0x1b8e2d8c8，createAVPlayerLayer 0x1b8e2dac8，setPlatformDynamicRangeLimit 0x1b8e2de24。静态符号不是当前样片实际执行证明。
- [Chromium macOS 合成源码](https://chromium.googlesource.com/chromium/src/+/master/ui/accelerated_widget_mac/ca_renderer_layer_tree.mm#302) 显示 overlay 将 IOSurface 装到 CVPixelBuffer，PQ 可附静态 hdr_metadata，HLG 则注入 viewing environment；[旧帧尺寸回归](https://issues.chromium.org/issues/572225701) 在 158 已验证修复且是 8 bit 路径，不能当本实验原因。实际配置需有 overlay / CSS / compositing 单变量 A/B。
- [Apple AVPlayer EDR 说明](https://developer.apple.com/videos/play/wwdc2021/10161/) 和 [照片 HLG 播放文档](https://support.apple.com/en-ie/guide/photos/phte8a1fcd79/mac) 用于区分 SDK 实现、应用能力、真实合成。仅有解码证据不能宣称原生应用之间无差异。
