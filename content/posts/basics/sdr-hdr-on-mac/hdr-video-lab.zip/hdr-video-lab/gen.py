#!/usr/bin/env python3
from array import array
from pathlib import Path
import csv, json, math, subprocess, sys
W,H,FPS,N=1280,720,24,12
K=(.2627,.6780,.0593)
GRAYS=[(n,n,n) for n in (0.5,5,25,100,203,400,800,1000)]
COLORS=[(390,80,62),(63,350,89),(80,91,510),(320,210,125),(140,260,330),(235,100,240),(120,83,56),(203,203,203)]
YCS=(232,488)
BG=(18,18,18)
L=1000.0
GAMMA=1.2
A=.17883277
B=1-4*A
C=.5-A*math.log(4*A)
def pq(l):
    p=(l/10000.)**(2610/16384)
    return ((3424/4096 + (2413/128)*p)/(1+(2392/128)*p))**(2523/32)
def hlg(x):
    return math.sqrt(3*x) if x<=1/12 else A*math.log(12*x-B)+C
def dot(v):
    return sum(a*b for a,b in zip(v,K))
def transfer(rgb, kind):
    if kind=='pq': return tuple(pq(c) for c in rgb)
    ys=(dot(rgb)/L)**(1/GAMMA)
    if ys==0: return 0,0,0
    es=tuple(c/L/ys**(GAMMA-1) for c in rgb)
    if max(es)>1: raise ValueError((rgb, es))
    return tuple(hlg(c) for c in es)
def code(rgb, kind):
    r,g,b=transfer(rgb,kind)
    y=dot((r,g,b))
    cb=(b-y)/(2*(1-K[2]))
    cr=(r-y)/(2*(1-K[0]))
    return (round(64+876*y),round(512+896*cb),round(512+896*cr))
def rgb_from_code(codes,kind):
    y=(codes[0]-64)/876
    cb=(codes[1]-512)/896
    cr=(codes[2]-512)/896
    r=y+2*(1-K[0])*cr
    b=y+2*(1-K[2])*cb
    g=(y-K[0]*r-K[2]*b)/K[1]
    r,g,b=(min(max(c,0),1) for c in (r,g,b))
    if kind=='pq':
        def eotf(e):
            p=e**(32/2523)
            return 10000*(max(0,p-3424/4096)/(2413/128-(2392/128)*p))**(16384/2610)
        return tuple(eotf(c) for c in (r,g,b))
    e=tuple(x*x/3 if x<=.5 else (math.exp((x-C)/A)+B)/12 for x in (r,g,b))
    return tuple(L*dot(e)**(GAMMA-1)*x for x in e)
def frame(kind):
    bg=code(BG,kind)
    planes=[array('H',[v])*(W//s * (H//s)) for v,s in zip(bg,(1,2,2))]
    rows=[]
    for row, (yc, vals) in enumerate(zip(YCS,(GRAYS,COLORS))):
        for i,rgb in enumerate(vals):
            xc=80+160*i
            yuv=code(rgb,kind)
            restore=rgb_from_code(yuv,kind)
            rows.append((kind,'gray' if row==0 else 'color',i+1,xc/W,yc/H,*rgb,dot(rgb),*yuv,*(round(x,4) for x in restore),round(dot(restore),4)))
            for plane,v,s in zip(planes,yuv,(1,2,2)):
                size=96//s
                left,y0=(xc-48)//s,(yc-48)//s
                w=W//s
                block=array('H',[v])*size
                for y in range(y0,y0+size):
                    plane[y*w+left:y*w+left+size]=block
    if sys.byteorder!='little':
        for p in planes:p.byteswap()
    return b''.join(p.tobytes() for p in planes),rows
def encode(kind, frame):
    trc={'pq':'smpte2084','hlg':'arib-std-b67'}[kind]
    tags=['-color_range','tv','-color_primaries','bt2020','-color_trc',trc,'-colorspace','bt2020nc','-chroma_sample_location','left']
    x265='pools=2:frame-threads=2:log-level=error:keyint=24:min-keyint=24:scenecut=0:repeat-headers=1:range=limited:colorprim=bt2020:colormatrix=bt2020nc:transfer='+trc
    if kind=='pq':
        # BT.2020 mastering primaries and D65, MaxCLL 1000; a conservative
        # 55 cd/m2 MaxFALL; area-weighted designed average is 54.82.
        x265+=':hdr10=1:master-display=G(8500,39850)B(6550,2300)R(35400,14600)WP(15635,16450)L(10000000,50):max-cll=1000,55'
    args=['ffmpeg','-hide_banner','-loglevel','error','-y',
          '-f','rawvideo','-pix_fmt','yuv420p10le','-s',f'{W}x{H}','-r',str(FPS),*tags,'-i','pipe:',
          '-c:v','libx265','-preset','fast','-profile:v','main10','-x265-params',x265,'-qp','8',
          '-tag:v','hvc1','-pix_fmt','yuv420p10le',*tags,'-movflags','+faststart+write_colr',f'hdr-{kind}-bt2020.mp4']
    p=subprocess.Popen(args,stdin=subprocess.PIPE)
    with p.stdin:
        for i in range(N*FPS):p.stdin.write(frame)
    if p.wait():raise RuntimeError(f'{kind} encode failed')
def sample_decoded(kind):
    f=Path(f'hdr-{kind}-bt2020.mp4')
    trc={'pq':'smpte2084','hlg':'arib-std-b67'}[kind]
    result=subprocess.check_output(['ffmpeg','-hide_banner','-loglevel','error','-threads','1','-ss','2','-i',str(f),'-frames:v','1','-pix_fmt','yuv420p10le','-color_range','tv','-color_primaries','bt2020','-color_trc',trc,'-colorspace','bt2020nc','-f','rawvideo','pipe:'])
    codewords=array('H'); codewords.frombytes(result)
    if sys.byteorder!='little':codewords.byteswap()
    patches=[]
    for row,y in enumerate(YCS):
        for i in range(8):
            x=80+160*i
            expected=code((GRAYS,COLORS)[row][i],kind)
            yy=codewords[y*W+x]
            chroma=(y//2)*(W//2)+x//2
            cc=(codewords[W*H+chroma],codewords[W*H+W*H//4+chroma])
            patches.append({'row':row+1,'id':i+1,'actual':[yy,*cc],'expected':expected,'delta':[k-e for k,e in zip((yy,*cc),expected)]})
    return patches
out=[]
data={}
for f in ('pq','hlg'):
    raw, rows=frame(f)
    out.extend(rows)
    encode(f,raw)
    data[f]=sample_decoded(f)
with open('expectation.csv','w',newline='') as f:
    w=csv.writer(f)
    w.writerow(['kind','row','patch','u','v','target_r_nit','target_g_nit','target_b_nit','target_y_nit','input_Y10','input_Cb10','input_Cr10','restored_r_nit','restored_g_nit','restored_b_nit','restored_y_nit'])
    w.writerows(out)
Path('decoded-2s.json').write_text(json.dumps(data,indent=2)+'\n')
