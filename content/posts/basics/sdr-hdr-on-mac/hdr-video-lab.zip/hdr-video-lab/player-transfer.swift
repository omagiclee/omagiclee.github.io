import Foundation
import AVFoundation
import CoreVideo
import QuartzCore

func decode(_ path:String) throws -> [String:Any] {
    let url=URL(fileURLWithPath:path), item=AVPlayerItem(url:url), player=AVPlayer(playerItem:item)
    player.isMuted=true
    // The WWDC22 WWDC2022/110565 extended-linear output route, with no layer.
    let opts:[String:Any]=[
        AVVideoAllowWideColorKey:true,
        AVVideoColorPropertiesKey:[AVVideoColorPrimariesKey:AVVideoColorPrimaries_P3_D65,
                                   AVVideoTransferFunctionKey:AVVideoTransferFunction_Linear,
                                   AVVideoYCbCrMatrixKey:AVVideoYCbCrMatrix_ITU_R_2020],
        kCVPixelBufferPixelFormatTypeKey as String:NSNumber(value:kCVPixelFormatType_64RGBAHalf)
    ]
    let out=AVPlayerItemVideoOutput(outputSettings:opts)
    item.add(out)
    player.play()
    defer{player.pause();item.remove(out)}
    let end=Date().addingTimeInterval(6)
    while Date()<end {
        _=RunLoop.main.run(mode:.default,before:Date().addingTimeInterval(0.025))
        if let error=item.error {throw error}
        let time=out.itemTime(forHostTime:CACurrentMediaTime())
        if !time.isNumeric || time.seconds<0.04 {continue}
        if let pixel=out.copyPixelBuffer(forItemTime:time,itemTimeForDisplay:nil) {
            precondition(CVPixelBufferGetPixelFormatType(pixel)==kCVPixelFormatType_64RGBAHalf)
            precondition(CVPixelBufferGetWidth(pixel)==1280 && CVPixelBufferGetHeight(pixel)==720)
            let stride=CVPixelBufferGetBytesPerRow(pixel)
            CVPixelBufferLockBaseAddress(pixel,.readOnly)
            defer{CVPixelBufferUnlockBaseAddress(pixel,.readOnly)}
            let base=CVPixelBufferGetBaseAddress(pixel)!
            let rows=[232,488].map{ y in
                (0..<8).map{i in
                    let data=base.advanced(by:y*stride+(80+160*i)*8).assumingMemoryBound(to:UInt16.self)
                    let rgb=(0..<3).map{Double(Float16(bitPattern:data[$0]))}
                    let luma=rgb[0]*0.228975+rgb[1]*0.691739+rgb[2]*0.079287
                    return ["rgb":rgb as Any,"Y":luma as Any]
                }
            }
            let gray=rows[0].map{$0["Y"] as! Double}
            return ["file":url.lastPathComponent,"pixelFormat":"RGBA16f","timeSec":time.seconds,
                    "gray":rows[0],"color":rows[1],"ratios":gray.map{$0/gray[4]}]
        }
    }
    return ["file":url.lastPathComponent,"error":"AVPlayerItemVideoOutput timed out","rate":player.rate,"status":item.status.rawValue]
}
var cases=[[String:Any]]()
for f in CommandLine.arguments.dropFirst() {
    do {cases.append(try decode(f))}
    catch{cases.append(["file":f,"error":String(describing:error)])}
}
let data=try JSONSerialization.data(withJSONObject:cases,options:[.prettyPrinted,.sortedKeys])
print(String(decoding:data,as:UTF8.self))
