#!/usr/bin/env python3
"""Add one AMVE box to the test asset's single hvc1 sample description.
Preserves the mdat bytes and all color tags. No re-encode.
"""
from pathlib import Path
import struct
import hashlib
import sys

def children(data,start,end):
    i=start
    while i<end:
        size,kind=struct.unpack_from('>I4s',data,i)
        if size<8 or i+size>end:
            raise ValueError((i,size,kind,end))
        yield i,size,kind
        i+=size
    if i!=end:
        raise ValueError((i,end))
src=Path(sys.argv[1]); dst=Path(sys.argv[2])
data=bytearray(src.read_bytes())
def child(parent,kind,skip=0):
    start,size,_=parent
    return next(b for b in children(data,start+8+skip,start+size) if b[2]==kind)
top=(0,len(data)+8,b'top')
def top_child(kind):
    return next(b for b in children(data,0,len(data)) if b[2]==kind)
moov=top_child(b'moov')
mdat=top_child(b'mdat')
trak=child(moov,b'trak');mdia=child(trak,b'mdia');minf=child(mdia,b'minf');stbl=child(minf,b'stbl')
stsd=child(stbl,b'stsd');hvc1=child(stsd,b'hvc1',8)
exts=list(children(data,hvc1[0]+8+78,hvc1[0]+hvc1[1]))
assert any(t==b'hvcC' for _,_,t in exts)
assert all(t!=b'amve' for _,_,t in exts)
insert=hvc1[0]+hvc1[1]
amve=struct.pack('>I4sIHH',16,b'amve',3140000,15635,16450)
stco=next(b for b in children(data,stbl[0]+8,stbl[0]+stbl[1]) if b[2] in (b'stco',b'co64'))

for i,n,t in (moov,trak,mdia,minf,stbl,stsd,hvc1):
    struct.pack_into('>I',data,i,n+len(amve))
cfmt,cn=('>I',4) if stco[2]==b'stco' else ('>Q',8)
entry_count=struct.unpack_from('>I',data,stco[0]+12)[0]
for s in range(entry_count):
    offset_position=stco[0]+16+cn*s
    offset=struct.unpack_from(cfmt,data,offset_position)[0]
    if offset>=insert:
        struct.pack_into(cfmt,data,offset_position,offset+len(amve))
before=bytes(data[mdat[0]+8:mdat[0]+mdat[1]])
data[insert:insert]=amve
shift=len(amve) if mdat[0]>=insert else 0
after=bytes(data[mdat[0]+8+shift:mdat[0]+mdat[1]+shift])
assert before==after
dst.write_bytes(data)
print('mdat SHA256',hashlib.sha256(after).hexdigest())
