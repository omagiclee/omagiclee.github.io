# Safari 27.2 HDR 增益图：已交付二进制静态证据

取自本机 macOS 27.2 arm64e.x1 dyld 共享缓存，WebKit UUID `A622C7F9-1BD8-3EA8-A052-6A60284BE346`，WebCore UUID `5F2C9FCD-18A3-3486-9AD8-8DAD803DA656`。以下均为未加 ASLR slide 的地址，不是进程动态 trace。

| 二进制中的位置 | 能直接看到的动作 |
|---|---|
| WebCore `ImageDecoderCG::frameGainMapAtIndex` `0x1BB57091C` | 先在 `0x1BB5709D4` 以 `kCGImageAuxiliaryDataTypeISOGainMap` 调 ImageIO；没有结果则在 `0x1BB570A38` 再试 `kCGImageAuxiliaryDataTypeHDRGainMap`，即 Apple 专用辅助图类型 |
| WebKit `RemoteRenderingBackend::cacheNativeImage` `0x1A495E64C` | `0x1A495E68C` 建 ShareableBitmap，`0x1A495E6A4` 调 `ShareableBitmap::createPlatformImage`；后者在 `0x1B89BA244` 遇到增益图才调用 `ShareableGainMap::applyGainMapToBaseImage`，失败回基图。回到调用者在 `0x1A495E6B0` 建 NativeImage，在 `0x1A495E6E0` 将其缓存 |
| 基图转 CVPixelBuffer `0x1BB577BBC` | `0x1BB577C00` 读取原 CGImage 的色彩空间并保存在 `x20`。创建 32BGRA 基图缓冲时 `0x1BB577C28` 把第四个参数 `x3`（色彩空间）设为 0，随后在 `0x1BB577C2C` 调 Metal scratch wrapper |
| Metal scratch wrapper `0x1BB577A64` | 保存输入色彩空间 `x3` 到 `x19`，在 `0x1BB577B3C` 转发到 `x4`，`0x1BB577B40` 调通用 scratch helper。该 wrapper 只设置 IOSurface 和 Metal 兼容性属性 |
| 通用 scratch helper `0x1BB5778C8` | `0x1BB577924` 调 CVPixelBufferCreate。若输入色彩空间为空，`0x1BB577958` 的 `cbz x20` 直接跨过 `kCVImageBufferCGColorSpaceKey` 查找和 `0x1BB577984` attachment 设置。后者使用槽 `0x1EF386EE8`，初始目标 `0x1BB40F428` 实际符号 `WebCore::initCoreVideoCVBufferSetAttachment` |
| 基图像素填充 `0x1BB577C7C–0x1BB577CA4` | `w3=8`（bits per component），`x5=x20`（真正的输入色彩空间）传给 `CGBitmapContextCreate`，之后 `CGContextDrawImage` 写像素；结束只解锁／返回，没有补色彩空间 attachment。故「用正确色域写了字节」不等同于「下游收到带该色域标签的缓冲区」 |
| 合并参数 `0x1BB5856CC–0x1BB585820` | 重新取原 CGImage 的色彩空间，再放进输入参数字典用于确定 HDR 目标格式。这个字典和实际基图 PixelBuffer 自身 attachment 是不同对象 |
| 重建 `ShareableGainMap::applyGainMapToBaseImage` `0x1BB585590` | `0x1BB585660` 读 Display P3 PQ 常量，并在 `0x1BB58567C` 取 gain map headroom。在 `0x1BB585AB0` 调 ImageIO `CGImageApplyHDRGainMap`，成功后从目标缓冲的 IOSurface 建 CGImage（`0x1BB585BF0`）；若合并返回失败，caller 可回退基图 |
| 绘制 | `RemoteGraphicsContext::drawNativeImage` `0x1A49379B4` 按资源 ID 查到已缓存的 NativeImage，`0x1A4937AB4` 经虚表 `+0x1a8` 分派；若 receiver 为 `GraphicsContextCG`，槽 `0x1E6A8B738` 对应 `0x1BB56373C`。`0x1BB563960/96C` 读上下文 EDR 与色调映射状态，`0x1BB5639F8` 实际画图，另有条件性设置 EDR 和 tone mapping 的分支 |

复核方式：`dyld_info -disassemble` 找 C++ 函数体与 ARM64e 指令，再用 `dyld_info -exports` / `-lookup_va` 对照。跨库分支需从 stub 的 ADRP/ADD/LDR 还原共享缓存指针槽的未滑移目标地址，然后跟相应 dylib 的导出位置交叉校验。

## ImageIO 为什么会把无色彩标签的基图解释成 sRGB

同一机器的 ImageIO UUID 为 `7E767ECC-2A80-3BA9-A0E0-EB50118EF1B3`。这部分来自 Apple 已交付二进制，不依赖 WebKit 仓库推测。

| 未滑移地址 | 观察 |
|---|---|
| `0x18D6635EC / 0x18D663628` | ImageIO `CGImageApplyHDRGainMap` 入口和对 `_IIOApplyHDRGainMap`（`0x18D663640`）的直调 |
| `0x18D6636E4` | `_IIOApplyHDRGainMap` 把实际基图缓冲、增益图、元数据交给 `HDRImage` 的 `initWithImageBuffer:gainMapBuffer:gainMapMetadata:imageProperties:`。ObjC 调用 stub `0x19005BCE0` 还原到该 selector，classref `0x1E08255A0` 解析到 `_OBJC_CLASS_$_HDRImage`。输出缓冲另在 `0x18D6637E4` 包成另一个 HDRImage |
| `0x18D66390C / 0x18D67178C` | ImageIO 把源/目标 HDRImage 交给 `-[HDRImageConverter convertImage:toImage:]`。转换器从源对象请求 `inputTransformToEDR:`，进而计算输入像素、颜色和增益图矩阵 |
| `0x18D66E08C / 0x18D66E9F0` | 普通输入色彩变换分支请求输入 `HDRImage.colorSpace`，将它作为源色彩空间用于传递函数/矩阵变换；增益图颜色矩阵分支在缺少合适的单独增益图色彩空间时，同样查询输入 `HDRImage.colorSpace`。这是条件分支而非对某一次 Safari 运行的逐调用观察 |
| `0x18D66A358 / 0x18D66A390` | `-[HDRImage colorSpace]` 尚未缓存颜色空间时从自身的 image buffer 调 `xdr_CVPixelBufferCopyColorSpace`（`0x18D66A404`） |
| `0x18D66A440 / 0x18D66A47C` | 先从实际 CVPixelBuffer 读 `kCVImageBufferCGColorSpaceKey`；没有则复制可传播的 attachments，尝试 `CVImageBufferCreateColorSpaceFromAttachments`。都得不到色彩空间则返回空 |
| `0x18D66A3DC–0x18D66A3E8` | 色彩空间为空时，用 GOT 槽 `0x1E017D0F8` 解析出的 CoreGraphics `kCGColorSpaceSRGB`（`0x1E0232D58`）调用 `CGColorSpaceCreateWithName` 并缓存。后续处理正是使用 sRGB 解释原字节，而非把原来的 P3 图先转换成 sRGB |

这说明为何「上游用 P3 写入缓冲」与「下游按 P3 读缓冲」可以同时脱钩。二进制证据证明此支路和 fallback 的存在，单变量实验确认附件有无足以改变控制样本的合并结果，最终应用截屏证明可见差异。三类证据不能互相替代。
