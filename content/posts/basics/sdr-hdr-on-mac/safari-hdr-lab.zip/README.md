# Safari 27.2 — HDR gain-map 实验附件

本包只含主动生成的合成样本、测量数值、原创探针和静态分析笔记。没有原始桌面截图。探针在独立进程中调用 macOS 的私有 ImageIO 入口，不读取或更改 Safari、Preview、显示设置，也不是可用于生产的稳定接口。

- 打开 `hdr-safari-ab.html` 可在同一个窗口中复现两种交付路径，上排 ISO RGB 增益图 JPEG，下排直接 Display P3 PQ PNG。显示器必须有可用 HDR/EDR 余量。不要将合成文件重编码为别的图片格式。
- `data/` 包含原始灰阶与 RGB 取样、同窗 A/B、软件解码和独立缓冲区矩阵。亮度数值是截图或缓冲的线性分量，不是显示器实测 nit。
- `gainmap-stage.mm` 在 macOS 27.2 上建 BGRA 底图缓冲，把带或不带色彩空间附件的相同字节交给 ImageIO，并从重建 IOSurface 取样。与已交付浏览器有部分等效参数，但不是 Safari 过程中的插桩记录。
- `sample-capture.swift` 可用人工从预览定位的色块矩形采样系统 HDR 截图。参数依次为文件、定位图宽高、横向色条左右坐标、取样段上下坐标。

## 复核缓冲区矩阵

```sh
xcrun clang++ -std=c++20 -fobjc-arc gainmap-stage.mm \
  -framework Foundation -framework CoreGraphics -framework ImageIO \
  -framework CoreImage -framework CoreVideo -framework IOSurface \
  -o gainmap-stage

./gainmap-stage gain-map.jpg
./gainmap-stage gain-map.jpg --base-untagged
./gainmap-stage gain-map.jpg --base-srgb
./gainmap-stage gain-map.jpg --gain-preserve
./gainmap-stage gain-map.jpg --gain-copy
./gainmap-stage gain-map.jpg --gain-copy --roundtrip-xmp
./gainmap-stage gain-map.jpg --base-untagged --gain-copy --roundtrip-xmp
```

前三组分别使用真实的基图 P3 附件、无附件、在不改变像素字节的前提下声明 sRGB。后四组隔离增益图缓冲区复制和 XMP 元数据往返。见 `data/gainmap-stage-matrix.txt`。以正式博文的完整进展为准，`window-ab-report.md`记录的是先做窗口 A/B 时的结论。
