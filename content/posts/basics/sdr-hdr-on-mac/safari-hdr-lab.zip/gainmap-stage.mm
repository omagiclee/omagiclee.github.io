#import <Foundation/Foundation.h>
#import <CoreGraphics/CoreGraphics.h>
#import <ImageIO/ImageIO.h>
#import <CoreImage/CoreImage.h>
#import <CoreVideo/CoreVideo.h>
#import <IOSurface/IOSurface.h>
#include <cstring>
#include <algorithm>

extern "C" {
CFDictionaryRef CGImageSourceCopyAuxiliaryDataInfoAtIndexWithOptions(CGImageSourceRef,size_t,CFStringRef,CFDictionaryRef);
CGFloat CGImageGetHDRGainMapHeadroom(CGImageMetadataRef,CFDictionaryRef);
OSStatus CGImageCreatePixelBufferAttributesForHDRTarget(uint32_t,CFDictionaryRef,CFDictionaryRef,CFDictionaryRef*);
OSStatus CGImageApplyHDRGainMap(CVPixelBufferRef,CVPixelBufferRef,CVPixelBufferRef,CFDictionaryRef);
CGImageRef CGImageCreateFromIOSurface(IOSurfaceRef,CFDictionaryRef);
extern const CFStringRef kCGImageAuxiliaryDataInfoColorSpace, kCGImageAuxiliaryDataInfoPixelBuffer;
extern const CFStringRef kCGImageAuxiliaryDataRepresentation, kCGImageAuxiliaryDataRepresentationPixelBuffer;
extern const CFStringRef kCGTargetPixelFormat, kCGTargetHeadroom, kCGTargetColorSpace, kCGFlexRangeAlternateColorSpace;
}
static NSString *fmt(OSType v) {
    return [NSString stringWithFormat:@"%c%c%c%c", v>>24&255,v>>16&255,v>>8&255,v&255];
}
static void samples(NSString *tag, CIImage *img, CIContext *ctx, CGColorSpaceRef l) {
    if (!img) { printf("%s unavailable\n", tag.UTF8String); return; }
    printf("%s ciHeadroom %.4f\n", tag.UTF8String, img.contentHeadroom);
    for (int i=0;i<8;++i) {
        float px[4]={-1,-1,-1,-1};
        [ctx render:img toBitmap:px rowBytes:16 bounds:CGRectMake(i*64+32,128,1,1) format:kCIFormatRGBAf colorSpace:l];
        printf("patch %d %.4f %.4f %.4f\n",i+1,px[0],px[1],px[2]);
    }
}
static CVPixelBufferRef clonePlanes(CVPixelBufferRef source, bool retainAttachments) {
    CVPixelBufferRef out=nullptr;
    NSDictionary *options=@{(__bridge id)kCVPixelBufferIOSurfacePropertiesKey:@{},(__bridge id)kCVPixelBufferMetalCompatibilityKey:@YES};
    if (CVPixelBufferCreate(kCFAllocatorDefault,CVPixelBufferGetWidth(source),CVPixelBufferGetHeight(source),CVPixelBufferGetPixelFormatType(source),(__bridge CFDictionaryRef)options,&out)) return nullptr;
    if(retainAttachments) CVBufferPropagateAttachments(source,out);
    CVPixelBufferLockBaseAddress(source,kCVPixelBufferLock_ReadOnly);
    CVPixelBufferLockBaseAddress(out,0);
    size_t planes=CVPixelBufferGetPlaneCount(source);
    for(size_t i=0;i<(planes?planes:1);i++) {
        auto s=(uint8_t*)(planes?CVPixelBufferGetBaseAddressOfPlane(source,i):CVPixelBufferGetBaseAddress(source));
        auto d=(uint8_t*)(planes?CVPixelBufferGetBaseAddressOfPlane(out,i):CVPixelBufferGetBaseAddress(out));
        auto sr=planes?CVPixelBufferGetBytesPerRowOfPlane(source,i):CVPixelBufferGetBytesPerRow(source);
        auto dr=planes?CVPixelBufferGetBytesPerRowOfPlane(out,i):CVPixelBufferGetBytesPerRow(out);
        auto ht=planes?CVPixelBufferGetHeightOfPlane(source,i):CVPixelBufferGetHeight(source);
        for(size_t y=0;y<ht;y++) memcpy(d+y*dr,s+y*sr,std::min(sr,dr));
    }
    CVPixelBufferUnlockBaseAddress(out,0);
    CVPixelBufferUnlockBaseAddress(source,kCVPixelBufferLock_ReadOnly);
    return out;
}

int main(int argc, const char** argv) {
  @autoreleasepool {
    if (argc<2 || argc>5) return 64;
    bool taggedBase=true, baseAsSRGB=false, cloneGain=false, keepGainAttachments=false, roundtrip=false;
    for (int i=2;i<argc;i++) {
       if (!strcmp(argv[i],"--base-untagged")) taggedBase=false;
       else if (!strcmp(argv[i],"--base-srgb")) baseAsSRGB=true;
       else if (!strcmp(argv[i],"--gain-copy")) cloneGain=true;
       else if (!strcmp(argv[i],"--gain-preserve")) {cloneGain=true;keepGainAttachments=true;}
       else if (!strcmp(argv[i],"--roundtrip-xmp")) roundtrip=true;
       else return 64;
    }
    printf("baseTagged=%d baseAsSRGB=%d gainCopied=%d gainKeepsAttachments=%d XMPReencoded=%d\n",taggedBase,baseAsSRGB,cloneGain,keepGainAttachments,roundtrip);
    NSURL *u=[NSURL fileURLWithPath:[NSString stringWithUTF8String:argv[1]]];
    CGImageSourceRef src=CGImageSourceCreateWithURL((__bridge CFURLRef)u,nullptr);
    if (!src) return 65;
    CGImageRef base=CGImageSourceCreateImageAtIndex(src,0,(__bridge CFDictionaryRef)@{(__bridge id)kCGImageSourceShouldCacheImmediately:@YES,(__bridge id)kCGImageSourceDecodeRequest:(__bridge id)kCGImageSourceDecodeToSDR});
    CGImageRef direct=CGImageSourceCreateImageAtIndex(src,0,(__bridge CFDictionaryRef)@{(__bridge id)kCGImageSourceDecodeRequest:(__bridge id)kCGImageSourceDecodeToHDR});
    if (!base || !direct) return 66;
    CGColorSpaceRef baseCS=CGImageGetColorSpace(base);
    CGColorSpaceRef linear=CGColorSpaceCreateWithName(kCGColorSpaceExtendedLinearDisplayP3);
    CIContext *ctx=[CIContext contextWithOptions:@{kCIContextWorkingColorSpace:(__bridge id)linear}];
    samples(@"default ImageIO HDR decode", [CIImage imageWithCGImage:direct], ctx, linear);
    auto auxOptions=@{(__bridge id)kCGImageAuxiliaryDataRepresentation:(__bridge id)kCGImageAuxiliaryDataRepresentationPixelBuffer};
    CFDictionaryRef aux=CGImageSourceCopyAuxiliaryDataInfoAtIndexWithOptions(src,0,kCGImageAuxiliaryDataTypeISOGainMap,(__bridge CFDictionaryRef)auxOptions);
    if (!aux) { printf("no ISO aux\n"); return 67; }
    auto gm=(CVPixelBufferRef)CFDictionaryGetValue(aux,kCGImageAuxiliaryDataInfoPixelBuffer);
    auto meta=(CGImageMetadataRef)CFDictionaryGetValue(aux,kCGImageAuxiliaryDataInfoMetadata);
    auto gmCS=(CGColorSpaceRef)CFDictionaryGetValue(aux,kCGImageAuxiliaryDataInfoColorSpace);
    if(!gm||!meta) return 68;
    CFDictionaryRef originalAttachments=CVBufferCopyAttachments(gm,kCVAttachmentMode_ShouldPropagate);
    if(originalAttachments) {
      printf("gain attachment keys:");
      for (NSString *key in (__bridge NSDictionary *)originalAttachments) printf(" %s",key.UTF8String);
      puts("");
      CFRelease(originalAttachments);
    }
    if(cloneGain) {
      gm=clonePlanes(gm,keepGainAttachments);
      if(!gm) return 73;
    }
    if(roundtrip) {
      auto bytes=CGImageMetadataCreateXMPData(meta,nullptr);
      if(!bytes) return 74;
      meta=CGImageMetadataCreateFromXMPData(bytes);
      CFRelease(bytes);
      if(!meta) return 75;
    }
    printf("gain map input %s %zux%zu colorSpace=%s\n",fmt(CVPixelBufferGetPixelFormatType(gm)).UTF8String,CVPixelBufferGetWidth(gm),CVPixelBufferGetHeight(gm),gmCS?"present":"absent");
    auto width=CGImageGetWidth(base),height=CGImageGetHeight(base);
    CVPixelBufferRef baseBuf=nullptr;
    auto storage=@{(__bridge id)kCVPixelBufferIOSurfacePropertiesKey:@{},(__bridge id)kCVPixelBufferMetalCompatibilityKey:@YES};
    CVReturn baseStatus=CVPixelBufferCreate(kCFAllocatorDefault,width,height,kCVPixelFormatType_32BGRA,(__bridge CFDictionaryRef)storage,&baseBuf);
    if(baseStatus || !baseBuf) { printf("can't allocate base CVPixelBuffer %d\n",baseStatus);return 69; }
    CGColorSpaceRef attachmentCS=baseAsSRGB?CGColorSpaceCreateWithName(kCGColorSpaceSRGB):baseCS;
    if(taggedBase) CVBufferSetAttachment(baseBuf,kCVImageBufferCGColorSpaceKey,attachmentCS,kCVAttachmentMode_ShouldPropagate);
    CVPixelBufferLockBaseAddress(baseBuf,0);
    CGContextRef bctx=CGBitmapContextCreate(CVPixelBufferGetBaseAddress(baseBuf),width,height,8,CVPixelBufferGetBytesPerRow(baseBuf),baseCS,(CGBitmapInfo)kCGBitmapByteOrder32Little|(CGBitmapInfo)kCGImageAlphaPremultipliedFirst);
    CGContextSetBlendMode(bctx,kCGBlendModeCopy);
    CGContextDrawImage(bctx,CGRectMake(0,0,width,height),base);
    CGContextRelease(bctx);
    CVPixelBufferUnlockBaseAddress(baseBuf,0);
    auto pq=CGColorSpaceCreateWithName(kCGColorSpaceDisplayP3_PQ);
    auto input=@{(__bridge id)kCVPixelBufferWidthKey:@(width),(__bridge id)kCVPixelBufferHeightKey:@(height),(__bridge id)kCVPixelBufferPixelFormatTypeKey:@(kCVPixelFormatType_32BGRA),(__bridge id)kCVImageBufferCGColorSpaceKey:(__bridge id)baseCS};
    auto headroom=CGImageGetHDRGainMapHeadroom(meta,nullptr);
    auto options=@{(__bridge id)kCGTargetPixelFormat:@(kCVPixelFormatType_64RGBAHalf),(__bridge id)kCGTargetHeadroom:@(headroom),(__bridge id)kCGFlexRangeAlternateColorSpace:(__bridge id)pq,(__bridge id)kCGTargetColorSpace:(__bridge id)kCGColorSpaceDisplayP3_PQ};
    CFDictionaryRef actual=nullptr;
    auto attrStatus=CGImageCreatePixelBufferAttributesForHDRTarget(2,(__bridge CFDictionaryRef)input,(__bridge CFDictionaryRef)options,&actual);
    printf("metadata headroom %.4f, output attributes status %d\n",headroom,attrStatus);
    if(attrStatus || !actual) return 70;
    NSMutableDictionary *attrs=[(__bridge NSDictionary*)actual mutableCopy];
    attrs[(__bridge id)kCVPixelBufferIOSurfacePropertiesKey]=@{};
    attrs[(__bridge id)kCVPixelBufferMetalCompatibilityKey]=@YES;
    NSNumber *p=attrs[(__bridge id)kCVPixelBufferPixelFormatTypeKey];
    OSType pixelFormat=p?p.unsignedIntValue:kCVPixelFormatType_64RGBAHalf;
    printf("target buffer %s\n",fmt(pixelFormat).UTF8String);
    CVPixelBufferRef target=nullptr;
    auto targetStatus=CVPixelBufferCreate(kCFAllocatorDefault,width,height,pixelFormat,(__bridge CFDictionaryRef)attrs,&target);
    if(targetStatus||!target) { printf("can't allocate target %d\n",targetStatus);return 71; }
    CVBufferSetAttachment(target,kIOSurfaceContentHeadroom,(__bridge CFTypeRef)@(headroom),kCVAttachmentMode_ShouldPropagate);
    CVBufferSetAttachment(target,kCVImageBufferCGColorSpaceKey,pq,kCVAttachmentMode_ShouldPropagate);
    NSMutableDictionary *arguments=[@{(__bridge id)kCGImageAuxiliaryDataInfoMetadata:(__bridge id)meta} mutableCopy];
    if(gmCS) arguments[(__bridge id)kCGImageAuxiliaryDataInfoColorSpace]=(__bridge id)gmCS;
    auto applyStatus=CGImageApplyHDRGainMap(baseBuf,gm,target,(__bridge CFDictionaryRef)arguments);
    printf("apply status %d\n",applyStatus);
    if (applyStatus) return 72;
    auto surface=CVPixelBufferGetIOSurface(target);
    auto result=CGImageCreateFromIOSurface(surface,nullptr);
    printf("after IOSurface handoff headroom %.4f %zu bpc\n",result?CGImageGetContentHeadroom(result):0.,result?CGImageGetBitsPerComponent(result):0);
    if(result) samples(@"SPI reconstruction, from IOSurface CGImage", [CIImage imageWithCGImage:result], ctx, linear);
    samples(@"SPI reconstruction, from CVPixelBuffer with explicit PQ", [CIImage imageWithCVPixelBuffer:target options:@{kCIImageColorSpace:(__bridge id)pq}], ctx, linear);
    return 0;
  }
}
