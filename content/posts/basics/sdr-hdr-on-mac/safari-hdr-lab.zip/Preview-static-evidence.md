# Preview HDR static evidence

Target Apple Preview macOS 27.2 (26B123), Preview 11.0 (1147.1.10).
Binary universal SHA-256 8818a0e7c199e334882a71179167458acb677ea3705e20a9e6710bc077a2e228.
Selected arm64e UUID 2212BCA6-AAD9-36FD-B8BE-D439DF04DDE9 (not arm64e.x1).
Attachment hdr-disassembly.txt is a bounded native disassembly excerpt produced by dyld_info.

- PVImageElement _imageOptions at 0x10004C68C: HDR branch sets kCIImageExpandToHDR=true and kCIImageGenerateFlexGTC=true. Alternate branch sets kCIImageToneMapHDRtoSDR=true. A branch with gain image in use returns empty options. Explicit assigned colorspace and ITU-R BT.2100 transfer function participate in branch decisions.
- Display-side _sourceCIImageWithSubsample:maxWidth:maxHeight:useSDRLayer: at 0x10004D19C calls _imageOptions, removes kCIImageExpandToHDR on SDR-layer flag, and initializes CIImage with source/index/options. _sourceImage at 0x10004D394 also initializes a CIImage from source/index/options.
- _gainImage at 0x10004B8E0 requests kCIImageAuxiliaryHDRGainMap. _gainImageType at 0x10004BA00 reads ImageIO auxiliary entries and distinguishes ISO and Apple HDR gain maps.
- _createLayerForView:scaleFactor:zoomCenter: at 0x10004E81C loads the Core Image path with useSDRLayer false, obtains a CGImage, sets CALayer contents, applies preferredDynamicRange=CADynamicRangeHigh at 0x10004EA00, and transfers contentsEDRStrength and contentsMaximumDesiredEDR from the image view.
- PVIKImageView2 inherits Quartz/ImageKit IKImageView2. initWithFrame: reads user default PVDisableHDRBackgroundAppDimming at 0x10015A2E8 and sends setHdrFocusMode: at 0x10015A30C with mode 2 if the flag is false (0 if true). setImage:withZoomFactor:andCenter:orAutoResizes: has an async branch sending updateHDRFocusWithAnimation: at 0x10015CC00.
- _CGImageOptions at 0x10004C560 constructs ImageIO DecodeToHDR (with kCGGenerateFlexGTC option) or DecodeToSDR, but directly observed use is metadata via mutableImageProperties, rather than claiming this is the primary viewing decode path.
- com.apple.Preview.image.wantsExtendedDynamicRangeContent is a KVO context string in observed callsites, not evidence of a preference.
- No GUI/runtime or luminance observation. No claims that the user's unidentified file hit a given branch, calibration, exact ImageKit mode 2 implementation, or quality equivalence to a browser.

## arm64e.x1 cross-check

Same behavior on arm64e.x1 UUID 832471DF-8CE0-3C2E-A0F3-8187435A0CCA. See hdr-disassembly-arm64e.x1.txt.

- Core Image options: _imageOptions 0x10004ACB4. ToneMapHDRtoSDR 0x10004AD38, ExpandToHDR 0x10004AD6C, GenerateFlexGTC 0x10004AD80. _sourceCIImageWithSubsample at 0x10004B77C, _sourceImage at 0x10004B964.
- Gain maps: _gainImageType at 0x10004A07C with ISO and Apple markers at 0x10004A190 and 0x10004A19C.
- CALayer: _createLayerForView at 0x10004CD08 with CADynamicRangeHigh / setPreferredDynamicRange calls around 0x10004CEEC, EDR strength and max desired EDR around 0x10004CF0C–0x10004CF2C.
- HDR focus: initWithFrame at 0x100151F9C with preference and setHdrFocusMode around 0x100152124–0x100152148. updateHDRFocusWithAnimation at 0x100154928.
