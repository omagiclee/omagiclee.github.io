import Foundation
import CoreGraphics
import CoreImage
import ImageIO
let args = Array(CommandLine.arguments.dropFirst())
guard args.count == 7,
      let viewW = Double(args[1]), let viewH = Double(args[2]),
      let left = Double(args[3]), let right = Double(args[4]),
      let top = Double(args[5]), let bottom = Double(args[6]),
      let src = CGImageSourceCreateWithURL(URL(fileURLWithPath: args[0]) as CFURL,nil)
else {fatalError("use file visualWidth visualHeight stripLeft stripRight brightTop brightBottom")}
let props = [kCGImageSourceDecodeRequest as String:kCGImageSourceDecodeToHDR] as CFDictionary
guard let img=CGImageSourceCreateImageAtIndex(src,0,props) else { fatalError("decode failed") }
let ci=CIImage(cgImage:img)
let cs=CGColorSpace(name:CGColorSpace.extendedLinearDisplayP3)!
let ctx=CIContext(options:[.workingColorSpace:cs])
let sw=Double(img.width)/viewW,sh=Double(img.height)/viewH
let ys=[0.25,0.5,0.75].map { Double(img.height)-sh*(top+(bottom-top)*$0) }
let patch=(right-left)/8
var gray:[Double]=[]
for i in 0..<8 {
    var mids:[[Double]]=[]
    let x=(left+(Double(i)+0.5)*patch)*sw
    for y in ys {
        let count=11
        var rgba=[Float](repeating:-1,count:count*count*4)
        rgba.withUnsafeMutableBytes { out in
            ctx.render(ci,toBitmap:out.baseAddress!,rowBytes:count*16,bounds:CGRect(x:Int(x)-count/2,y:Int(y)-count/2,width:count,height:count),format:.RGBAf,colorSpace:cs)
        }
        mids.append((0...2).map { k in
            let values=stride(from:k,to:rgba.count,by:4).map{Double(rgba[$0])}.sorted()
            return values[values.count/2]
        })
    }
    let rgb=(0...2).map { k in mids.map{$0[k]}.sorted()[1] }
    print("patch \(i+1)",rgb.map{String(format:"%.4f",$0)}.joined(separator:" "))
    if i < 6 {gray.append(0.228975*rgb[0]+0.691739*rgb[1]+0.079287*rgb[2])}
}
let rel=gray.map{$0/max(0.0001,gray[2])}
print("width=\(img.width) height=\(img.height) bitsPerComponent=\(img.bitsPerComponent) screenshotHeadroom=\(img.contentHeadroom)")
print("gray relative to third patch",rel.map{String(format:"%.4f",$0)}.joined(separator:" "))
