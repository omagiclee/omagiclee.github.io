import json
def inv_bt709(e):
 return e/4.5 if e < 0.081 else ((e+0.099)/1.099)**(1/.45)
def srgb_decode(e):
 return e/12.92 if e<=.04045 else ((e+.055)/1.055)**2.4
def srgb_encode(l):
 return 12.92*l if l<=.0031308 else 1.055*l**(1/2.4)-.055
def linear_rgb(patch,matrix='709',trc='apple1961',limited=True):
 Y, Cb, Cr=patch
 a,b=(.2126,.0722) if matrix=='709' else (.299,.114)
 y=(Y-16)/219 if limited else Y/255
 cb=(Cb-128)/(224 if limited else 255)
 cr=(Cr-128)/(224 if limited else 255)
 r=y+2*(1-a)*cr
 b0=y+2*(1-b)*cb
 g=(y-a*r-b*b0)/(1-a-b)
 f={'apple1961':lambda x:x**1.961,'bt1886_approx':lambda x:x**2.4,'inverse709':inv_bt709,'srgb':srgb_decode}[trc]
 return [f(max(0.,min(v,1.))) for v in (r,g,b0)]
m=json.load(open('source-measurements.json'))
params=[('main_apple1961','709','apple1961',True),('main_1886_idealized','709','bt1886_approx',True),('main_inverse709','709','inverse709',True),('control_srgb','709','srgb',True),('control_matrix601','601','apple1961',True),('control_full','709','apple1961',False)]
results={}
for name,matrix,trc,limited in params:
 result=[]
 for p in m['sdr709.mp4']['patches']:
  linear=linear_rgb(p['decoded_ycbcr'],matrix,trc,limited)
  result.append({'row':p['row'],'column':p['column'],'name':p['name'],'linear_srgb':linear,'srgb8':[round(255*srgb_encode(x)) for x in linear]})
 results[name]=result
with open('predictions.json','w') as f:json.dump(results,f,indent=2); f.write('\n')
for name,result in results.items():
 print(name,[(p['name'],p['srgb8']) for p in result if p['name'] in {'Y16','Y24','Y64','Y126','Y176','Y235','warm skin','red'}])
