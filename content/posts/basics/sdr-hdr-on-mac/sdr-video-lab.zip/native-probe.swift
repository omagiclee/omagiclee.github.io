import AVFoundation
import CoreGraphics
import CoreImage
import CoreVideo
import Foundation
import ImageIO

let linear = CGColorSpace(name: CGColorSpace.extendedLinearSRGB)!
let ctx = CIContext(options: [.workingColorSpace: linear])
let keys: [CFString] = [kCVImageBufferColorPrimariesKey,kCVImageBufferTransferFunctionKey,kCVImageBufferYCbCrMatrixKey]
func centers(_ img: CIImage) -> [[Float]] {
  let w = Int(img.extent.width), h = Int(img.extent.height)
  let locations = [(0,0),(0,7),(1,3),(1,5),(1,7),(2,0),(2,6)]
  var out: [[Float]] = []
  for (row,col) in locations {
    let x = Int(Double(w)*(Double(col)+0.5)/8.0)
    let y = h - 1 - Int(Double(h)*(Double(row)+0.5)/4.0)
    var pixel = [Float](repeating: 0, count: 4)
    pixel.withUnsafeMutableBytes { p in
      ctx.render(img,toBitmap: p.baseAddress!,rowBytes: 16,bounds: CGRect(x:x,y:y,width:1,height:1),format: .RGBAf,colorSpace: linear)
    }
    out.append(Array(pixel.prefix(3)).map{roundf($0*100000)/100000})
  }
  return out
}
@main struct Main {
static func main() async {
  for path in CommandLine.arguments.dropFirst(){
    let url = URL(fileURLWithPath: path)
    let asset = AVURLAsset(url: url)
    let gen = AVAssetImageGenerator(asset: asset)
    gen.requestedTimeToleranceBefore = .zero
    gen.requestedTimeToleranceAfter = .zero
    do {
      let (genImage,actualTime) = try await gen.image(at: CMTime(seconds: 0.5,preferredTimescale: 240))
      let cgProfile=genImage.colorSpace?.name.map { $0 as String } ?? "unnamed"
      let reading: [String:Any] = ["asset":url.lastPathComponent,"imageGeneratorSeconds":actualTime.seconds,"imageGeneratorColorSpace":cgProfile,"linearSRGB":centers(CIImage(cgImage:genImage))]
      let utf8 = try JSONSerialization.data(withJSONObject:reading,options:[.sortedKeys])
      print(String(data:utf8,encoding:.utf8)!)
    } catch { print(path,error) }
  }
}
}
