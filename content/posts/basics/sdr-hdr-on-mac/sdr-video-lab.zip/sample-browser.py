import json,statistics,subprocess
from pathlib import Path
def sample(path):
 w,h = [int(v) for v in subprocess.check_output(['ffprobe','-v','error','-show_entries','stream=width,height','-of','csv=p=0',str(path)]).split(b',')]
 raw=subprocess.check_output(['ffmpeg','-hide_banner','-loglevel','error','-i',str(path),'-f','rawvideo','-pix_fmt','rgb24','-'])
 assert len(raw)==w*h*3
 rows=[]
 for r in range(4):
  row=[]
  for c in range(8):
   x,y=(int((c+.5)*w/8),int((r+.5)*h/4))
   row.append([statistics.median(raw[(iy*w+ix)*3+ch] for iy in range(y-4,y+5) for ix in range(x-4,x+5)) for ch in range(3)])
  rows.append(row)
 return rows
all={p.name:sample(p) for p in sorted(Path('.').glob('*-sdr*.png'))}
Path('chrome-display-samples.json').write_text(json.dumps(all,indent=2)+'\n')
for f,rows in all.items():
 print(f, 'gray rows:', [[v[0] for v in row] for row in rows[:2]],'red:',rows[2][0], 'warm skin:',rows[2][6])
