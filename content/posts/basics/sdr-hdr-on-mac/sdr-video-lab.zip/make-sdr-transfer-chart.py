import json
from pathlib import Path
d=json.load(open('chrome-display-samples.json'))
m=json.load(open('source-measurements.json'))['sdr709.mp4']
w,h=760,410
L,T,R,B=72,70,715,315
def xy(x,y):
 return (L+(x-16)*(R-L)/219, B-y*(B-T)/255)
def a(txt,x,y,fill='#334155',size=14,anchor='start',weight='400'):
 return f'<text x="{x}" y="{y}" fill="{fill}" font-size="{size}" text-anchor="{anchor}" font-weight="{weight}">{txt}</text>'
parts=['<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 760 410" role="img" aria-labelledby="title desc"><title id="title">同一 BT.709 视频在 Chrome 的中间调差异</title><desc id="desc">无头 Chrome 默认路径的曲线在中间调高于禁用硬件解码的曲线。黑白端点相同。更换为 sRGB 传递标签后，默认路径与关闭硬解的基线在取样点重合。</desc><rect width="760" height="410" rx="16" fill="#f8fafc"/><g font-family="system-ui, sans-serif">']
parts += [a('同一 BT.709 视频，Chrome 的中间调随解码路径变化',38,31,'#0f172a',20,weight='650'),a('独立 macOS Chrome 158 · 无头合成截图 sRGB8，不是屏幕光度',38,53,'#475569',12)]
for yn in range(0,256,51):
 _,y=xy(16,yn)
 parts += [f'<path d="M {L} {y:.2f} H {R}" stroke="#cbd5e1" />', a(str(yn),58,y+5,anchor='end')]
for xn in [16,48,80,112,144,176,208,235]:
 x,_=xy(xn,0)
 parts += [f'<path d="M {x:.2f} {T} V {B}" stroke="#e2e8f0" />',a(str(xn),x,335,anchor='middle')]
parts += [a('画面 R（sRGB 8-bit）',L,T-5,size=12),a("源 Y′（BT.709 limited）",R,355,size=12,anchor='end')]
for filename,color,style in [('default-sdr709.png','#255cc9','line'),('software-sdr709.png','#ad4270','line'),('default-sdr-srgb-trc.png','#805b10','ring')]:
 data=d[filename]
 points=[xy(p['decoded_ycbcr'][0],data[p['row']][p['column']][0]) for p in m['patches'] if p['row']<2]
 if style=='line':
  parts.append('<polyline fill="none" stroke="'+color+'" stroke-width="2.6" points="'+' '.join(f'{x:.2f},{y:.2f}' for x,y in points)+'"/>')
  for x,y in points:
   parts.append(f'<circle cx="{x:.2f}" cy="{y:.2f}" r="3.0" fill="{color}"/>')
 else:
  for x,y in points:
   parts.append(f'<circle cx="{x:.2f}" cy="{y:.2f}" r="4.8" fill="none" stroke="{color}" stroke-width="1.2"/>')
for cx,color,lab in [(67,'#255cc9','1-1-1 默认'),(250,'#ad4270','1-1-1 禁用硬解'),(472,'#805b10','仅改 sRGB transfer，默认（描边）')]:
 parts += [f'<circle cx="{cx}" cy="381" r="4" fill="{color}"/>',a(lab,cx+12,386,size=13)]
parts.append('</g></svg>')
Path('sdr-video-chrome-transfer.svg').write_text(''.join(parts)+'\n')
