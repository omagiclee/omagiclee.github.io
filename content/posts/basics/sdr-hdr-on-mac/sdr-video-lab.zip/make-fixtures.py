import hashlib,json,math,subprocess
from pathlib import Path
w,h=960,540
neutral=[[16,17,18,20,24,32,48,64],[80,96,112,126,144,176,219,235]]
rgb=[
[('red',(0.80,0.08,0.08)),('green',(0.08,0.76,0.10)),('blue',(0.08,0.12,0.80)),('cyan',(0.10,0.70,0.72)),('magenta',(0.70,0.10,0.65)),('yellow',(0.74,0.72,0.10)),('warm skin',(0.74,0.45,0.34)),('deeper skin',(0.52,0.31,0.24))],
[('warm white',(0.89,0.85,0.76)),('ochre',(0.76,0.47,0.11)),('olive',(0.40,0.46,0.20)),('teal',(0.11,0.45,0.47)),('lavender',(0.51,0.41,0.67)),('neutral 35%',(.35,.35,.35)),('neutral 75%',(.75,.75,.75)),('framing white',(1,1,1))]
]
def from_709_rgb(r,g,b):
 y=.2126*r+.7152*g+.0722*b
 return (round(16+219*y),round(128+224*(b-y)/(2*(1-.0722))),round(128+224*(r-y)/(2*(1-.2126))))
patches=[[(f'Y{j}',(j,128,128)) for j in row] for row in neutral]+[[(name,from_709_rgb(*values)) for name,values in row] for row in rgb]
def run(*args,stdout=None):
 return subprocess.run(['ffmpeg','-y','-nostdin','-hide_banner','-loglevel','error',*args],check=True,stdout=stdout)
raw=b''
for ch,s in [(0,1),(1,2),(2,2)]:
 raw+=b''.join(b''.join(bytes([patches[min(y*4*s//h,3)][i][1][ch]])*(w//(s*8)) for i in range(8)) for y in range(h//s))
Path('source.yuv').write_bytes(raw)
run('-f','rawvideo','-pixel_format','yuv420p','-video_size',f'{w}x{h}','-framerate','24','-color_range','tv','-color_primaries','bt709','-color_trc','bt709','-colorspace','bt709','-stream_loop','-1','-i','source.yuv','-vf','setparams=range=limited:color_primaries=bt709:color_trc=bt709:colorspace=bt709','-t','20','-an','-c:v','libx264','-profile:v','high','-pix_fmt','yuv420p','-crf','1','-g','48','-x264-params','colorprim=bt709:transfer=bt709:colormatrix=bt709:fullrange=off','-color_range','tv','-color_primaries','bt709','-color_trc','bt709','-colorspace','bt709','-movflags','+faststart+write_colr','sdr709-temp.mp4')
run('-i','sdr709-temp.mp4','-map','0:v:0','-an','-c','copy','-bsf:v','h264_metadata=colour_primaries=1:transfer_characteristics=1:matrix_coefficients=1:video_full_range_flag=0','-color_range','tv','-color_primaries','bt709','-color_trc','bt709','-colorspace','bt709','-movflags','+faststart+write_colr','sdr709.mp4')
Path('sdr709-temp.mp4').unlink()
# Same coded samples. Change only NCLX + matching H.264 VUI signal.
variants=[
 ('sdr-srgb-trc.mp4','tv','iec61966-2-1','bt709','transfer_characteristics=13', (1,13,1,0)),
 ('sdr-full-tag.mp4','pc','bt709','bt709','video_full_range_flag=1', (1,1,1,1)),
 ('sdr-601-matrix.mp4','tv','bt709','smpte170m','matrix_coefficients=6', (1,1,6,0)),
]
for f,rg,trc,mat,bsf,tag in variants:
 run('-i','sdr709.mp4','-map','0:v:0','-an','-c','copy','-bsf:v','h264_metadata='+bsf,
     '-color_range',rg,'-color_primaries','bt709','-color_trc',trc,'-colorspace',mat,'-movflags','+faststart+write_colr',f)
def decoded(name):
 # Force the same range label on the extracted YUV to avoid implicit range-conversion at the rawvideo muxer.
 return subprocess.check_output(['ffmpeg','-nostdin','-hide_banner','-loglevel','error','-i',name,'-frames:v','1','-c:v','rawvideo','-f','rawvideo','-'])
def native_cicp(p):
 data=Path(p).read_bytes()
 pos=data.index(b'colrnclx')+8
 from struct import unpack
 a,b,c,rg=unpack('>HHHB',data[pos:pos+7])
 return (a,b,c,rg>>7)
def yuv_at(yuv,x,y):
 cx,cy=x//2,y//2
 return (yuv[y*w+x],yuv[w*h+cy*(w//2)+cx],yuv[w*h*5//4+cy*(w//2)+cx])
meta={}
for name,*_,wanted_tag in [('sdr709.mp4',None,(1,1,1,0)),*variants]:
 data=decoded(name)
 assert len(data)==w*h*3//2
 actual_tag=native_cicp(name)
 assert actual_tag==wanted_tag,(name,actual_tag,wanted_tag)
 digest=hashlib.sha256(data).hexdigest()
 if meta:
  assert digest==meta['sdr709.mp4']['decoded_frame_sha256'],(name,digest)
 meta[name]={"nclx":actual_tag,"width":w,"height":h,"decoded_frame_sha256":digest,"patches":[
 {'row':r,'column':c,'name':label,'center_fraction':[(c+.5)/8,(r+.5)/4],
 'design_ycbcr':val,'decoded_ycbcr':yuv_at(data,int((c+.5)*w/8),int((r+.5)*h/4))}
 for r,row in enumerate(patches) for c,(label,val) in enumerate(row)]}
 print(name,actual_tag,digest)
Path('source-measurements.json').write_text(json.dumps(meta,indent=2)+'\n')
Path('source.yuv').unlink()
