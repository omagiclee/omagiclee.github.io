const {chromium}=require(process.env.PLAYWRIGHT_PATH||'playwright');
const {createServer}=require('node:http');
const {readFile}=require('node:fs/promises');
const path=require('node:path');
const fs=require("node:fs");
const fixtures=['sdr709.mp4','sdr-srgb-trc.mp4','sdr-full-tag.mp4','sdr-601-matrix.mp4'];
const server=createServer(async(req,res)=>{
 const name=path.basename(new URL(req.url,'http://localhost').pathname);
 if(![...fixtures,'sdr-video.html'].includes(name)){res.writeHead(404);res.end();return;}
 const contents=await readFile(path.join(__dirname,name));
 const type=name.endsWith('.mp4')?'video/mp4':'text/html';
 const m=/^bytes=(\d+)-(\d*)$/.exec(req.headers.range??'');
 if(m){
   const start=+m[1],end=m[2]?Math.min(+m[2],contents.length-1):contents.length-1;
   if(start>end){res.writeHead(416,{'Content-Range':'bytes */'+contents.length});return res.end();}
   res.writeHead(206,{'Content-Type':type,'Accept-Ranges':'bytes','Content-Range':'bytes '+start+'-'+end+'/'+contents.length,'Content-Length':end-start+1});return res.end(contents.subarray(start,end+1));
 }
 res.writeHead(200,{'Content-Type':type,'Accept-Ranges':'bytes','Content-Length':contents.length});res.end(contents);
});
async function one(browser,name,mode,port){
 const context=await browser.newContext({viewport:{width:1100,height:750},deviceScaleFactor:1});const page=await context.newPage();
 const cdp=await page.context().newCDPSession(page);
 const props={},events=[];
 cdp.on('Media.playerPropertiesChanged',e=>e.properties.forEach(a=>props[a.name]=a.value));
 cdp.on('Media.playerEventsAdded',e=>events.push(...e.events));
 await cdp.send('Media.enable');
 await page.goto('http://127.0.0.1:'+port+'/sdr-video.html?file='+name);
 await page.waitForFunction(()=>document.querySelector('video').currentTime>.30,{},{timeout:10000});
 let status=await page.evaluate(()=>({ua:navigator.userAgent, capability:matchMedia('(dynamic-range: high)').matches,quality:document.querySelector('video').getVideoPlaybackQuality().totalVideoFrames}));
 if(name==='sdr709.mp4'){
  const internals=await page.context().newPage();
  await internals.goto('chrome://media-internals/');
  await internals.waitForTimeout(800);
  const inspected=await internals.evaluate(()=>{
   const visible=document.querySelector('#player-list')||document.querySelector('#players')||document.querySelector('ul');
   const li=visible?.querySelector('.tree-item-header');
   li?.click();
   return {globals:Object.getOwnPropertyNames(window).filter(x=>/media|manager|player/i.test(x)),out:document.body.innerText,dom:visible?.outerHTML?.slice(0,8000)};
  });
  await internals.close();
  fs.writeFileSync(mode+'-media-internals.json',JSON.stringify(inspected,null,2));
 }
 await page.locator('video').screenshot({path:mode+'-'+name.replace('.mp4','.png')});
 console.log(JSON.stringify({mode,name,status,props,events:events.filter(e=>e.value.includes('decoder')||e.value.includes('pipeline'))}));
 await context.close();
}
(async()=>{
 let browser;
 try{
   await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(0,'127.0.0.1',resolve)});
   for(const [mode,args] of [['default',[]],['software',['--disable-accelerated-video-decode']]]){
     browser=await chromium.launch({executablePath:process.argv[2],headless:true,args});
     for(const f of fixtures)await one(browser,f,mode,server.address().port);
     await browser.close();browser=null;
   }
 }catch(e){console.error(e);process.exitCode=1}
 finally{await browser?.close();server.close()}
})();
