# SDR 视频路径的静态与运行证据

## Chrome 158.0.8127.88，macOS 27.2 26B123

- 运行：Chrome for Testing 新的临时无头实例。两次用相同 BT.709 1-1-1 limited 文件，默认 Media Internals 显示 VideoToolboxVideoDecoder / platform=true；关闭硬解后 FFmpegVideoDecoder / platform=false。详见 chrome-actual-decoders.txt。
- 同一码值像素在默认路径显著变亮于中间调（Y'=64、126、176 的 R 输出分别 64/139/194，而禁用硬解 56/128/186），黑白端点相同。仅更改文件 transfer 标签为 sRGB 时，默认路径结果在 32 个色块中心精确等于软件路径的 1-1-1。由此可将差异缩小到两条路径的传递曲线解释。此采样系数字合成截图，不是显示器实测 nit。
- 同版本 Chromium 158.0.8127.88 源码明确两条曲线：ui/gfx/mac/color_space_util.mm 把 Apple CoreVideo 的 709 transfer 附件优先匹配到 BT709_APPLE；ui/gfx/color_space.cc 把 BT709_APPLE 解析为 kRec709Apple（约 1.961），而普通 BT709 与 sRGB 共用标准 sRGB transfer。软件解码则映射 FFmpeg 帧的色彩元数据。默认路径中性灰符合 1.961 模型。不存在应用到实际窗口的普遍性声明，尤其不外推到外屏的显示 EOTF。
- 源码链接：<https://chromium.googlesource.com/chromium/src/+/refs/tags/158.0.8127.88/ui/gfx/color_space.cc#990> · <https://chromium.googlesource.com/chromium/src/+/refs/tags/158.0.8127.88/ui/gfx/mac/color_space_util.mm#99> · <https://chromium.googlesource.com/chromium/src/+/HEAD/media/filters/ffmpeg_video_decoder.cc>

## QuickTime Player / Safari / 照片对应的本机静态锚点

- 目标：QuickTime Player 10.5 (1278.2)，dyld_info -objc → MGPlayerView : AVPlayerView；dyld_info -imports → AVPlayerLayer、AVPlayerView、CVImageBufferCreateColorSpaceFromAttachments。
- 目标：照片 12.0 (916.58.114)，dyld_info -objc → -[IPXViewerMediaController _handleVideoPlayerItem:preferredSeekTime:info:forAsset:completion:]、_updateVideoPlayer:orientation:；dyld_info -imports → AVPlayer、AVPlayerItem、PHImageManager、PHVideoRequestOptions。说明“照片”存在图库请求与系统 AVPlayer 的路径，不确定具体资产在何时播放原件、代理或渲染版本。
- 目标：Safari 27.2 的 WebCore 共享缓存。存在 WebCore::MediaPlayerPrivateAVFoundationObjC::createVideoLayer、platformLayer、paintWithVideoOutput，对应 WebKit 的 AVFoundation ObjC 后端。静态符号不表示每帧必然进入同一表面。
- 厂商用色阶测试说明文档 <https://developer.apple.com/documentation/avfoundation/evaluating-video-using-quicktime-test-pattern-files.md>；光度测量与支持的显示参考模式 <https://developer.apple.com/documentation/avfoundation/evaluating-an-app-s-video-color-using-light-measurement-instruments.md>。后者区分 Mac 内置屏路径的 1.961、HDMI 外屏的接收端 EOTF、XDR HDTV 参考模式 BT.1886 约 2.4。

## AVFoundation 独立帧输出

AVAssetImageGenerator 在同机取 0.5 秒帧，再由 CoreImage 变换到扩展线性 sRGB，不经过 QuickTime／照片窗口。对主片报告 kCGColorSpaceCoreMedia709。取样次序为 Y16、Y64、Y126、Y176、Y235、红、暖肤色。Y126 的 G 主片/只改 transfer 分别 0.25884/0.21579。只改 range 则 G 黑白从 0/0.99232 变为 0.00439/0.84491。只改 601 matrix，中性取样完全不变、红块 R 从 0.63941 变为 0.55006。详见 native-frame-color.ndjson。
